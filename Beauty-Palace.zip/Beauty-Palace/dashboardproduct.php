<!DOCTYPE html>
<html>
  <head>
	<title>BEAUTY PALACE - Product</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </head>
<body>
    <center><img src="img/New_Project2.jpg"></center>
	<div class="main-menu>
	<div class="area"></div><nav class="main-menu">
        <ul>
            <li>
                <a href="index.php"> 
				<i class="fa fa-home fa-2x"></i>
                <span class="nav-text">
                    Billing
                </span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardpurchase.php">
                    <i class="fa fa-laptop fa-2x"></i>
                    <span class="nav-text">
                        Purchase
                    </span>
                    </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardsales.php">
                    <i class="fa fa-list fa-2x"></i>
                    <span class="nav-text">
                        Sales
                    </span>
                    </a>
            </li>
			<li>
                <a href="dashboardproduct.php">
                    <i class="fa fa-bar-chart-o fa-2x"></i>
                    <span class="nav-text">
                        Add Product 
                    </span>
                    </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardstock.php">
					 <i class="fa fa-table fa-2x"></i>
					<span class="nav-text">
						Stock Report
                    </span>
                </a>
            </li>
            <li>
                <a href="salesReport.php">
					 <i class="fa fa-table fa-2x"></i>
					<span class="nav-text">
					Sales Report
					</span>
                </a>
            </li>
            <li>
                <a href="#">
					<i class="fa fa-table fa-2x"></i>
                    <span class="nav-text">
                        Tables
                    </span>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="fa fa-map-marker fa-2x"></i>
                    <span class="nav-text">
                        Maps
                    </span>
                </a>
            </li>
            <li>
				<a href="documentation.php">
					<i class="fa fa-info fa-2x"></i>
					<span class="nav-text">Documentation</span>
                </a>
            </li>
        </ul>
        <ul class="logout">
            <li>
                <a href="#">
                <i class="fa fa-power-off fa-2x"></i>
                <span class="nav-text">
                            Logout
                </span>
                </a>
            </li>  
        </ul>
        </nav>
 <div class="container">
 <article>
 <p><br/></p>	<p><br/></p> 
 <div class="row">
 <div class="col-sm-4"> <blockquote><blockquote><blockquote><blockquote>
	<h3 align="left">PRODUCT</h3>
 	<table> 
	<?php	
	
		include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect();		
		$purchaseid1=$_GET['id'];
		$result = $DbFunction->getData("SELECT * FROM mpurchase WHERE purchaseid='$purchaseid1'");
		
		foreach ($result as $res)
		{
			$purchaseid = $res['purchaseid'];
			$productname=$res['productname'];
			$itemname=$res['itemname']; 
			$productcode=$res['productcode'];
			$productprice=$res['productprice'];
			$sellingprice=$res['sellingprice'];
			
		}
		
		
		
	?>
	
	<form  id="form1" name="form1" align="LEFT" action="dashboardproduct.php"  method="post" autocomplete="on">
	
    	<td width="140">
        <tr>
            <td width="100">&nbsp;</td></tr>
        <tr>
		<td align="left">Product Id</td>
		<td><label>
		
	<?php
		include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect(); 
		$query = "SELECT DISTINCT purchaseid FROM mpurchase ORDER BY purchaseid DESC Limit 1";
		$result = $DbFunction->getData($query);
		foreach ($result as $res) 
		{
			$purchaseid = $res['purchaseid'];
		}
		$purchaseid = ($purchaseid + 1);
		
	
		
	if(isset($purchaseid) and !(isset($purchaseid1))) {
	?>	
		<input disabled type="text" value="<?php echo $purchaseid; ?>" autofocus name="purchaseid" />
		<input hidden type="text" value="<?php echo $purchaseid; ?>" autofocus name="purchaseid" />
	
	<?php
	
	} 	

	if(isset($purchaseid1)) {
		$purchaseid1=$_GET['id'];
	?>	
		<input disabled type="text" value="<?php echo $purchaseid1; ?>" autofocus name="purchaseid1" />
		<input hidden type="text" value="<?php echo $purchaseid1; ?>" autofocus name="purchaseid1" />
	<?php
	
	} 	

	?>
	
	
	</label></td>
	</tr>
   
	<tr>
		<td align="left">Product Category</td>
        <td><label>
		<input type="text" value="<?php echo $productname; ?>" autofocus name="productname" />					
		</label></td>
	</tr>                  
    <tr>
		<td align="left">Product Name </td>
        <td><label><input type="text" value="<?php echo $itemname; ?>" name="itemname" /></label></td>
    </tr>
	
	<tr>
		<td align="left">Product Price </td>
        <td><label><input type="text" value="<?php echo $productprice; ?>" name="productprice" /></label></td>
    </tr>
	
	<tr>
		<td align="left">Selling Price </td>
        <td><label><input type="text" value="<?php echo $sellingprice; ?>" name="sellingprice" /></label></td>
    </tr>
	
	<tr>
        <td>&nbsp;</td>
        <td> 
		<input type="submit" name="AddSubmit" value="Submit" formaction="addproduct.php" class="form-submit-button" title="Submit Purchase Master" />

		<input type="submit" name="Select" value="Update" formaction="addproduct.php" class="form-submit-button" title="Update Purchase Master" />
	</tr>
    </form>
    </table> 
	</div>
	<div class="col-sm-8">
	
	<?php     
	
		include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect();
		$query = "SELECT * FROM mpurchase ORDER BY purchaseid Desc";
		$total_results = $DbFunction->getNorows($query);
		$per_page = 15;
		$total_pages = ceil($total_results / $per_page);
		if (isset($_GET['page']) && is_numeric($_GET['page']))
        {
            $show_page = $_GET['page'];
            if ($show_page > 0 && $show_page <= $total_pages)
			{
                $start = ($show_page -1) * $per_page;
                $end = $start + $per_page; 
            }
            else
            {
                echo      $start = 0;
                echo      $end = $per_page; 
            }               
        }
        else
        {
            $start = 0;
            $end = $per_page; 
        }
		$result = $DbFunction->getData("SELECT * FROM mpurchase ORDER BY purchaseid Desc Limit $start, $per_page");
		echo "<div><table align='center'  class='table-responsive table-fixed ' height='658px' cellpadding='0.5' border-spacing: 1px; style='border-collapse: collapse;'>";
		echo '<tr> <th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center;">Sr. No.</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product Id</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product Category</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product Code</th>		
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item Name</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; "><img src="update.png" href=""></th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; "><img src="del.png" href=""></th>
		</tr>';
		$start = $start + 1;
		for ($i = $start; $i < $end; $i++)
        {
            if ($i == $total_results) { break; }		
			foreach ($result as $res) 
			{
				$purchaseid = $res['purchaseid'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$productcode=$res['productcode'];
				
				echo "<tr>";
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $purchaseid. '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $productcode . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="dashboardproduct.php?id=' . $purchaseid . '"><img src="update.png"></a></td>'; 
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="deleteproduct.php?id=' . $purchaseid . '" onclick="return confirmDelete()"><img src="del.png"></a></td>';	
				echo "</tr>"; 
				$i = $i + 1;	
			}
			if ( $i > $rows ) 
			{
				break;	
			} 
		}
		echo "</table></div>";
		echo "<div align='center'>";      
        echo "<p><b>View Page Wise:</b> ";
        for ($i = 1; $i <= $total_pages; $i++)
        {
                echo "<a id = 'anchortag' href='dashboardpurchase.php?page=$i'>$i</a> ";
        }
        echo "</div>";
		
	?>
	
 </div>
</div>
 </div>
 </article>
 </div>
</div>
 <script type="text/javascript">
  function submitForm(action) {
    var form = document.getElementById('form1');
    form.action = action;
    form.submit();
  }
</script>
</body>
</html>