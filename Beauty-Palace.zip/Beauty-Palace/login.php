<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Beauty Palace</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script>
		function newRow(){
				
					var table = document.getElementById("tbl");
					var row = table.insertRow(1);
					var cell1 = row.insertCell(0);
					var cell2 = row.insertCell(1);
					var cell3 = row.insertCell(2);
					cell1.innerHTML = "<input type='text' name='name[]' />";
					cell2.innerHTML = "<input type='text' name='email[]' /><br/>";
					cell3.innerHTML = "<input type='button' onclick='newRow()' value='Add'/>"; 
					 
				}
		</script>
	</head>
	<body>
	<form action="addarray.php" method="post">
	<table name="tbl" id="tbl">
	<tr>
	<td><input type="text" name="name[]" /></td>
	<td><input type="email" name="email[]" /></td>
	</tr>
	
	<tr>
	<td><input type='button' onclick='newRow()' value='Add'/></td>
	<td><input type="submit" name="AddSubmit" value="Submit"></td>
	</tr><br/>
	</form>
	
	</body>
</html>