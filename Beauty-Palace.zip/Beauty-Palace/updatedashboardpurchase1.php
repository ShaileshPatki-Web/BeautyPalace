<!DOCTYPE html>
<html lang="en">
<head>
<title>Beauty Palace</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Style the header */
header {
  background-color: rgb(16, 176, 231);
  padding: 20px;
  text-align: center;
  font-size: 15px;
  color: white;
}

/* Create two columns/boxes that floats next to each other */
nav {
  float: left;
  width: 7%;
  height: 650px; /* only for demonstration, should be removed */
  background: DodgerBlue;
  padding: 0px;
}

/* Style the list inside the menu */
nav ul {
  list-style-type: none;
  padding: 0;
}

article {
  float: right;
  padding: 10px;
  width: 93%;
  background-color: #f1f1f1;
  height: 650px; 
}

/* Clear floats after the columns */
section:after {
  content: "";
  display: table;
  clear: both;
}

/* Style the footer */
footer {
  background-color: #777;
  padding: 10px;
  text-align: center;
  color: white;
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;

  color: white;                  
  font-size: 10px;    
  text-align: center;
}

/* Responsive layout - makes the two columns/boxes stack on top of each other instead of next to each other, on small screens */
@media (max-width: 600px) {
  nav, article {
    width: 100%;
    height: auto;
  }
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: DodgerBlue;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
}
li a:hover {
  background-color: rgb(16, 176, 231);
  color: white;
}
</style>
</head>
<body>



<header>
  <h2>Beauty Palace</h2>
</header>

<section>
  <nav>
    <ul>
      <li><a href="dashboardsales.php">Sales</a></li>
      <li><a href="index.php">Purchase</a></li>

      <li><a href="dashboard.php">Billing</a></li>
    </ul>
  </nav>
  
  <article>
    <h1>Purchase</h1>
    <p>
	
	<?php
		
		error_reporting("0");
		include ("connect_db.php");
						
		$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
		
		if(!$con)
		{
			die ("Can't Connect");
		} 
				
		include_once("classes/Crud.php");	
		
		$objEmp=new dbConnect("localhost","root","","beautypalace");
		
		$crud = new Crud();
		
		$conn = $crud->myconnect();					
				
		$purchasebillno = $_GET['id'];
		
		$query ="SELECT * FROM purchase WHERE purchaseid = '$purchasebillno'";
		
		$result=$objEmp->connect($query);
		
		while($row = mysql_fetch_array( $result )) 
  			{			
				  $id = $row['purchaseid'];
				  $purchasebillno = $row['purchasebillno'];
				  $vendorname = $row['vendorname'];
				  $venderinoviceno=$row['venderinoviceno'];
				  $productname=$row['productname'];
				  $itemname=$row['itemname']; 
				  $productcode=$row['productcode'];
				  $itemprice=$row['itemprice'];
				  $sellingprice=$row['sellingprice'];
				  $itemquantity=$row['itemquantity'];
				  $total=$row['total']; 
				  
				  $gstpercentage=$row['gstpercentage'];
				  $gstontotal=$row['gstontotal'];
				  $grandtotal=$row['grandtotal'];	
			}
		
	?>
			<table  height="50" width="350" align="LEFT" > 
            <form name="updatedashboardpurchase" align="LEFT" action="updatepurchasebillquery.php"  method="post">
            <td width="100">
                <tr>
                    <td width="100">&nbsp;</td></tr>
                <tr>
					<td align="left">Purchase Bill Number </td>
					<td><label>
						<input type="text" autofocus name="purchasebillno" value="<?php echo $purchasebillno; ?>" />
					</label></td>
                </tr>
                <tr>
					<td width="100">&nbsp;</td>
                <tr>
					<td align="left">Vendor Name </td>
                    <td><label>
						<input type="text" autofocus name="vendorname" value="<?php echo $vendorname; ?>" />					
					    </label></td>
				</tr>  
				 <tr>
					<td width="100">&nbsp;</td>
                <tr>
				<tr>
                      <td align="left">Invoice Number </td>
                      <td><label>
                        <input type="text" autofocus name="venderinoviceno" value="<?php echo $venderinoviceno; ?>" />
                      </label></td>
                    </tr>     
                <tr>
                    <td width="100">&nbsp;</td>
				</tr>
                <tr>
                    <td align="left">Product Category </td>
                    <td><label>
					<select name="productname" value="<?php echo $venderinoviceno; ?>"  width="170px">
						<?php
						
						$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
						
						if(!$con)
						{
							die ("Can't Connect");
						} 
						
						$query = "SELECT DISTINCT productname FROM mpurchase";
						
						$result = mysqli_query($con, $query);				
						
						while($row = mysqli_fetch_array($result))
						{
							$mproduct=$row['productname'];
							echo "<option>$mproduct</option>";
						} 
						
						echo "</select>";
						
						?>
					</label></td>
                </tr>
				<tr>
				    <td>&nbsp;</td>
                </tr>
                <tr>
					<td align="left">Product Name </td>
                    <td><input type="text" name="itemname" value="<?php echo $itemname; ?>" /></td>
                </tr>
                <tr>
				    <td>&nbsp;</td>
                </tr>
				<tr>
					<td align="left">Product Code </td>
                    <td><input type="text" name="productcode" value="<?php echo $productcode; ?>" /></td>
                </tr>
                <tr>
				    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td align="left">Product Price </td>
                    <td><input type="text" name="itemprice" value="<?php echo $itemprice; ?>"  /></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
				
				<tr>
                    <td align="left">Selling Price </td>
                    <td><input type="text" name="sellingprice" value="<?php echo $sellingprice; ?>"  /></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
				
				<tr>
					<td align="left">Product Quantity </td>
                    <td><input type="text" name="itemquantity" value="<?php echo $itemquantity; ?>" /></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>             
                <tr>
                    <td align="left">GST % </td>
                    <td><input type="text" name="gstpercentage" value="<?php echo $gstpercentage; ?>" /></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>                 	
				<tr>
                    <td>&nbsp;</td>
                    <td> 
						<input type="submit" name="AddSubmit" value="Submit" class="form-submit-button"  /> </td>
                </tr>
                <tr>
					<td>&nbsp;</td>
                </tr>
				</form>
            </table>
			
		<?php          

		$objEmp=new dbConnect("localhost","root","","beautypalace");
				
		include_once("classes/Crud.php");
		
		$perpage = 10;
		
		if(isset($_GET["page"])){
		$page = intval($_GET["page"]);
		}
		else {
		$page = 1;
		}
		
		$calc = $perpage * $page;
		$start = $calc - $perpage;
		
		$crud = new Crud();
		
		$conn = $crud->myconnect();					
				
		$purchaseid = $_GET['id'];
		
		if ( $objEmp->ifsessionExists() === FALSE ) session_start();
			
		$_SESSION['work_srno'] = $purchaseid;
		
		$query ="SELECT * FROM purchase WHERE purchaseid = '$purchaseid'";
		
		$result=$objEmp->connect($query);
		
		while($row = mysql_fetch_array( $result )) 
  			{			
				  $id = $row['purchaseid'];
				  $purchasebillno = $row['purchasebillno'];
				  $vendorname = $row['vendorname'];
				  $venderinoviceno=$row['venderinoviceno'];
				  $productname=$row['productname'];
				  $itemname=$row['itemname']; 
				  
				  $itemprice=$row['itemprice'];
				  $itemquantity=$row['itemquantity'];
				  $total=$row['total']; 
				  
				  $gstpercentage=$row['gstpercentage'];
				  $gstontotal=$row['gstontotal'];
				  $grandtotal=$row['grandtotal'];	
			}
			
		$query ="SELECT * FROM purchase WHERE purchaseid = '$id'";
		
		$rows = $crud->getNorows($query); 
		
		$result = $crud->getData("SELECT * FROM purchase WHERE purchaseid = '$id' ORDER BY purchaseid Desc Limit $start, $perpage");
		
		echo "<div><table align='center' height:70 width:100 class='table' cellpadding='0.5' border-spacing: 0px; style='border-collapse: collapse;'>";

		echo '<tr> <th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF; text-align: center; ">SrNo</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">purchasesBillNo</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">VendorrName</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Inovice No</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">ProductName</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Product Code</th>		
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">ItemName</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">ItemPrice</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Selling Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">ItemQuantity</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">PriceTotal</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">GST%</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">GSTTotal</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">GrandTotal</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; "><img src="update.png" href=""></th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; "><img src="del.png" href=""></th>
		
</tr>';
				
			$start = $start + 1;
			 
			for( $i = $start; $i < $calc; $i++) {		
			
			foreach ($result as $res) {
			  $purchaseid = $res['purchaseid'];
			  $purchasebillno = $res['purchasebillno'];
			  $vendorname = $res['vendorname'];
			  $venderinoviceno=$res['venderinoviceno'];
			  $productname=$res['productname'];
			  $itemname=$res['itemname']; 
			  $productcode=$res['productcode'];
			  $itemprice=$res['itemprice'];
			  $sellingprice=$res['sellingprice'];
			  $itemquantity=$res['itemquantity'];
			  $total=$res['total']; 
			  
			  $gstpercentage=$res['gstpercentage'];
			  $gstontotal=$res['gstontotal'];
			  $grandtotal=$res['grandtotal']; 
				  
			 	echo '<tr> </tr>';
				echo '<tr> </tr>';
			
				echo "<tr>";
            
                echo '<td style="padding: 1PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
                echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $purchasebillno . '</td>';
                echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $vendorname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $venderinoviceno . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $productcode . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $sellingprice . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $total . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $gstpercentage . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $gstontotal . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $grandtotal . '</td>';
				
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="updatedashboardpurchase.php?id=' . $purchaseid . '"><img src="update.png"></a></td>'; 
				
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="deletepurchasebill.php?id=' . $id . '" onclick="return confirmDelete()"><img src="del.png"></a></td>';	
                echo "</tr>"; 
				
				$i = $i + 1;	
							
				}
				
				if ( $i > $rows ) {
				break;	
				
				} 
			}
					
		echo "</table></div>";
 
 ?>
			
	</p>
	
  </article>
</section>

<footer>
  <p>Copyright 2019</p>
</footer>

</body>
</html>