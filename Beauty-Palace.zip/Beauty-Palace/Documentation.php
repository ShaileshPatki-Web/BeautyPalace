<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Beauty Palace</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<center><img src="img/New_logof.jpg"></center>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/table.css"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
		<script src="table2excel.js" type="text/javascript"></script>
		<script type="text/javascript">
			function myFunction() 
			{
				var htmltable= document.getElementById('tblCustomers');
				var html = htmltable.outerHTML;
				window.open('data:application/vnd.ms-excel,' + encodeURIComponent(html));
			} 
			function stockPrint()
			{
				var table=document.getElementById("tblCustomers");
				 newWin=window.open("");
				 newWin.document.write("<html><head><link rel='stylesheet' type='text/css' href='bootstrap/css/table.css'/></head> <body>");
				// newWin.document.write($('#tblCustomers').html());
				 newWin.document.write(table.outerHTML);
				 newWin.document.write("</body></html>");
				 newWin.print();
				 newWin.close();
				 //window.print();
				
			}
</script>

  </head>
  <body>
  <div class="main-menu>
  <div class="area"></div><nav class="main-menu">
		<ul>
            <li><a href="index.php">
			<i class="fa fa-home fa-2x"></i>
            <span class="nav-text">Billing</span>
            </a>
            </li>
			<li class="has-subnav">
                <a href="dashboardpurchase.php">
                <i class="fa fa-laptop fa-2x"></i>
                <span class="nav-text">Purchase</span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardsales.php">
                <i class="fa fa-list fa-2x"></i>
                <span class="nav-text">Sales</span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="#">
                 <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Stock Report</span>
                </a>
            </li>
           <li>
                    <a href="dashboardproduct.php">
                        <i class="fa fa-bar-chart-o fa-2x"></i>
                        <span class="nav-text">
                           Add Product 
                        </span>
                    </a>
                </li>
            <li>
                <a href="#">
                <i class="fa fa-font fa-2x"></i>
                <span class="nav-text">Quotes</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Tables</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-map-marker fa-2x"></i>
                <span class="nav-text">Maps</span>
                </a>
            </li>
            <li>
				<a href="documentation.php">
                <i class="fa fa-info fa-2x"></i>
                <span class="nav-text">Documentation</span>
                </a>
            </li>
        </ul>
        <ul class="logout">
			<li>
			<a href="#">
            <i class="fa fa-power-off fa-2x"></i>
            <span class="nav-text">Logout</span>
            </a>
			</li>  
        </ul>
    </nav>
 <div class="container">
 <article>
	<h3>Documentation</h3>
	<div class="row">&nbsp;</div>
	 <div class="row" >
	 <div class="col-md-12">
	 <div class="search-container" >
	 <p></p>
		
	</div>
	</div>
	</div>
	<div class="row">
	<div class="col-md-12">
  </article>
 </div>
 </div>
 </body>
</html>