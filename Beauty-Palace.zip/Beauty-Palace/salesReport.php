<!DOCTYPE html>
<html lang="en">
<head>
<title>Beauty Palace - Sales Report</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<center><img src="img/New_logof.jpg"></center>
<link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
<link rel="stylesheet" type="text/css" href="bootstrap/css/table.css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="table2excel.js" type="text/javascript"></script>
<script type="text/javascript">
	function myFunction() 
	{
		var htmltable= document.getElementById('tblCustomers');
		var html = htmltable.outerHTML;
		window.open('data:application/vnd.ms-excel,' + encodeURIComponent(html));
	} 
	function salesPrint()
	{
		var table=document.getElementById("tblCustomers");
		 newWin=window.open("");
		 newWin.document.write("<html><head><link rel='stylesheet' type='text/css' href='bootstrap/css/table.css'/></head> <body>");
		// newWin.document.write($('#tblCustomers').html());
		 newWin.document.write(table.outerHTML);
		 newWin.document.write("</body></html>");
		 newWin.print();
		 newWin.close();
		 //window.print();
		
	}
	function ajx()
{	var x_value=$("#month").val();
	//alert(x_value);
    $.ajax({
        url:'ajx.php',
        data:{month:x_value},
        type: 'post',
        success : function(resp){
            $("#tblCustomers").html(resp);               
        },
        error : function(resp){}
    });}
</script>

  </head>
  <body>
  <div class="main-menu>
  <div class="area"></div><nav class="main-menu">
		<ul>
            <li><a href="index.php">
			<i class="fa fa-home fa-2x"></i>
            <span class="nav-text">Billing</span>
            </a>
            </li>
			<li class="has-subnav">
                <a href="dashboardpurchase.php">
                <i class="fa fa-laptop fa-2x"></i>
                <span class="nav-text">Purchase</span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardsales.php">
                <i class="fa fa-list fa-2x"></i>
                <span class="nav-text">Sales</span>
                </a>
            </li>
			<li>
                <a href="dashboardproduct.php">
                    <i class="fa fa-bar-chart-o fa-2x"></i>
                    <span class="nav-text">
                    Add Product 
                    </span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardstock.php">
                <i class="fa fa-folder-open fa-2x"></i>
                <span class="nav-text">Stocks Report</span>
                </a>
            </li>
          
            <li>
                <a href="salesReport.php">
                <i class="fa fa-font fa-2x"></i>
                <span class="nav-text">Sales Report</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Tables</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-map-marker fa-2x"></i>
                <span class="nav-text">Maps</span>
                </a>
            </li>
            <li>
				<a href="#">
                <i class="fa fa-info fa-2x"></i>
                <span class="nav-text">Documentation</span>
                </a>
            </li>
        </ul>
        <ul class="logout">
			<li>
			<a href="#">
            <i class="fa fa-power-off fa-2x"></i>
            <span class="nav-text">Logout</span>
            </a>
			</li>  
        </ul>
    </nav>	
 <div class="container">
 <article>
	<h3>Sales Report</h3>
	<div class="row">&nbsp;</div>
		<div class="row" >
			<div class="col-md-12">
				<div class="search-container" >
				<p></p>
	 					<form action="salesReport.php" method="post">
						<!--<input type='text' align='right' id="search" name="search" placeholder='Search..' name='search'>
						<input type='submit' align='right' name="Search" value="Search" formaction="salesReport.php"><i class='fa fa-search'></i></input> -->
						<label><strong>From Date&nbsp;&nbsp;</strong></label><input type="date" value="<?php echo date('Y-m-d'); ?>" name="fromdate" id="fromdate" >
						&nbsp;&nbsp;<label><strong>To Date&nbsp;&nbsp;</strong></label><input type="date" name="todate" value="<?php echo date('Y-m-d'); ?>" id="todate" >
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" id="gReport" name="gReport" formaction="salesReport.php" value="Generate Report">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<strong>OR Select Month </strong> <select name="month" id="month" onclick="ajx()">
							<option value="1">Jan</option>
							<option value="2">Feb</option>
							<option value="3">March</option>
							<option value="4">April</option>
							<option value="5">May</option>
							<option value="6">June</option>
							<option value="7">Jully</option>
							<option value="8">Aug</option>
							<option value="9">Sep</option>
							<option value="10">Oct</option>
							<option value="11">Nov</option>
							<option value="12">Dec</option>
						</select>
						
					</form>
				<p></p>
				</div>
			</div>
		</div>
	<div class="row">
	<div class="col-md-12">
	<?php          
		include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect();
		$query = "SELECT * FROM sales ORDER BY salesid ASC";
		$total_results = $DbFunction->getNorows($query);
		$per_page = 10;
		$fromdate=$_POST['fromdate'];
		$todate=$_POST['todate'];
		$month=$_POST['month'];
		$total_pages = ceil($total_results / $per_page);
		if (isset($_GET['page']) && is_numeric($_GET['page']))
        {
                $show_page = $_GET['page'];
                // make sure the $show_page value is valid
                if ($show_page > 0 && $show_page <= $total_pages)
                {
                        $start = ($show_page -1) * $per_page;
                        $end = $start + $per_page; 
                }
                else
                {
                // error - show first set of results
                  echo      $start = 0;
                  echo      $end = $per_page; 
                }               
        }
        else
        {
                // if page isn't set, show first set of results
                $start = 0;
                $end = $per_page; 
        }
		$_POST['gReport'];
	
		if (isset($_POST['gReport'])=='Generate Report')
		{
			$result=$DbFunction->getData("SELECT * FROM sales WHERE salesDate BETWEEN '$fromdate'  AND '$todate' ");
		}
		 else{
			$result = $DbFunction->getData("SELECT * FROM sales ORDER BY salesid ASC Limit $start, $per_page" );
		 }		
		echo "<div><table id='tblCustomers' align='center'  class='table table-responsive' cellpadding='0.5' border-spacing: 1px; style='border-collapse: collapse;'>";
		echo '<tr><td colspan="12" align="center">Form '.$fromdate.' To '.$todate .' Report </td></tr><tr> <th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF; text-align: center; ">Sr.No.</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Bill No</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Sales Date</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Customer Name</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product<br>Name</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item<br>Name</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Qty</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discount %</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discount Amt<br>Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Grand<br>Total</th>
		</tr>';
		$start = $start + 1;
		// loop through results of database query, displaying them in the table 
		$totalsale=0;
        for ($i = $start; $i < $end; $i++)
        {
        // make sure that PHP doesn't try to show results that don't exist
            if ($i == $total_results) { break; }		
			foreach ($result as $res) 
			{
				$salesid = $res['salesid'];
				$salesbillno = $res['salesbillno'];
				$salesDate= $res['salesDate'];
				$customername = $res['customername'];
				$venderinoviceno=$res['venderinoviceno'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$itemprice=$res['itemprice'];
				$itemquantity=$res['itemquantity'];
				$total=$res['total']; 
				$discpercentage=$res['discpercentage'];
				$discontotal=$res['discontotal'];
				$grandtotal=$res['grandtotal']; 		  
				$totalsale =$totalsale+$grandtotal; 	
		
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $salesbillno . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $salesDate . '</td>';
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $customername . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
				if($itemquantity<=5)
				{	echo '<td style="padding: 0.5PX;border: 0.5PX solid ;"><font color="red">' . $itemquantity . '</font></td>';
				}else
				{
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
				}
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $total . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discpercentage . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discontotal . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $grandtotal . '</td>';
				echo '</tr>';
				
				$i = $i + 1;	
			}
			if ( $i > $rows ) 
			{
				break;	
			} 
		}
		echo "<tr><td colspan='12' align='right'>Total =".$totalsale. "</td></tr>";
		echo "</table></div>";
?>
		</div>
		</div>
		</div>
		<?php 
			echo "<div align='center'>";      
			echo "<p><b>View Page Wise:</b> ";
			for ($i = 1; $i <= $total_pages; $i++)
			{
                echo "<a id = 'anchortag' href='salesReport.php?page=$i'>$i</a> ";
			}
	?>	
		<button onclick='myFunction()'>Excel</button>
		<button name="Print" onclick="salesPrint()">Print</button>
		
  </article>
 </div>
 </div>
 </body>
</html>