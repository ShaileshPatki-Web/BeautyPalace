<?php

		if(isset($_POST['EditSubmit']) == 'EditSubmit')
		{	

			include_once("classes/DbFunction.php");
			
			$DbFunction = new DbFunction();
			
			$conn = $DbFunction->myconnect();		
			
			$salesbillno=$_POST['salesbillno'];
			$insert_salesbillno = implode(",", $salesbillno); 
			$str_arr_salesbillno = explode (",", $insert_salesbillno);  
			$salesbillno = $insert_salesbillno;
			
			$query="INSERT INTO tempsales(salesbillno, salesDate, customername, productname, itemname, productcode, itemprice, itemquantity, total, discpercentage, discontotal, grandtotal )\n 
			SELECT salesbillno, salesDate, customername, productname, itemname, productcode, itemprice, itemquantity, total, discpercentage, discontotal, grandtotal FROM sales WHERE salesbillno = '$salesbillno'  ORDER BY salesid ASC";
			
			$result = $DbFunction->execute($query);
			
			header("Location: index.php");

		}

	

	if(isset($_POST['FinalSubmitSave']) == 'FinalSubmitSave') {
						 
		 $salesid = $_POST['salesid'];
		 $salesid = ($salesid - 1);
		 
		 $salesbillno=$_POST['salesbillno'];
		 $insert_salesbillno = implode(",", $salesbillno); 
		 $str_arr_salesbillno = explode (",", $insert_salesbillno);  
		 $salesbillno = $insert_salesbillno;

		 
		 $salesDate = $_POST['salesDate'];
		 $customername = $_POST['customername'];					 
		 $productname = $_POST['productname'];
		 $productcode = $_POST['productcode'];
		 $itemname = $_POST['itemname'];
		 $discontotal = $_POST['discontotal'];
		 $itemprice = $_POST['itemprice'];
		 $sellingprice = $_POST['sellingprice']; 
		 $itemquantity = $_POST['itemquantity'];
		 $discpercentage = $_POST['discpercentage'];
		 
		 
		 include_once("classes/DbFunction.php");

		 $DbFunction = new DbFunction();

		 $conn = $DbFunction->myconnect(); 
		
		 $salesbillno = $salesbillno;
		 $total = ($itemprice * $itemquantity);
		
		 $discontotal = (($total * $discpercentage) / 100);					
		 $discontotal = number_format($discontotal,2);
		
		 $grandtotal = ($total - $discontotal);
		 $grandtotal = number_format($grandtotal,2);

		 $intinsert = "UPDATE  sales SET salesbillno='$salesbillno', salesDate = '$salesDate', customername='$customername',productname='$productname',productcode='$productcode',itemname='$itemname', itemprice='$itemprice',itemquantity='$itemquantity',total='$total', discpercentage='$discpercentage',discontotal='$discontotal',grandtotal='$grandtotal' WHERE salesid='$salesid'";
		
		 $result = $DbFunction->execute($intinsert);
		
		 header("Location: index.php");	
		
	}
					
?>