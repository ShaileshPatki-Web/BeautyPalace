-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 30, 2019 at 06:23 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `beautypalace`
--

-- --------------------------------------------------------

--
-- Table structure for table `mpurchase`
--

CREATE TABLE IF NOT EXISTS `mpurchase` (
  `purchaseid` int(11) NOT NULL AUTO_INCREMENT,
  `productname` varchar(500) NOT NULL,
  `itemname` varchar(500) NOT NULL,
  `productcode` varchar(100) NOT NULL,
  `productprice` varchar(500) NOT NULL,
  `sellingprice` varchar(500) NOT NULL,
  PRIMARY KEY (`purchaseid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `mpurchase`
--

INSERT INTO `mpurchase` (`purchaseid`, `productname`, `itemname`, `productcode`, `productprice`, `sellingprice`) VALUES
(1, 'Bags', 'Office Bags for Laptop', 'BO1', '370', '390'),
(2, 'Jewellery', 'Imitation Jewellery', 'JI2', '245', '270'),
(3, 'Perfume', 'Rose Perfume', 'PR3', '165', '190'),
(4, 'Cosmetics', 'Vatika Herbal Shampoo', 'CV4', '140', '170'),
(5, 'Cosmetics', 'Herbal Cream', 'CH5', '125', '140'),
(6, 'Jewellery', 'Golden Chain', 'JG6', '28500', '29700'),
(7, 'Bags', 'Mobile Accessories', 'CM7', '315', '340'),
(8, 'Perfume', 'Ladies Jasmine Perfume', 'PJ8', '185', '210'),
(9, 'Bags', 'Mobile Accessories Bags', 'BM9', '425', '540'),
(10, 'Perfume', 'Perfume for Men', 'PP10', '185', '225'),
(11, 'Jewellery', 'Gems in Ring', 'JG11', '245', '278'),
(12, 'Cosmetics', 'Winter Creams', 'CW12', '95', '110'),
(13, 'Bags', 'Office Bags', 'BO13', '140', '190'),
(14, 'Bags', 'Bags for Accessories', 'BB14', '185', '230'),
(15, 'Perfume', 'Jasmine Fragrance Perfume', 'PJ15', '235', '285'),
(16, 'Cosmetics', 'Anfrench Remover', 'CA16', '180', '190'),
(17, 'Perfume', 'Jasmin fragrance', 'PR2', '200', '400'),
(19, 'Bags', 'Purse for Women', 'BP41', '200', '250'),
(18, 'Bags', 'Ladies Purse', 'BL40', '680', '800'),
(20, 'Jewellery', 'Earring', 'JE42', '40', '100'),
(21, 'Jewellery', 'Bengals', 'JB43', '40', '100'),
(22, 'Bags', 'Office Bags for Tiffen', 'BO13', '310', '340'),
(23, 'Bags', 'Carry Bag', 'BO1', '445', '470'),
(24, 'Perfume', 'Jasmine Perfume', 'PJ8', '330', '340'),
(27, 'Mobile', 'LG Mobile', 'ML27', '5000', '5500'),
(26, 'Bags', 'Polythin Bag', 'BP26', '8', '10'),
(28, 'Mobile', 'Motorollo Mobile', 'MM28', '9000', '9500'),
(29, 'Cosmetics', 'Vicco Turmeric Cream', 'CV29', '35', '48'),
(30, 'Mobile', 'Samsung Galaxy - 350', 'MS30', '8500', '8700');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE IF NOT EXISTS `purchase` (
  `purchaseid` int(11) NOT NULL AUTO_INCREMENT,
  `purchasebillno` varchar(100) NOT NULL,
  `purchaseDate` date NOT NULL,
  `vendorname` varchar(300) NOT NULL,
  `venderinoviceno` varchar(100) NOT NULL,
  `productname` varchar(500) NOT NULL,
  `productcode` varchar(100) NOT NULL,
  `itemname` varchar(500) NOT NULL,
  `itemprice` varchar(10) NOT NULL,
  `sellingprice` varchar(10) NOT NULL,
  `actualitemqty` varchar(10) NOT NULL,
  `itemquantity` varchar(10) NOT NULL,
  `updateqty` varchar(10) NOT NULL,
  `total` varchar(10) NOT NULL,
  `gstpercentage` varchar(10) NOT NULL,
  `gstontotal` varchar(10) NOT NULL,
  `grandtotal` varchar(100) NOT NULL,
  PRIMARY KEY (`purchaseid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchaseid`, `purchasebillno`, `purchaseDate`, `vendorname`, `venderinoviceno`, `productname`, `productcode`, `itemname`, `itemprice`, `sellingprice`, `actualitemqty`, `itemquantity`, `updateqty`, `total`, `gstpercentage`, `gstontotal`, `grandtotal`) VALUES
(1, '1', '2019-12-24', 'Lenova Mobile Shopee, Aurangabad', '1011', 'Cosmetics', 'CH5', 'Herbal Cream', '445', '470', '70', '50', '', '8900', '18', '1602', '10,502.00'),
(2, '2', '2019-12-24', 'Samsung Osmanpura Showroom, Aurangabad', '1012', 'Bags', 'BO1', 'Office Bags for Laptop', '310', '370', '80', '61', '', '21700', '18', '3906', '25,606.00'),
(3, '3', '2019-12-25', 'Vivo Showroom @ Trimurti Chowk', '1013', 'Mobile', 'MS30', 'Samsung Galaxy - 350', '8500', '8700', '90', '64', '10', '255000', '18', '45900', '300,900.00'),
(6, '6', '2019-12-30', 'Samsung Osmanpura Showroom, Aurangabad', '1006', 'Jewellery', 'JI2', 'Imitation Jewellery', '310', '330', '20', '20', '', '6200', '18', '1116', '7,316.00'),
(4, '4', '2019-12-30', 'Pearl Beauty Parlor', '1004', 'Perfume', 'PP4', 'Perfume for Ladies', '110', '130', '70', '70', '', '7700', '3', '231', '7,931.00'),
(5, '5', '2019-12-30', 'Sai Mineral Water Suppliers', '1005', 'Bags', 'BM5', 'Mineral Water Cartrej', '375', '385', '10', '10', '', '3750', '18', '675', '4,425.00'),
(7, '7', '2019-12-30', 'Samsung Showroom @ Trimurti Chowk', '1007', 'Mobile', 'MS30', 'Samsung Galaxy - 350', '8300', '8500', '20', '20', '', '166000', '18', '29880', '195,880.00');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `salesid` int(10) NOT NULL AUTO_INCREMENT,
  `salesbillno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `salesDate` date NOT NULL,
  `customername` varchar(300) CHARACTER SET latin1 NOT NULL,
  `productname` varchar(300) CHARACTER SET latin1 NOT NULL,
  `itemname` varchar(300) CHARACTER SET latin1 NOT NULL,
  `productcode` varchar(100) CHARACTER SET latin1 NOT NULL,
  `itemprice` varchar(10) CHARACTER SET latin1 NOT NULL,
  `itemquantity` varchar(10) CHARACTER SET latin1 NOT NULL,
  `total` varchar(10) CHARACTER SET latin1 NOT NULL,
  `discpercentage` varchar(10) CHARACTER SET latin1 NOT NULL,
  `discontotal` varchar(10) CHARACTER SET latin1 NOT NULL,
  `grandtotal` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`salesid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`salesid`, `salesbillno`, `salesDate`, `customername`, `productname`, `itemname`, `productcode`, `itemprice`, `itemquantity`, `total`, `discpercentage`, `discontotal`, `grandtotal`) VALUES
(1, '1', '2019-12-25', 'Deve Dnyneshwar', 'Bags', 'Office Bags for Laptop', 'BO1', '330', '7', '2310', '18', '415.80', '1,894.20'),
(2, '1', '2019-12-24', 'Deve Dnyneshwar', 'Cosmetics', 'Vatika Herbal Shampoo', 'CV4', '330', '20', '6600', '18', '1188', '5412'),
(3, '1', '2019-12-24', 'Deve Dnyneshwar', 'Bags', 'Office Bags for Laptop', 'BO1', '340', '10', '3400', '18', '612', '2788'),
(4, '2', '2019-12-25', 'Dipika Sherma', 'Mobile', 'Samsung Galaxy - 350', 'MS30', '290', '7', '2030', '18', '365.40', '1,664.60'),
(5, '2', '2019-12-24', 'Dipika Sherma', 'Bags', 'Office Bags', 'BO13', '378', '20', '7560', '10', '756', '6804'),
(6, '2', '2019-12-24', 'Dipika Sherma', 'Cosmetics', 'Herbal Cream', 'CH5', '340', '10', '3400', '18', '612', '2788'),
(7, '3', '2019-12-28', 'Deve Dnyneshwar', 'Cosmetics', 'Herbal Cream', 'CH5', '340', '10', '3400', '18', '612', '2788'),
(8, '4', '2019-12-26', 'Hameed Shaikh', 'Mobile', 'Samsung Galaxy - 350', 'MS30', '8200', '2', '16400', '18', '2952', '13448'),
(9, '4', '2019-12-26', 'Hameed Shaikh', 'Cosmetics', 'Herbal Cream', 'CH5', '340', '3', '1020', '18', '183.6', '836.4'),
(10, '4', '2019-12-26', 'Hameed Shaikh', 'Bags', 'Office Bags for Laptop', 'BO1', '470', '4', '1880', '18', '338.4', '1541.6'),
(11, '4', '2019-12-28', 'Hameed Shaikh', 'Bags', 'Mobile Accessories', 'CM7', '370', '3', '1110', '10', '111', '999'),
(12, '4', '2019-12-26', 'Hameed Shaikh', 'Mobile', 'Samsung Galaxy - 350', 'MS30', '8200', '3', '24600', '18', '4428', '20172'),
(13, '4', '2019-12-26', 'Hameed Shaikh', 'Cosmetics', 'Herbal Cream', 'CH5', '340', '2', '680', '18', '122.4', '557.6'),
(14, '4', '2019-12-26', 'Hameed Shaikh', 'Bags', 'Office Bags for Laptop', 'BO1', '470', '5', '2350', '18', '423', '1927'),
(15, '4', '2019-12-28', 'Hameed Shaikh', 'Bags', 'Mobile Accessories', 'CM7', '370', '3', '1110', '10', '111', '999'),
(16, '5', '2019-12-30', 'Hameed Shaikh', 'Bags', 'Mobile Accessories Bags', 'BM9', '370', '30', '11100', '18', '1998', '9102'),
(17, '5', '2019-12-30', 'Hameed Shaikh', 'Cosmetics', 'Winter Creams', 'CW12', '110', '10', '1100', '5', '55', '1045'),
(18, '5', '2019-12-30', 'Hameed Shaikh', 'Mobile', 'Samsung Galaxy - 350', 'MS30', '7800', '10', '78000', '18', '14040', '63960');

-- --------------------------------------------------------

--
-- Table structure for table `sales1`
--

CREATE TABLE IF NOT EXISTS `sales1` (
  `salesid` int(10) NOT NULL AUTO_INCREMENT,
  `salesbillno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `salesDate` date NOT NULL,
  `customername` varchar(300) CHARACTER SET latin1 NOT NULL,
  `productname` varchar(300) CHARACTER SET latin1 NOT NULL,
  `itemname` varchar(300) CHARACTER SET latin1 NOT NULL,
  `productcode` varchar(100) CHARACTER SET latin1 NOT NULL,
  `itemprice` varchar(10) CHARACTER SET latin1 NOT NULL,
  `itemquantity` varchar(10) CHARACTER SET latin1 NOT NULL,
  `total` varchar(10) CHARACTER SET latin1 NOT NULL,
  `discpercentage` varchar(10) CHARACTER SET latin1 NOT NULL,
  `discontotal` varchar(10) CHARACTER SET latin1 NOT NULL,
  `grandtotal` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`salesid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `sales1`
--

INSERT INTO `sales1` (`salesid`, `salesbillno`, `salesDate`, `customername`, `productname`, `itemname`, `productcode`, `itemprice`, `itemquantity`, `total`, `discpercentage`, `discontotal`, `grandtotal`) VALUES
(1, '1', '2019-12-25', 'Deve Dnyneshwar', 'Bags', 'Office Bags for Laptop', 'BO1', '330', '7', '2310', '18', '415.80', '1,894.20'),
(2, '1', '2019-12-24', 'Deve Dnyneshwar', 'Cosmetics', 'Vatika Herbal Shampoo', 'CV4', '330', '20', '6600', '18', '1188', '5412'),
(3, '1', '2019-12-24', 'Deve Dnyneshwar', 'Bags', 'Office Bags for Laptop', 'BO1', '340', '10', '3400', '18', '612', '2788'),
(4, '2', '2019-12-25', 'Dipika Sherma', 'Mobile', 'Samsung Galaxy - 350', 'MS30', '290', '7', '2030', '18', '365.40', '1,664.60'),
(5, '2', '2019-12-24', 'Dipika Sherma', 'Bags', 'Office Bags', 'BO13', '378', '20', '7560', '10', '756', '6804'),
(6, '2', '2019-12-24', 'Dipika Sherma', 'Cosmetics', 'Herbal Cream', 'CH5', '340', '10', '3400', '18', '612', '2788'),
(7, '3', '2019-12-28', 'Deve Dnyneshwar', 'Cosmetics', 'Herbal Cream', 'CH5', '340', '10', '3400', '18', '612', '2788'),
(8, '4', '2019-12-26', 'Hameed Shaikh', 'Mobile', 'Samsung Galaxy - 350', 'MS30', '8200', '2', '16400', '18', '2952', '13448'),
(9, '4', '2019-12-26', 'Hameed Shaikh', 'Cosmetics', 'Herbal Cream', 'CH5', '340', '3', '1020', '18', '183.6', '836.4'),
(10, '4', '2019-12-26', 'Hameed Shaikh', 'Bags', 'Office Bags for Laptop', 'BO1', '470', '4', '1880', '18', '338.4', '1541.6'),
(11, '4', '2019-12-28', 'Hameed Shaikh', 'Bags', 'Mobile Accessories', 'CM7', '370', '3', '1110', '10', '111', '999'),
(12, '4', '2019-12-26', 'Hameed Shaikh', 'Mobile', 'Samsung Galaxy - 350', 'MS30', '8200', '3', '24600', '18', '4428', '20172'),
(13, '4', '2019-12-26', 'Hameed Shaikh', 'Cosmetics', 'Herbal Cream', 'CH5', '340', '2', '680', '18', '122.4', '557.6'),
(14, '4', '2019-12-26', 'Hameed Shaikh', 'Bags', 'Office Bags for Laptop', 'BO1', '470', '5', '2350', '18', '423', '1927'),
(15, '4', '2019-12-28', 'Hameed Shaikh', 'Bags', 'Mobile Accessories', 'CM7', '370', '3', '1110', '10', '111', '999'),
(16, '5', '2019-12-30', 'Hameed Shaikh', 'Bags', 'Mobile Accessories Bags', 'BM9', '370', '30', '11100', '18', '1998', '9102'),
(17, '5', '2019-12-30', 'Hameed Shaikh', 'Cosmetics', 'Winter Creams', 'CW12', '110', '10', '1100', '5', '55', '1045'),
(18, '5', '2019-12-30', 'Hameed Shaikh', 'Mobile', 'Samsung Galaxy - 350', 'MS30', '7800', '10', '78000', '18', '14040', '63960');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `purchaseid` int(11) NOT NULL AUTO_INCREMENT,
  `purchasebillno` varchar(100) NOT NULL,
  `purchaseDate` date NOT NULL,
  `vendorname` varchar(300) NOT NULL,
  `venderinoviceno` varchar(100) NOT NULL,
  `productname` varchar(500) NOT NULL,
  `productcode` varchar(100) NOT NULL,
  `itemname` varchar(500) NOT NULL,
  `itemprice` varchar(10) NOT NULL,
  `sellingprice` varchar(10) NOT NULL,
  `actualitemqty` varchar(10) NOT NULL,
  `itemquantity` varchar(10) NOT NULL,
  `updateqty` varchar(10) NOT NULL,
  `total` varchar(10) NOT NULL,
  `gstpercentage` varchar(10) NOT NULL,
  `gstontotal` varchar(10) NOT NULL,
  `grandtotal` varchar(100) NOT NULL,
  PRIMARY KEY (`purchaseid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`purchaseid`, `purchasebillno`, `purchaseDate`, `vendorname`, `venderinoviceno`, `productname`, `productcode`, `itemname`, `itemprice`, `sellingprice`, `actualitemqty`, `itemquantity`, `updateqty`, `total`, `gstpercentage`, `gstontotal`, `grandtotal`) VALUES
(1, '', '0000-00-00', 'Sai Mineral Water Suppliers', '1005', 'Bags', 'BM5', 'Mineral Water Cartrej', '375', '385', '10', '10', '', '', '', '', ''),
(2, '', '0000-00-00', 'Samsung Osmanpura Showroom, Aurangabad', '1006', 'Jewellery', 'JI2', 'Imitation Jewellery', '310', '330', '20', '20', '', '', '', '', ''),
(3, '', '0000-00-00', 'Lenova Mobile Shopee, Aurangabad', '1011', 'Cosmetics', 'CH5', 'Herbal Cream', '445', '470', '70', '50', '', '', '', '', ''),
(4, '', '0000-00-00', 'Samsung Osmanpura Showroom, Aurangabad', '1012', 'Bags', 'BO1', 'Office Bags for Laptop', '310', '370', '80', '61', '', '', '', '', ''),
(5, '', '0000-00-00', 'Pearl Beauty Parlor', '1004', 'Perfume', 'PP4', 'Perfume for Ladies', '110', '130', '70', '70', '', '', '', '', ''),
(6, '', '0000-00-00', 'Vivo Showroom @ Trimurti Chowk', '1013', 'Mobile', 'MS30', 'Samsung Galaxy - 350', '8500', '8700', '90', '84', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tempsales`
--

CREATE TABLE IF NOT EXISTS `tempsales` (
  `salesid` int(10) NOT NULL AUTO_INCREMENT,
  `salesbillno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `salesDate` date NOT NULL,
  `customername` varchar(300) CHARACTER SET latin1 NOT NULL,
  `productname` varchar(300) CHARACTER SET latin1 NOT NULL,
  `itemname` varchar(300) CHARACTER SET latin1 NOT NULL,
  `productcode` varchar(100) CHARACTER SET latin1 NOT NULL,
  `itemprice` varchar(10) CHARACTER SET latin1 NOT NULL,
  `itemquantity` varchar(10) CHARACTER SET latin1 NOT NULL,
  `total` varchar(10) CHARACTER SET latin1 NOT NULL,
  `discpercentage` varchar(10) CHARACTER SET latin1 NOT NULL,
  `discontotal` varchar(10) CHARACTER SET latin1 NOT NULL,
  `grandtotal` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`salesid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tempsales`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
