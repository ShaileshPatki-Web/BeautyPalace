<?php
	
  		 // get form data, making sure it is valid
		
		include_once("classes/DbFunction.php");
		
		$DbFunction = new DbFunction();
		
		$conn = $DbFunction->myconnect();
		
		$work_srno = $_POST['getid'];		
		
		$purchasebillno = $_POST['purchasebillno'];
		$vendorname = $_POST['vendorname'];
		$venderinoviceno = $_POST['venderinoviceno'];
		$productname = $_POST['productname'];
		
		$itemname = $_POST['itemname'];
		$insert_itemname= implode(",", $itemname); // echo	
		$str_arr1_itemname = explode (",", $insert_itemname);
		
		$productcode = $_POST['productcode'];
		$itemprice = $_POST['itemprice'];
		$sellingprice=$_POST['sellingprice'];
		$itemquantity = $_POST['itemquantity'];
		$total = $_POST['total'];
		$gstpercentage = $_POST['gstpercentage'];
		$gstontotal = $_POST['gstontotal']; 
		$grandtotal = $_POST['grandtotal'];
		
  		
		$total = ($itemprice * $itemquantity);
		
		$gstontotal = (($total * $gstpercentage) / 100);
		
		$grandtotal = ($total + $gstontotal);
		
		$grandtotal = number_format($grandtotal,2);
		
		$data = array
				(array(					
			
			'productname' => $insert_productname,
			'itemname' => $insert_itemname,

			'sellingprice' => $insert_sellingprice,
			'itemquantity' => $insert_itemquantity,
			'gstpercentage' => $insert_gstpercentage,
			
			));					

			foreach($data as $x => $val) {
					 "$x = $val<br>";
			}
			
			function Counting($data){ 
					
			$count = 0;
			
			foreach( $data as $datacount){
				$count += count( $datacount);
				
			}
			
			return ($count);
			} 
							
			$countarray = Counting($str_arr1_itemname);
				
			//print_r($data);	
			
			for($i=0; $i < $countarray; $i++) {		

			 $itemname = $str_arr1_itemname[$i];
			
			if(!empty($itemname)) {
				
				 $sql="SELECT * FROM mpurchase WHERE itemname = '$itemname'";

				$result = $DbFunction->getData($sql);
				
				foreach ($result as $res) {
			
					$productcode = $res['productcode'];
				
				}
			}
		
		$query1 ="UPDATE  purchase SET vendorname='$vendorname',venderinoviceno='$venderinoviceno', productname='$productname',productcode='$productcode',itemname='$itemname', itemprice='$itemprice',sellingprice='$sellingprice', itemquantity='$itemquantity',total='$total', gstpercentage='$gstpercentage',gstontotal='$gstontotal',grandtotal='$grandtotal' WHERE 	purchaseid='$work_srno'";
		
		$result = $DbFunction->execute($query1);

		$update1 = "UPDATE purchase SET purchasebillno = purchaseid";
		
		$result1 = $DbFunction->execute($update1);		
		
		header("Location: dashboardpurchase.php");
	}
?>