<html>
<head>
<script type="text/javascript">
$('#category').change(function(){
var cat_id=$('#category').val();
$('#sub-category').empty();
$.get('ddck.php',{'cat_id':cat_id},function(return_data){
	$.each(return_data.data, function(key,value){
$("#sub-category").append("

<option value=" + value.subcat_id +">"+value.subcategory+"</option>

");
});
}, "json");
$('#category').change(function(){
//var st=$('#category option:selected').text();
var cat_id=$('#category').val();
$('#sub-category').empty(); //remove all existing options
///////
$.get('ddck.php',{'cat_id':cat_id},function(return_data){
	if(return_data.data.length>0){
	$('#msg').html( return_data.data.length + ' records Found');
$.each(return_data.data, function(key,value){
$("#sub-category").append("<option value='"+value.subcat_id+"'>"+value.subcategory+"</option>");
});
}else{
$('#msg').html('No records Found');
}
}, "json");
///////
});
</script>

</head>
<body>

<form method=post action=dd-submit.php>
<select name=category id=category>
<option value='' selected>Select</option>
<?Php
require "config.php";// connection to database 
$sql="select * from dd2_category "; // Query to collect data 

foreach ($dbo->query($sql) as $row) {
echo "<option value=$row[cat_id]>$row[category]</option>";
}
?>
</select>
<select name=sub-category id=sub-category>
</select>
<input type=submit value=Submit></form>
</body>
</html>