<?php
		session_start();
		$salesid =  $_GET['id'];		
		include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect();	
		$intinsert = "DELETE  From tempsales WHERE salesid='$salesid'";
		$result = $DbFunction->execute($intinsert);					
		header("Location: index.php");
?>