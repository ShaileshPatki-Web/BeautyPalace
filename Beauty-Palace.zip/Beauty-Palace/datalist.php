<!DOCTYPE html>
<html>
<body>

<form action="/action_page.php" method="post" autocomplete="on">
  <input list="browsers" name="browsers">
  <datalist id="browsers">
    <option value="Internet Explorer">
    <option value="Firefox">
    <option value="Chrome">
    <option value="Opera">
    <option value="Safari">
  </datalist>
  <input type="submit">
</form>

<p><strong>Note:</strong> The datalist tag is not supported in Internet Explorer 9 and earlier versions, or in Safari 12.0 and earlier versions.</p>

</body>
</html>
