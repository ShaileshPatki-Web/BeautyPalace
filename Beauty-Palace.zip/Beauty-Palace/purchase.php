<html>
  <head>
  <center><h1>BEAUTY PALACE - Purchase</h1></center>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

  </head>
  <body>
  <div class="main-menu>
  
  <div class="area"></div><nav class="main-menu">
  
            <ul>
                <li>
                    <a href="index.php"> 
						<i class="fa fa-home fa-2x"></i>
                        <span class="nav-text">
                            SELL
                        </span>
                    </a>
                  
                </li>
                <li class="has-subnav">
                    <a href="dashboardpurchase.php">
                        <i class="fa fa-laptop fa-2x"></i>
                        <span class="nav-text">
                            Purchase
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-list fa-2x"></i>
                        <span class="nav-text">
                           STOCK
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-folder-open fa-2x"></i>
                        <span class="nav-text">
                            Pages
                        </span>
                    </a>
                   
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-bar-chart-o fa-2x"></i>
                        <span class="nav-text">
                            Graphs and Statistics
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-font fa-2x"></i>
                        <span class="nav-text">
                           Quotes
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                       <i class="fa fa-table fa-2x"></i>
                        <span class="nav-text">
                            Tables
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                        <i class="fa fa-map-marker fa-2x"></i>
                        <span class="nav-text">
                            Maps
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa fa-info fa-2x"></i>
                        <span class="nav-text">
                            Documentation
                        </span>
                    </a>
                </li>
            </ul>

            <ul class="logout">
                <li>
                   <a href="#">
                         <i class="fa fa-power-off fa-2x"></i>
                        <span class="nav-text">
                            Logout
                        </span>
                    </a>
                </li>  
            </ul>
        </nav>
 <div class="container">
 <article>
		<h3 align="left">PURCHASE</h3>
		<div class="row">&nbsp;</div>
	 <div class="row">
	 <div class="col-sm-8">
	<table  width="350" align="LEFT" > 
            <form name="salesbill" align="LEFT" action="purchasebill.php"  method="post">
            <td width="100">
                <tr>
                    <td width="100">&nbsp;</td></tr>
                <tr>
					<td align="left">Purchase Bill Number </td>
					<td><label>
						<input type="text" autofocus name="salesbillno" />
					</label></td>
                </tr>
                <tr>
					<td width="100">&nbsp;</td>
                <tr>
					<td align="left">Vendor Name </td>
                    <td><label>
						<input type="text" autofocus name="vendorname" />					
					    </label></td>
				</tr>  
				 <tr>
					<td width="100">&nbsp;</td>
                <tr>
				<tr>
                      <td align="left">Invoice Number </td>
                      <td><label>
                        <input type="text" autofocus name="venderinoviceno" />
                      </label></td>
                    </tr>     
                <tr>
                    <td width="100">&nbsp;</td>
				</tr>
                <tr>
                    <td align="left">Product Category </td>
                    <td><label>
					<select name="productname" value="$mproduct" width="170px">
						<?php
						include ("connect_db.php");
						$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
						if(!$con)
						{
							die ("Can't Connect");
						} 
						$query = "SELECT DISTINCT productname FROM mproduct";
						$result = mysqli_query($con, $query);				
						while($row = mysqli_fetch_array($result))
						{
							$mproduct=$row['productname'];
							echo "<option>$mproduct</option>";
						} 
						echo "</select>";
						?>
					</label></td>
                </tr>
				<tr>
				    <td>&nbsp;</td>
                </tr>
                <tr>
					<td align="left">Product Name </td>
                    <td><input type="text" name="itemname" /></td>
                </tr>
                <tr>
				    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td align="left">Product Price </td>
                    <td><input type="text" name="itemprice" /></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
				<tr>
					<td align="left">Product Quantity </td>
                    <td><input type="text" name="itemquantity" /></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>             
                <tr>
                    <td align="left">GST % </td>
                    <td><input type="text" name="gstontotal" /></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>                 	
				<tr>
                    <td>&nbsp;</td>
                    <td> 
						<input type="submit" name="AddSubmit" value="Submit" class="form-submit-button"  /> </td>
                </tr>
                <tr>
					<td>&nbsp;</td>
                </tr>
				</form>
            </table> 
	
	<?php          
	
		include_once("classes/Crud.php");
		
		$perpage = 10;
		
		if(isset($_GET["page"])){
		$page = intval($_GET["page"]);
		}
		else {
		$page = 1;
		}
		
		$calc = $perpage * $page;
		$start = $calc - $perpage;
		
		$crud = new Crud();
		
		$conn = $crud->myconnect();
		
						
		$query = "SELECT * FROM purchase ORDER BY purchaseid Desc";
		
		$rows = $crud->getNorows($query); 
		
		
		$result = $crud->getData("SELECT * FROM purchase ORDER BY purchaseid Desc Limit $start, $perpage");
		
		
		echo "<div><table align='center' height:70 width:100 class='table' cellpadding='0.5' border-spacing: 0px; style='border-collapse: collapse;'>";

		
		echo '<tr> <th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF; text-align: center; ">SrNo</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">purchasesBillNo</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">VendorrName</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Inovice No</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">ProductName</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">ItemName</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">ItemPrice</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">ItemQuantity</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">PriceTotal</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">GST%</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">GSTTotal</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">GrandTotal</th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; "><img src="update.png" href=""></th>
		<th style="border: 0.5PX solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; "><img src="del.png" href=""></th>
		
</tr>';
				
			$start = $start + 1;
			 
			for( $i = $start; $i < $calc; $i++) {		
			
			foreach ($result as $res) {
				  $purchaseid = $res['purchaseid'];
				  $purchasebillno = $res['purchasebillno'];
				  $vendorname = $res['vendorname'];
				  $venderinoviceno=$res['venderinoviceno'];
				  $productname=$res['productname'];
				  $itemname=$res['itemname']; 
				  
				  $itemprice=$res['itemprice'];
				  $itemquantity=$res['itemquantity'];
				  $total=$res['total']; 
				  
				  $gstpercentage=$res['gstpercentage'];
				  $gstontotal=$res['gstontotal'];
				  $grandtotal=$res['grandtotal']; 
				  
			 	echo '<tr> </tr>';
				echo '<tr> </tr>';
			
				echo "<tr>";
            
                echo '<td style="padding: 1PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
                echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $purchasebillno . '</td>';
                echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $vendorname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $venderinoviceno . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $total . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $gstpercentage . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $gstontotal . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $grandtotal . '</td>';
				
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="updatesalesbill.php?id=' . $salesid . '"><img src="update.png"></a></td>'; 
				
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="crud/deleteholidays.php?id=' . $id . '" onclick="return confirmDelete()"><img src="del.png"></a></td>';	
                echo "</tr>"; 
				
				$i = $i + 1;	
							
				}
				
				if ( $i > $rows ) {
				break;	
				
				} 
			}
					
		echo "</table></div>";
 
 ?>
	
	</div>
	
		
		<div class="col-sm-4">
			<iframe src="billing.php" align="center" name="bill" id="bill" width="380" height="500">
			</div>
	 	
	
	 </div>
	 
  </article>
 

 </div>

 </div>
 </body>
 </html>