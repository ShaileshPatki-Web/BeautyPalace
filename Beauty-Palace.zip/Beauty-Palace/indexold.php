<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Beauty Palace</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<center><img src="img/New_logof.jpg"></Center>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	
		<script type="text/javascript">
		
			function billPrint()
			{
				window.open("billing.php").print();
			}
			function newRow()
			{
				
				var table = document.getElementById("tbl");
				var row = table.insertRow(6);
				var cell1 = row.insertCell(0);
				var cell2 = row.insertCell(1);
				var cell3 = row.insertCell(2);
				var cell4 = row.insertCell(3);
				var cell5 = row.insertCell(4);
				var cell6 = row.insertCell(5);
				var cell7 = row.insertCell(6);				
				
				cell1.innerHTML = "<input type='text' size='20' name='producthidden[]' id='textFieldTextJS'/>";
				cell2.innerHTML = "<input type='text' size='20' name='itemname[]'/>";
				cell3.innerHTML = "<input type='text' size='20' name='productcode[]'/>";
				cell4.innerHTML = "<input type='text' size='20' name='itemprice[]'/>";
				cell5.innerHTML = "<input type='text' size='20' name='itemquantity[]'/>";	
				cell6.innerHTML = "<input type='text' size='20' name='gstpercentage[]'/>";	
				cell7.innerHTML = "<input type='button' onclick='newRow()' value='Add'/>";
				
				
			}
			
			function singleSelectChangeText() {

			document.cookie = "username1=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
			
			var selObj = document.getElementById("new_select3");
			var selValue = selObj.options[selObj.selectedIndex].text;
			
			document.getElementById("textFieldTextJS1").value = selValue;			
			
			}
			
			function singleInputChangeText() {

			
			document.cookie = "username1=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
			
						
			
			var selObj = document.getElementById("new_select3");
			var selValue = selObj.options[selObj.selectedIndex].text;
			
			//Cookies.set('username', 'selValue');
			//var uvalue = Cookies.get('username'); // => 'value'
			
			//var cvalue = Cookies.get('value');
			
			document.getElementById("textFieldTextJS1").value = selValue;			
			
			document.cookie = 'username1=textFieldTextJS1';
			
			}
			
			function fetch_select1(val)
			{
			 $.ajax({		 
			 type: 'post',
			 url: 'fetch_data_name.php',	 
			 data: {		 
			  get_option:val
			 },
			 success: function (response) {		  
			 document.getElementById("new_select1").innerHTML=response;
			 
			 }
			 });
			}
			
			function fetch_select2(val1)
				{		
				
				 $.ajax({
				 type: 'post',
				 url: 'fetch_data_itemname.php',
				 data: {
				  get_option1:val1
				 },
				  success: function (response) {		
				  document.getElementById("new_select2").innerHTML=response;
				   
				  var x = document.getElementsByClassName("exampleitemname");
				  x[0].innerHTML = response; 
					
				 }
				 });
				}
	
			function fetch_select3(val3)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_productcode.php',
			 data: {
			  get_option3:val3
			  
			 },
			 success: function (response) {		
			 
			 document.getElementById("new_select3").innerHTML=response;
			  
			 var x = document.getElementsByClassName("exampleproductcode");
			 x[0].innerHTML = response;	
			 
				
			 }
			 });
			}
						
			function fetch_select5(val5)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_sellingprice.php',
			 data: {
			  get_option5:val5
			 },
			 success: function (response) {		
			  
			  document.getElementById("new_select5").innerHTML=response;
				
			  var x = document.getElementsByClassName("examplesellingprice");
			  x[0].innerHTML = response;	
			  
			 }
			 });
			}
			
			var	sellingprice = document.getElementByClass("sellingprice");
			//value = sellingprice.value;
			document.write(sellingprice);
				
		</script>
		
		<style type="text/css">
			.box{
				color: #000;
				 margin-top: 40px;
			}
			.red{ background: #ECF0F5; }
			
		</style>
			
  </head>
  <body>
  
  <div class="main-menu>
  
  <div class="area"></div><nav class="main-menu">  
		<ul>
            <li><a href="index.php">
			<i class="fa fa-home fa-2x"></i>
            <span class="nav-text">Billing</center></span>
            </a>
            </li>
			<li class="has-subnav">
                <a href="dashboardpurchase.php">
                <i class="fa fa-laptop fa-2x"></i>
                <span class="nav-text">Purchase</span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardsales.php">
                <i class="fa fa-list fa-2x"></i>
                <span class="nav-text">Sales</span>
                </a>
            </li>
			<li>
                    <a href="dashboardproduct.php">
                        <i class="fa fa-bar-chart-o fa-2x"></i>
                        <span class="nav-text">
                           Add Product 
                        </span>
                    </a>
                </li>
            <li class="has-subnav">
                <a href="dashboardstock.php">
                 <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Stock Report</span>
                </a>
            </li>
          <li>
                <a href="salesReport.php">
                 <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Sales Report</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Tables</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-map-marker fa-2x"></i>
                <span class="nav-text">Maps</span>
                </a>
            </li>
            <li>
				<a href="documentation.php">
                <i class="fa fa-info fa-2x"></i>
                <span class="nav-text">Documentation</span>
                </a>
            </li>
        </ul>
        <ul class="logout">
			<li>
			<a href="#">
            <i class="fa fa-power-off fa-2x"></i>
            <span class="nav-text">Logout</span>
            </a>
			</li>  
        </ul>
    </nav>
	
 <div class="container">
 <article>
 <p><br/><p>
 
	<h3 align="center">Billing</h3>
		 
	<div class="col-sm-12">
	
	<?php
				
			include_once("classes/DbFunction.php");

			$DbFunction = new DbFunction();

			$conn = $DbFunction->myconnect(); 
				
			$tbl_name="sales"; // Table name 

			$sql="SELECT * FROM $tbl_name";

			$result = $DbFunction->getData($sql);

			$count = $DbFunction->getNorows($sql);
				
				
			$query = "SELECT DISTINCT salesid FROM $tbl_name ORDER BY salesid DESC Limit 1";
			
			$result1 = $DbFunction->getData($query);
			
			foreach ($result1 as $res) {
			
				 $salesid = $res['salesid'];
	  
			}
			
			$salesid = ($salesid + 1);
			
			$querytimetable = "Select * from timetable_days ORDER BY srno Asc";

			$rows = $DbFunction->getNorows($querytimetable); 		

			$resulttimetable = $DbFunction->getData("SELECT * FROM timetable_days  ORDER BY srno Asc");
			
	
			
			?>
					
	
			
			
			<?php
			/*
				foreach($_COOKIE as $key=>$value)
				{
				echo "key: ".$key.'<br />';				
				};
				
				unset($_COOKIE);
			*/
			?>
		<form name="indexForm" action="index1.php" method="post" width="100%">
		
			<table name="tbl" id="tbl"> 
				
                <tr>
					<td align="left">Bill Number :</td>
					 <td>
					
						<label><input type="text" readonly size="20"  name="salesbillno" id="salesbillno" value="<?php echo $salesid; ?>"  class='form-control detail' /></label>
						
					 </td>
                </tr>
               
                <tr>
					<td align="left">Customer Name:</td>
					
                    <td><label><input type="text" size="20" autofocus name="customername" id="customername" required value="<?php echo $_COOKIE[customername]; ?>" class='form-control detail' /></label></td>
					
				</tr>                  				 
                
				<tr><td><p></br></p></td></tr>
                <tr>
					<td align="left" width="130">Product Category </td>
					<td align="center">Item Name </td>
					<td align="center">Product Code </td>
					
					<td align="center" width="110" >Price </td>
					<td align="center">Quantity </td>
					<td align="center">Discount </td>
                </tr>               
				    
                <tr>
				
					<td>
				
				<?php 
						
					$result = $DbFunction->getData("SELECT DISTINCT productname FROM mpurchase GROUP BY productname,itemname ORDER BY productname,itemname");
					
					echo "<select name='productname[]'  onChange='fetch_select1(this.value);fetch_select2(this.value);fetch_select3(this.value);fetch_select5(this.value);' class='form-control detail'>";
					echo "<option value='$productname'>----Select---</option>";
					foreach ($result as $res) {
					
						$productname=$res['productname'];
						
						echo "<option value='$productname'>$productname</option>";
					}
					
				echo "</select>";	
				
				?>
				
				</td>
				
				<td>

				<?php 
						
					$result = $DbFunction->getData("SELECT  itemname FROM mpurchase WHERE itemname = '$itemname' AND productname = '$productname' ORDER BY itemname");
					
					echo "<select  name='itemname[]'  id='new_select2' onchange='OnSelectionChange()' class='exampleitemname form-control detail' >";
					echo "<option value='Select Item Name'>Select Item Name</option>";
					foreach ($result as $res) {
					
						echo	  $itemname=$res['itemname'];
							  
						echo "<option value='$itemname'>$itemname</option>";
					}
					
					echo "</select>";	
						
				?>	
                   
				   </td>
					
					<td>
					
					<?php 						

						$result = $DbFunction->getData("SELECT  productcode FROM mpurchase WHERE productcode = '$productcode' AND itemname = '$itemname'  ORDER BY itemname");
						
						echo "<select  name='productcode[]' onchange='singleSelectChangeText()' id='new_select3' class='exampleproductcode form-control detail' >";
						echo "<option value='Select Product Code'>Select Product Code</option>";
						foreach ($result as $res) {
						
								$productcode=$res['productcode'];
							
							echo "<option value='$productcode'>$productcode</option>";
						}
						
						echo "</select>";	
					
					?>	
					
					</td>
					<td>
					<INPUT name='sellingprice' value='<?php echo $sellingprice; ?>' class='examplesellingprice form-control detail' />
					<?php 	
					/*	
						echo "<select  name='sellingprice[]' id='new_select5'  class='examplesellingprice form-control detail'>";
						echo "<option value='Select Selling Price'>Select Selling Price</option>";
						foreach ($result as $res) {
						
									$sellingprice=$res['sellingprice'];
							
							echo "<option value='$sellingprice'>$sellingprice</option>";
						}
						
						echo "</select>";	
					*/
				?>	
					
					</td>
					
					<td><input type="text" size="20" name="itemquantity[]" id="itemquantity" required class='form-control detail' /></td>
					<td><input type="text" size="20" name="gstpercentage[]" id="gstpercentage" required class='form-control detail' /></td>
					<p>
						
					<td><input type='submit' name="SubmitSave" value='Add'/></td>				
					
					<td>
				
					</td>						
					
					</tr>					
					
					</table> 
				
				</form>
				
				
			    
				
				<form action="index1.php" method="post">
				
				<div align="center">
				
				<div align="center"><input type='submit' name="FinalSubmitSave" value='Save'/>
				<input type="submit" name="Print" value="Print" onclick="billPrint()"></div>
				<p><br/><p>
					
				</div>
				
				</form>		
				
					
				
					
				<form id="frm3" name="form3" action="fetch_data_sellingprice.php" method="POST">
			
				<input type='text' size='10' name='productcode' class='productcode' id='textFieldTextJS1'/>
					

				
										
					<input type="submit" name="SubmitPrice" value="Submit" />
					
				</form>
				
				
				</div>
		
		<div style="align:center">
		
		
		<?php  
		
        include_once("classes/DbFunction.php");
		
		$DbFunction = new DbFunction();
		
		$conn = $DbFunction->myconnect();
		
		$query = "SELECT * FROM tempsales ORDER BY salesid Desc";
		
		$total_results = $DbFunction->getNorows($query);		
		
		$per_page = 10;
	
		$total_pages = ceil($total_results / $per_page);
		
		$result = $DbFunction->getData("SELECT * FROM tempsales ORDER BY salesid Desc");
		
		$result1 = $DbFunction->getData("SELECT SUM(itemprice) AS itemprice,SUM(itemquantity) AS itemquantity,SUM(total) AS total ,SUM(discpercentage) AS discpercentage,SUM(discontotal) AS discontotal,SUM(grandtotal) AS grandtotal FROM tempsales ORDER BY salesid");
		
		
		if($result > 0 ) {
		
		echo "<div><table class='table' cellpadding='0.15' border-spacing: 1px; style='border-collapse: collapse;border-style:solid;border-width: 1px;'>";
		echo '<tr style="border-style:solid;border-width: 3px;"> <th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF; text-align: center; ">Sr. No.</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product<br>Category</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item<br>Name</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Qty</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discount</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discounted<br>Amount</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Grand<br>Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; "><img src="img/update.png"></th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; "><img src="img/del.png"></th>
		</tr>';
		
		$start =  1;
		$total_results;
		
		for ($i = $start; $i <= $total_results; $i++)
        {
          		
			foreach ($result as $res) {
				
				$salesid = $res['salesid'];
				$salesbillno = $res['salesbillno'];
				$salesDate= $res['salesDate'];
				$customername = $res['customername'];
				$venderinoviceno=$res['venderinoviceno'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$itemprice=$res['itemprice'];
				$itemquantity=$res['itemquantity'];
				$total=$res['total']; 
				$discpercentage=$res['discpercentage'];
				$discontotal=$res['discontotal'];
				$grandtotal=$res['grandtotal']; 
				
				echo '<tr> </tr>';
				echo '<tr> </tr>';
				echo "<tr style='text-align:center;'>";
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>';                
				
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $total . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discpercentage . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discontotal . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $grandtotal . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="indexupdate.php?id=' . $salesid . '"><img src="update.png"></a></td>'; 
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="deleteindexsales.php?id=' . $salesid . '" onclick="return confirmDelete()"><img src="del.png"></a></td>';	
			    echo "</tr>"; 
				$i = $i + 1;	
				}
				
			}
			
			$result1 = $DbFunction->getData("SELECT SUM(itemprice) AS itemprice,SUM(itemquantity) AS itemquantity,SUM(total) AS total ,SUM(discpercentage) AS discpercentage,SUM(discontotal) AS discontotal,SUM(grandtotal) AS grandtotal FROM tempsales ORDER BY salesid");
			
			foreach ($result1 as $row) {
									
					$salesid = $row['salesid'];
					$salesbillno = $row['salesbillno'];
					$salesDate= $row['salesDate'];
					$customername = $row['customername'];
					$venderinoviceno=$row['venderinoviceno'];
					$productname=$row['productname'];
					$itemname=$row['itemname']; 
					$itemprice=$row['itemprice'];				
					$itemquantity=$row['itemquantity'];
					$total=$row['total']; 
					$discpercentage=$row['discpercentage'];
					$discontotal=$row['discontotal'];
					$grandtotal= (($total) - ($discontotal));
					
			}	
			
			echo '<tr> </tr>';
				echo '<tr> </tr>';
				echo "<tr style='text-align:center;'>";
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">'  .'<div align="center">'.''.'</div>'. '</td>'; 
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;font-weight: bold;text-align:center;">' . Total . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . '' . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . '' . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;font-weight: bold;text-align:center;">' . $total . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . '' . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;font-weight: bold;text-align:center;">' . number_format($discontotal,2) . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;font-weight: bold;text-align:center;">' . number_format($grandtotal,2) . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><img src="update.png"></td>'; 
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><img src="del.png"></td>';	
			    echo "</tr>"; 
			
			echo "</table></div>";		
			}
		?>
		
		<!--<div class="col-sm-4">
			<iframe src="billing.php" style="display:none" align="center" name="bill" id="bill" width="380" height="500">			
			
		</div>-->
	 		
	 
	 
  </article> 

 </div> 
				
 </div>
 
 
 </body>
 </html>