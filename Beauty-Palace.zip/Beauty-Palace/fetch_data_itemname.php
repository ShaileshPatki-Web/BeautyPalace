<?php

if(isset($_POST['get_option1']))
{

	$state1 = $_POST['get_option1'];

	
	include_once("classes/DbFunction.php");
	
	$DbFunction = new DbFunction();
	
	$result = $DbFunction->getData("SELECT  itemname FROM mpurchase WHERE productname = '$state1' ORDER BY productname");
	 
		foreach ($result as $res) {
			 echo "<option>".$res['itemname']."</option>";
		
		}
		echo $res['itemname'];
		exit; 
		
}	

?>