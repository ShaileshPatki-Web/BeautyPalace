<?php

	define('DB_SERVER', 'localhost');
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', '');
	define('DB_DATABASE', 'beautypalace');
	
	$db_host="localhost";
	$db_user="root";
	$db_pass="";
	$db_name="beautypalace";

	
	$connection = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
	
	if($connection){
		
		//echo "Connected";
	}

class dbConnect 
{	
	private $host = 'localhost';
	private $username = 'root';
	private $password = '';
	private $database = 'beautypalace';
	
	protected $connection;
	
	public function __construct()
	{
		if (!isset($this->connection)) {
			
			$this->connection = new mysqli($this->host, $this->username, $this->password, $this->database);
			
			if (!$this->connection) {
				echo 'Cannot connect to database server';
				exit;
			}			
		}	
		
		return $this->connection;
	}
	
	public function myconnect($sql) {

		$con=mysqli_connect($this->host, $this->username, $this->password, $this->database);
	
		$sql = $sql;
        
		$result = mysqli_query($sql, $con) or die ("Query failed");
        
		return $result;			
		
	}	
	
}

	$host="localhost";
	$user="root";
	$passwd="";
	$dataBase="beautypalace";
	
    class dbConnect1 {
    private $host;
    private $user;
    private $passwd;
    private $dataBase;
    
    function __construct($host,$user,$passwd,$dataBase) {
        $this->host = $host;
        $this->user = $user;
        $this->passwd = $passwd;
        $this->dataBase = $dataBase;
    }
    
    function connect($sql) {
		$conn=mysqli_connect($this->host,$this->user,$this->passwd,$this->dataBase) or die (mysqli_error());
        
        echo $sql = $sql;
        $result = mysqli_query($sql, $conn) or die ("Query failed");
            return $result;
    }
}

?>