<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Tooltip - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( document ).tooltip();
  } );
  </script>
  <style>
  label {
    display: inline-block;
    width: 5em;
  }
  </style>
</head>
<body>
		
	<form id="form1" action="tooltip.php" method="post">	
	
	<input type="text" name="productname" id="productname" >
	
	
	<input type="submit" name = "Submit" />
	</form>
	<?php 	
			include_once("classes/DbFunction.php");
	
			$DbFunction = new DbFunction();

			$conn = $DbFunction->myconnect(); 
			
	echo	$productname = $_POST['productname'];
			
			$itemname = $_POST['itemname'];
			
			$result = $DbFunction->getData("SELECT  * FROM mpurchase WHERE productname = '$productname' ORDER BY itemname");

			foreach ($result as $res) {
			
				 $salesbillno = $res['salesbillno'];
				 $itemname = $res['itemname'];
			}
				

			echo '<input type="text" name="itemname" id="itemname" list="team_list">';
			
			echo "<datalist id='team_list'>";

				foreach ($result as $res) {
				
					echo	  $itemname=$res['itemname'];
						  
					echo "<option>$itemname</option>";
				}

			echo '</datalist>';
 
	?>
 
</body>
</html>