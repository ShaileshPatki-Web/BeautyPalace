<?php
			
 $salesbillno = $_POST['salesbillno'];
 $vendorname = $_POST['vendorname'];
 $venderinoviceno = $_POST['venderinoviceno'];
 $productname = $_POST['productname'];
 $itemname = $_POST['itemname'];
 $gstontotal = $_POST['gstontotal'];
 $itemprice = $_POST['itemprice']; 
 $itemquantity = $_POST['itemquantity'];
 $gstpercentage = $_POST['gstontotal'];

 if(isset($_POST['AddSubmit'])) 
 {

				include ("connect_db.php");
				
				$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
				
				if(!$con)
				{
				  die ("Can't Connect");
				} 
				
				$total = ($itemprice * $itemquantity);
				$gstontotal = (($total * $gstontotal) / 100);
				
				$gstontotal = number_format($gstontotal,2);
				
				$grandtotal = ($total + $gstontotal);
				$grandtotal = number_format($grandtotal,2);
			
				$intinsert = "INSERT into sales (salesbillno,vendorname,vendorinvoiceno,productname,itemname,itemprice,itemquantity,total,gstpercentage,gstontotal,grandtotal) VALUES ('$salesbillno','$vendorname','$venderinoviceno','$productname','$itemname','$itemprice','$itemquantity','$total','$gstpercentage','$gstontotal','$grandtotal')";
				
				$result = mysqli_query($con, $intinsert);
				$deduct= " SELECT itemquantity FROM purchase WHERE itemname = '$itemname'";
				$res = mysqli_query($con, $deduct);
				
				while($row = $res->fetch_assoc()) {
				
				$q= $row["itemquantity"];
				
				}
				
				$quantity=$q-$itemquantity;
				
				$update = "UPDATE purchase SET itemquantity=$quantity WHERE itemname='$itemname'";
				
				$rslt = mysqli_query($con, $update);

				header("Location: billing.php");  
 }
?>