<?php
 
		error_reporting("0");
		
		if (isset($_POST['SubmitSave'])) {
		
		include_once("classes/DbFunction.php");
		
		$DbFunction = new DbFunction();
		
		if ( $DbFunction->is_session_started() === FALSE ) session_start();
			
		$con = $DbFunction->myconnect();
		
		$tbl_name="sales"; // Table name ;
		
		$row_data = array();		
		
		$customername = mysqli_real_escape_string($con,($_POST['customername'][$row]));
		
		//exit($customername);
		
		$salesbillno = mysqli_real_escape_string($con,($_POST['salesbillno'][$row]));
		$customername = mysqli_real_escape_string($con,($_POST['customername'][$row]));
		$productname=mysqli_real_escape_string($con,($_POST['productname'][$row]));
		
		foreach($_POST['department1'][$row] as $row=>$productname) { 
		
		$department1=mysqli_real_escape_string($con,($_POST['department1'][$row]));
		$productname=mysqli_real_escape_string($con,($_POST['productname'][$row]));
		$itemname=mysqli_real_escape_string($con,($_POST['itemname'][$row]));
		$productcode=mysqli_real_escape_string($con,($_POST['productcode'][$row]));
		$itemprice=mysqli_real_escape_string($con,($_POST['itemprice'][$row]));
		$itemquantity=mysqli_real_escape_string($con,($_POST['itemquantity'][$row]));

			$row_data[] = "('$salesbillno','$customername','$productname', '$itemname', '$productcode', '$itemprice', '$itemquantity')";
			print_r($row_data);
		}

		if (!empty($row_data)) {	
		$sql = 'INSERT INTO  sales(salesbillno,customername,productname, itemname, productcode,itemprice,itemquantity) VALUES '.implode

			(',', $row_data);
			$result = mysqli_query($con, $sql );		
		
		}
		
		if ($result)
		echo 'Successful inserts: ' . mysqli_affected_rows($con);
		else
		echo 'query failed' ;

		header("Location: index.php");
	
		}
?>