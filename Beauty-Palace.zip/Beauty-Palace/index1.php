<?php

		error_reporting("0");
		
		if(isset($_POST['SubmitSave'])) {   //  index add to tempsales
				
		$conn = mysqli_connect('localhost','root', '','beautypalace' );
		
		include_once("classes/DbFunction.php");	
		
		$DbFunction = new DbFunction();	
		
		$conn = $DbFunction->myconnect(); 
		
		$data = array();
		
		$salesbillno=$_POST['salesbillno'];
		$insert_salesbillno = implode(",", $salesbillno); 
		$str_arr_salesbillno = explode (",", $insert_salesbillno);  
		$salesbillno = $insert_salesbillno;
		
		$salesDate=date('Y-m-d');		
		
		$customername=$_POST['customername'];	
		
		$cookie_name = "user";
		$cookie_value = $customername;
		
		setcookie(customername, $cookie_value, time() + 3600); 
		
		$_COOKIES['customername'] = $cookie_value;
		
		$cookie_name = "user1";
		$cookie_value = $salesbillno;
		
		setcookie(salesbillno, $cookie_value, time() + 3600);
	
		$_COOKIES['salesbillno'] = $cookie_value;
			
		$productname = $_POST['productname'];	// echo   print_r($productname);			
			
		$insert_productname = implode(",", $productname); 
		$str_arr_productname = explode (",", $insert_productname);  
		
		$itemname = $_POST['itemname'];
		$insert_itemname= implode(",", $itemname); 
	
		$str_arr1_itemname = explode (",", $insert_itemname);
	
		$sellingprice = $_POST['sellingprice'];
		$insert_sellingprice = implode(",", $sellingprice);  
		$str_arr1_insert_sellingprice = explode (",", $insert_sellingprice); 
				
		$itemquantity = $_POST['itemquantity'];
		$insert_itemquantity = implode(",", $itemquantity); 	
		$str_arr1_insert_itemquantity = explode (",", $insert_itemquantity); 
		
		$gstpercentage = $_POST['gstpercentage'];
		$insert_gstpercentage = implode(",", $gstpercentage);
		$str_arr1_insert_gstpercentage = explode (",", $insert_gstpercentage); 
		
		$data = array
					(array(					
				
				'productname' => $insert_productname,
				'itemname' => $insert_itemname,
				'sellingprice' => $insert_sellingprice,
				'itemquantity' => $insert_itemquantity,
				'gstpercentage' => $insert_gstpercentage,
				
				));					
		
		foreach($data as $x => $val) {
				 "$x = $val<br>";
		}
		
		function Counting($data){ 
				
		$count = 0;
		
		foreach( $data as $datacount){
			$count += count( $datacount);
			
		}
		
		return ($count);
		} 
				
		$countarray = Counting($str_arr1_itemname);
		
		for($i=0; $i < $countarray; $i++) {		
		
			$itemname = $str_arr1_itemname[$i];
			
			if(!empty($itemname)) {
				
				 $sql="SELECT * FROM mpurchase WHERE itemname = '$itemname'";

				$result = $DbFunction->getData($sql);
				
				foreach ($result as $res) {
			
					$productcode = $res['productcode'];
				
				}
			}	
			
			$total = (($str_arr1_insert_sellingprice[$i]) * ($str_arr1_insert_itemquantity[$i]));
			
			$gstontotal = ((($total) * ($str_arr1_insert_gstpercentage[$i]) / 100));
			
			$grandtotal = (($total) - ($gstontotal));
			//$grandtotal = number_format($grandtotal,2);
			
			$query="INSERT INTO tempsales (salesbillno,salesDate,customername,productname,itemname,productcode,itemprice,itemquantity,total,discpercentage,discontotal,grandtotal) VALUES ('$salesbillno','$salesDate','$customername','$str_arr_productname[$i]','$str_arr1_itemname[$i]','$productcode','$str_arr1_insert_sellingprice[$i]','$str_arr1_insert_itemquantity[$i]','$total','$str_arr1_insert_gstpercentage[$i]','$gstontotal','$grandtotal') ";
			
			$result = mysqli_query($conn, $query) or die(mysqli_error());						
		
			}
			
			$update1 = "UPDATE sales SET salebillno = salesid";
		
			$result1 = $DbFunction->execute($update1);
			
			header("Location: index.php"); 
		}
				
		
		if(isset($_POST['SubmitSaveTemp'])) {	//  indexupdate.php ==>   tempsales update
				
		$conn = mysqli_connect('localhost','root', '','beautypalace' );
		
		include_once("classes/DbFunction.php");	
		
		$DbFunction = new DbFunction();	
		
		$conn = $DbFunction->myconnect(); 
		
		$data = array();
		
		$salesid = $_POST['salsidtemp'];
		
		$salesbillno = $_POST['salesbillnotemp'];
		
		$customername = $_POST['customername'];	
		
		$cookie_name = "user";
		
		$cookie_value = $customername;
		
		setcookie(customername, $cookie_value, time() + 3600); 
		
		$_COOKIES['customername'] = $cookie_value;
		
		$productname = $_POST['productname'];	// echo   print_r($productname);			
		
			
		$insert_productname = implode(",", $productname); 
		$str_arr_productname = explode (",", $insert_productname);  
		
		$itemname = $_POST['itemname'];
		$insert_itemname= implode(",", $itemname);
		
		$str_arr1_itemname = explode (",", $insert_itemname);
 		
		$sellingprice = $_POST['itempricetemp'];
		$insert_sellingprice = implode(",", $sellingprice); 
		$str_arr1_insert_sellingprice = explode (",", $insert_sellingprice); 
				
		$itemquantity = $_POST['itemquantity'];
		$insert_itemquantity = implode(",", $itemquantity); 
		$str_arr1_insert_itemquantity = explode (",", $insert_itemquantity); 
		
		$gstpercentage = $_POST['gstpercentage'];
		$insert_gstpercentage = implode(",", $gstpercentage);	
		$str_arr1_insert_gstpercentage = explode (",", $insert_gstpercentage); 
		
		$data = array
					(array(					
				
				'productname' => $insert_productname,
				'itemname' => $insert_itemname,
				'sellingprice' => $insert_sellingprice,
				'itemquantity' => $insert_itemquantity,
				'gstpercentage' => $insert_gstpercentage,
				
				));					
	
		foreach($data as $x => $val) {
				 "$x = $val<br>";
		}
		
		function Counting($data){ 
				
		$count = 0;
		
		foreach( $data as $datacount){
			$count += count( $datacount);
			
		}
		
		return ($count);
		} 
		
		$countarray = Counting($str_arr1_itemname);
		
		for($i=0; $i < $countarray; $i++) {		
		
			$itemname = $str_arr1_itemname[$i];
			
			if(!empty($itemname)) {
				
				$sql="SELECT * FROM mpurchase WHERE itemname = '$insert_itemname'";
			 
				$result = $DbFunction->getData($sql);
				
				foreach ($result as $res) {
			
					$productcode = $res['productcode'];
				
				}
			}	
			
			$salesDate = $_POST['salesDate'];
			
			$total = (($str_arr1_insert_sellingprice[$i]) * ($str_arr1_insert_itemquantity[$i]));
			
			$gstontotal = ((($total) * ($str_arr1_insert_gstpercentage[$i]) / 100));
	
			$grandtotal = (($total) - ($gstontotal));
			//$grandtotal = number_format($grandtotal,2);
			
			$query="UPDATE tempsales SET salesDate = '$salesDate', customername = '$customername', productname = '$str_arr_productname[$i]',itemname = '$str_arr1_itemname[$i]', productcode = '$productcode', itemprice = '$str_arr1_insert_sellingprice[$i]',itemquantity = '$str_arr1_insert_itemquantity[$i]',total = '$total',discpercentage = '$str_arr1_insert_gstpercentage[$i]',discontotal = '$gstontotal',grandtotal = '$grandtotal' WHERE salesid = '$salesid'";
			$result1 = $DbFunction->execute($query);
			
			}
			
			
			
		$salesid = $_POST['salsidtemp'];
		
		$query3 = "SELECT purchase.purchaseid AS ppurchaseid, purchase.vendorname AS pvendorname, purchase.venderinoviceno AS pvenderinoviceno, purchase.itemname AS pitemname, purchase.productcode AS pproductcode, tempsales.salesid AS ssalesid, tempsales.salesbillno AS ssalesbillno, tempsales.productcode AS sproductcode, tempsales.productname AS sproductname, purchase.actualitemqty AS pactualitemqty, purchase.itemquantity AS pitemquantity, tempsales.itemquantity AS sitemquantity, (
		tempsales.itemquantity - ABS( purchase.updateqty ) ) AS updateqty FROM purchase LEFT JOIN tempsales ON purchase.productcode = tempsales.productcode WHERE tempsales.salesid = '$salesid' ORDER BY purchase.productcode, updateqty";

		
		$result = $DbFunction->getData($query3);
	
		foreach ($result as $res) {
			
			$ssalesid = $res['ssalesid'];
		
			$purchaseid = $res['ppurchaseid'];

			$itemname = $res['pitemname'];

			$productcode = $res['pproductcode'];

			$itemquantity = $res['pitemquantity'];	

			$updateqty = $res['updateqty'];

			$itemquantity = ($itemquantity - $updateqty);
		    
			$query3 = "UPDATE purchase SET itemquantity = '$itemquantity', updateqty = '$updateqty' WHERE productcode = '$productcode' AND 	purchaseid = '$purchaseid'";
			
			$result3 = mysqli_query($conn, $query3);
		
			}

			$update1 = "UPDATE sales SET salebillno = salesid";
		
			$result1 = $DbFunction->execute($update1);
			
			header("Location: index.php"); 
		}
			
		if(isset($_POST['FinalSubmitSave'])) {   // Submit to the sales, purchase table  
			
		$conn = mysqli_connect('localhost','root', '','beautypalace' );
		
		include_once("classes/DbFunction.php");	
		
		$DbFunction = new DbFunction();	
		
		$sql="SELECT * FROM tempsales ";
		
		$result = $DbFunction->getData($sql);
		
		$process = 0;
		$cnt = $_POST['count'];
		
		foreach($result as $res) {
	
		   $salesid	= $res['salesid'];
		   $salesbillno = $res['salesbillno'];
		   $salesDate =  $res['salesDate'];
		   $customername =  $res['customername'];		   
		   $productname =  $res['productname'];
		   $itemname =  $res['itemname'];
		   $productcode =  $res['productcode'];
		   $itemprice =  $res['itemprice'];
		   $itemquantity =  $res['itemquantity'];
		   $total =  $res['total'];		   
		   $discpercentage =  $res['discpercentage'];
		   $discontotal =  $res['discontotal'];
		   $grandtotal =  $res['grandtotal'];
		
			   break;	   
	    }
		
		if (!empty($salesbillno)) {
			
		$query = "DELETE FROM sales WHERE salesbillno = '$salesbillno'";
		
		$result = mysqli_query($conn, $query) or die(mysqli_error());
		
		$query1 = "INSERT INTO sales( salesbillno, salesDate, customername, productname, itemname, productcode, itemprice, itemquantity, total, discpercentage, discontotal, grandtotal )\n 
		SELECT salesbillno, salesDate, customername, productname, itemname, productcode, itemprice, itemquantity, total, discpercentage, discontotal, grandtotal FROM tempsales ORDER BY salesid ASC";
		
		$result1 = mysqli_query($conn, $query1);
		
		$query2 = "DROP TABLE sales1";
		$result2 = mysqli_query($conn, $query2);
		
		$query3 = "CREATE TABLE sales1 LIKE sales";
		$result3 = mysqli_query($conn, $query3);
		
		$query4 = "INSERT INTO sales1( salesbillno, salesDate, customername, productname, itemname, productcode, itemprice, itemquantity, total, discpercentage, discontotal, grandtotal )\n 
			SELECT salesbillno, salesDate, customername, productname, itemname, productcode, itemprice, itemquantity, total, discpercentage, discontotal, grandtotal FROM sales ORDER BY salesbillno ASC";
		$result4 = mysqli_query($conn, $query4);		
		
		$query5 = "DROP TABLE sales";
		$result5 = mysqli_query($conn, $query5);
		
		$query6 = "CREATE TABLE sales LIKE sales1";
		$result6 = mysqli_query($conn, $query6);
		
		$query7 = "INSERT INTO sales( salesbillno, salesDate, customername, productname, itemname, productcode, itemprice, itemquantity, total, discpercentage, discontotal, grandtotal )\n 
			SELECT salesbillno, salesDate, customername, productname, itemname, productcode, itemprice, itemquantity, total, discpercentage, discontotal, grandtotal FROM sales1 ORDER BY salesbillno ASC";
		$result7 = mysqli_query($conn, $query7);				
		
		}
		
		$query8 = "SELECT purchase.purchaseid AS ppurchaseid, purchase.vendorname AS pvendorname, purchase.venderinoviceno AS pvenderinoviceno, purchase.itemname AS pitemname, purchase.productcode AS pproductcode, tempsales.salesid AS ssalesid, tempsales.salesbillno AS ssalesbillno, tempsales.productcode AS sproductcode, tempsales.productname AS sproductname, purchase.actualitemqty AS pactualitemqty, purchase.itemquantity AS pitemquantity, tempsales.itemquantity AS sitemquantity,  
		(tempsales.itemquantity - ABS( purchase.updateqty )) AS updateqty FROM purchase LEFT JOIN tempsales ON purchase.productcode = tempsales.productcode ORDER BY purchase.productcode, updateqty";
		
//		exit($query3);
		
	
		$result = $DbFunction->getData($query8);
	
		foreach ($result as $res) {
			
			 $ssalesid = $res['ssalesid'];
			 $purchaseid = $res['ppurchaseid'];
			 $itemname = $res['pitemname'];
			 $productcode = $res['pproductcode'];
	
			 $itemquantity = $res['pitemquantity'];	
		
			 $updateqty = $res['updateqty'];
		
			 $itemquantity = ($itemquantity - $updateqty);
		    
			$query9 = "UPDATE purchase SET itemquantity = '$itemquantity', updateqty = '$updateqty' WHERE productcode = '$productcode' AND 	purchaseid = '$purchaseid'";
			
			$result9 = $DbFunction->execute($query9);		
		
			$update10 = "UPDATE sales SET salebillno = salesid";
		
			$result10 = $DbFunction->execute($update10);
		
		}
		
		if ($result){
		
		$result11 = $DbFunction->execute("TRUNCATE Table tempsales");
		
		}
			
		header("Location: index.php"); 
		
		}
		
/*		$tbl_name="tempsales"; // Table name 

		$sql="SELECT * FROM $tbl_name ORDER BY salesid ASC";

		$result = $DbFunction->getData($sql);
	
		foreach ($result as $res) {
			
			$salesid = $res['salesid'];
			$itemname = $res['itemname'];
			$productcode = $res['productcode'];
			$itemquantitys = $res['itemquantity'];
	  
			$deduct1="SELECT * FROM stock";	
			$resultdeduct1=$DbFunction->getData($deduct1);
			
			foreach($resultdeduct1 as $res)
			{
				$itemname1=$res['itemname'];
				$itemquantity1 = $res['itemquantity'];
				
				if($itemname==$itemname1)
				{
					$q=$itemquantity1-$itemquantitys;
					$update = "UPDATE stock SET itemquantity='$q' WHERE itemname='$itemname'";
		
					$result = $DbFunction->execute($update);
				}
			}
		}
*/
		
		
	
		if(isset($_POST['ClearList'])) {  //  Clear tempsales data table
			
		$conn = mysqli_connect('localhost','root', '','beautypalace' );
		
		include_once("classes/DbFunction.php");	
		
		$DbFunction = new DbFunction();	
	
		$query = "TRUNCATE TABLE tempsales";
		
		$result = mysqli_query($conn, $query) or die(mysqli_error());		
		
		header("Location: index.php"); 
		
		}	
		


// SELECT purchase.vendorname, purchase.venderinoviceno, purchase.productcode, purchase.itemname, sales.salesbillno, sales.productcode, sales.productname, purchase.actualitemqty, purchase.itemquantity, sales.itemquantity, (purchase.itemquantity - sales.itemquantity) as updateqty 
// FROM purchase LEFT JOIN sales ON purchase.productcode = sales.productcode ORDER BY purchase.productcode,updateqty

// SELECT purchase.vendorname, purchase.venderinoviceno, purchase.itemname, sales.salesbillno, sales.productcode, sales.productname, purchase.actualitemqty, purchase.itemquantity,sales.itemquantity,
// (purchase.itemquantity - sales.itemquantity ) AS updateqty FROM purchase LEFT JOIN sales ON purchase.productcode = sales.productcode ORDER BY purchase.productcode, updateqty