<?php
	include_once("classes/DbFunction.php");
	$DbFunction = new DbFunction();
	$conn = $DbFunction->myconnect(); 
	$x=$_POST['mproduct'];
	$query ="SELECT DISTINCT itemname FROM mpurchase WHERE productname = '$x'";
	$result = $DbFunction->getData($query);
	foreach ($result as $row) 
	{
		$itemname=$row['itemname'];
		echo "<option value='$itemname'>$itemname</option>";
	}
?>