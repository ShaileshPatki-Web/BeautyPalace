<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<label>
					<select name='productname' value='$mproduct' width='170px'>
						<?php
						include ('connect_db.php');
						$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
						if(!$con)
						{
							die ('Cant Connect');
						} 
						$query = 'SELECT DISTINCT productname FROM mpurchase';
						$result = mysqli_query($con, $query);				
						while($row = mysqli_fetch_array($result))
						{
							$mproduct=$row['productname'];
							echo '<option>'.$mproduct.'</option>';
						} 
						echo '</select>';
						?>
</label>
</body>
</html>