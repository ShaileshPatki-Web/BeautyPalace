<?php
	
	if(isset($_POST['Select']) == 'Select') {
	
	 $purchaseid = $_POST['purchaseid']; 	
	 $purchasebillno = $_POST['purchasebillno']; 
	 $vendorname = $_POST['vendorname'];
	 $venderinoviceno = $_POST['venderinoviceno'];
	 $productname = $_POST['productname'];
	 $itemname = $_POST['itemname'];
	 
	 $productname = $_POST['productname'];
	 $productname1 = substr($productname, 0, 1);
	 $itemname1 = substr($itemname, 0, 1);
		 
	 $productcode = ($productname1 . $itemname1 . $purchaseid);	 
	 
	
	 $gstontotal = $_POST['gstontotal'];
	 $itemprice = $_POST['productprice'];
	 $sellingprice = $_POST['sellingprice']; 
	 $itemquantity = $_POST['itemquantity'];
	 $gstpercentage = $_POST['gstpercentage'];

	 
		include_once("classes/DbFunction.php");

		$DbFunction = new DbFunction();

		$conn = $DbFunction->myconnect(); 
		
		$itemname = $_POST['itemname'];
		$insert_itemname= implode(",", $itemname); // echo

		$str_arr1_itemname = explode (",", $insert_itemname);
		
		$purchasebillno = $purchasebillno;
		$total = ($itemprice * $itemquantity);

		$gstontotal = (($total * $gstpercentage) / 100);
		
		$grandtotal = (($total) + ($gstontotal));
		$grandtotal = number_format($grandtotal,2);
		
		$data = array
			(array(					
		
		'productname' => $insert_productname,
		'itemname' => $insert_itemname,
		'sellingprice' => $insert_sellingprice,
		'itemquantity' => $insert_itemquantity,
		'gstpercentage' => $insert_gstpercentage,
		
		));					

		foreach($data as $x => $val) {
				 "$x = $val<br>";
		}
		
		function Counting($data){ 
				
		$count = 0;
		
		foreach( $data as $datacount){
			$count += count( $datacount);
			
		}
		
		return ($count);
		} 
						
		$countarray = Counting($str_arr1_itemname);
			
		//print_r($data);	
		
		for($i=0; $i < $countarray; $i++) {		

		$itemname = $str_arr1_itemname[$i];
		
		if(!empty($itemname)) {
			
			 $sql="SELECT * FROM mpurchase WHERE itemname = '$itemname'";

			$result = $DbFunction->getData($sql);
			
			foreach ($result as $res) {
		
				$productcode = $res['productcode'];
			
			}
		}
		
		$intinsert = "UPDATE  purchase SET purchasebillno='$purchasebillno', vendorname='$vendorname',venderinoviceno='$venderinoviceno', productname='$productname',productcode='$productcode',itemname='$itemname', itemprice='$itemprice',sellingprice='$sellingprice', itemquantity='$itemquantity',total='$total', gstpercentage='$gstpercentage',gstontotal='$gstontotal',grandtotal='$grandtotal' WHERE 	purchasebillno='$purchasebillno'";
		
		//exit($intinsert);
		
		$result = $DbFunction->execute($intinsert);
		}
		
		header("Location: dashboardpurchase.php");	
	}
		
?>