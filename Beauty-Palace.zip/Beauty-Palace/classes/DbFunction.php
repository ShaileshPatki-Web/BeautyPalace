<?php

include_once 'DbConfig.php';

class DbFunction extends DbConfig
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function getData($query)
	{		
		$result = $this->connection->query($query);
		
		if ($result == false) {
			return false;
		} 
		
		$rows = array();
				
		while ($row = mysqli_fetch_array($result)){
			$rows[] = $row;
		}
		
		
		return $rows;
	}
		
	public function execute($query) 
	{
		$con = $this->myconnect();
		
		$resultexe = $this->connection->query($query);
		
		if ($resultexe == false) {			
		
			return false;
		} else {
			return true;
		}		
	}
	
	public function delete($id, $table) 
	{ 
		$query = "DELETE FROM $table WHERE id = $id";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot delete id ' . $id . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	
	public function escape_string($value)
	{
		return $this->connection->real_escape_string($value);
	}
	
		

	public function getNorows($query)
	{			
		$con = $this->myconnect();
		
		$result = $this->connection->query($query);
		
		if ($result == false) {
			return false;
		} 
		
		$rows = array();
		
		if ($result=mysqli_query($con, $query))
		{
	
		$rowcount=mysqli_num_rows($result);
		//printf("Result set has %d rows.\n",$rowcount);
        return $rowcount;
		}		
	}
	
	function is_session_started()
	{
    if ( php_sapi_name() !== 'cli' ) {
        if ( version_compare(phpversion(), '5.4.0', '>=') ) {
            return session_status() === PHP_SESSION_ACTIVE ? TRUE : FALSE;
        } else {
            return session_id() === '' ? FALSE : TRUE;
        }
    }
    return FALSE;
	}
	
	function ifsessionExists(){
    // check if session exists?
    if(isset($_SESSION)){
    return true;
    }else{
    return false;
    }
	} 
	// if ( ifsessionExists() === FALSE ) session_start();
}
?>
