<?php

class DbConfig 
{	
	private $host = 'localhost';
	private $username = 'root';
	private $password = '';
	private $database = 'beautypalace';
	
	protected $connection;
	
	public function __construct()
	{
		
		
		if (!isset($this->connection)) {
			
			$this->connection = new mysqli($this->host, $this->username, $this->password, $this->database);

			if (!$this->connection) {
				die("Connection failed: " . mysqli_connect_error());
				//echo 'Cannot connect to database server';
				exit;
			}			
		}	
		
		return $this->connection;
	}
	
	public function myconnect() {

	$con=mysqli_connect($this->host, $this->username, $this->password, $this->database);
	
	return $con;
	
	}	
	
}

?>
