<html>
  <head>
  
    <link rel="stylesheet" type="text/css" href="sidebar2.css"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script>
			   
			  function myFunction() {
				  
				var checkBox = document.getElementById("myCheck");
				
				var t = document.getElementById("discontotal");
				
				if (checkBox.checked == true){
					
				t.style.display = "block";
				} else {
					t.style.display = "none";
				}
			}
				function billPrint()
				{
					var x=document.getElementById("bill");
					x.window.print();
				}
				function newRow(){
				
					var table = document.getElementById("tbl");
					var row = table.insertRow(11);
					var cell1 = row.insertCell(0);
					 var cell2 = row.insertCell(1);
					 var cell3 = row.insertCell(2);
					 var cell4 = row.insertCell(3);
					 cell1.innerHTML = "<input type='text' name='itemname[]' />";
					 cell2.innerHTML = "<input type='text' name='itemprice[]' />";
					 cell3.innerHTML = "<input type='text' name='itemquantity[]'  id='itemquantity' />";
					 cell4.innerHTML = "<input type='text' name='discount[]'  id='discount' />";	
				}
			</script>

  </head>
  <body>
  <div class="main-menu>

  
  <div class="area"></div><nav class="main-menu">
  
  
            <ul>
                <li>
                    <a href="dashboardsales.php">
                         
						<i class="fa fa-home fa-2x"></i>
                        <span class="nav-text">
                            SELL
                        </span>
                    </a>
                  
                </li>
                <li class="has-subnav">
                    <a href="#">
                        <i class="fa fa-laptop fa-2x"></i>
                        <span class="nav-text">
                            Purchase
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-list fa-2x"></i>
                        <span class="nav-text">
                           STOCK
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-folder-open fa-2x"></i>
                        <span class="nav-text">
                            Pages
                        </span>
                    </a>
                   
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-bar-chart-o fa-2x"></i>
                        <span class="nav-text">
                            Graphs and Statistics
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-font fa-2x"></i>
                        <span class="nav-text">
                           Quotes
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                       <i class="fa fa-table fa-2x"></i>
                        <span class="nav-text">
                            Tables
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                        <i class="fa fa-map-marker fa-2x"></i>
                        <span class="nav-text">
                            Maps
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa fa-info fa-2x"></i>
                        <span class="nav-text">
                            Documentation
                        </span>
                    </a>
                </li>
            </ul>

            <ul class="logout">
                <li>
                   <a href="#">
                         <i class="fa fa-power-off fa-2x"></i>
                        <span class="nav-text">
                            Logout
                        </span>
                    </a>
                </li>  
            </ul>
        </nav>
 <div class="container">
 <article>
		<center><h1>BEAUTY PALACE</h1></center> 
		<div class="row">&nbsp;</div>
	 <div class="row">
	 <div class="col-sm-8">
	<table  class="table"  align="LEFT"  name ="tbl" id="tbl"> 
            <form name="salesbill" align="LEFT" action="billSale.php"  method="post">
            
               
                <tr>
					<td align="left">Bill Number :</td>
					 <td>
						<label><input type="text" size="5"autofocus name="salesbillno" /></label>
					 </td>
                </tr>
               
                <tr>
					<td align="left">Customer Name</td>
                    <td><label><input type="text" size="10"autofocus name="vendorname" /></label></td>
				</tr>   
               
                <tr>
                    <td align="left">Category </td>
                    <td><label><select name="productname" value="$mproduct" width="170px">
						<?php
							include ("connect_db.php");
							$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
							if(!$con)
							{
								die ("Can't Connect");
							} 
							$query = "SELECT DISTINCT productname FROM mproduct";
							$result = mysqli_query($con, $query);				
							while($row = mysqli_fetch_array($result))
							{
								$mproduct=$row['productname'];
								echo "<option>$mproduct</option>";
							} 
							echo "</select>";
						?> 
					</label></td>
                </tr>
				
                <tr>
					<td align="left">ProductName </td>
					<td align="left">Quantity </td>
					<td align="left">Price </td>
					<td align="left">Discount </td>
                </tr>
               
				    
              
                <tr>
                    <td><input type="text" size="20" name="itemname" multiple /></td>
					<td><input type="text" size="5" name="itemquantity"  id="itemquantity" multiple /></td>
					
                    <td><input type="text" size="5" name="itemprice" multiple /></td>
					<td><input type="text" size="5" name="discpercentage" multiple /></td>
					<td><button type="button" onclick="newRow()">Add</button></td>
                </tr>

				<tr><td></td>
					<td></td>
					<td><input type="submit" name="AddSubmit" value="Save" class="form-submit-button"  /> &nbsp;</td>
					<td><input type="button" name="Print" value="Print" onclick="document.getElementById('bill').contentWindow.print();"></td>
                </tr>
                <tr>
					<td>&nbsp;</td>
                </tr>
				</form>
            </table> 
	
	</div>
	
		
		<div class="col-sm-4">
			<iframe src="billing.php" align="center" name="bill" id="bill" width="380" height="500">
			</div>
	 	
	
	 </div>
	 
  </article>
 

 </div>

 </div>
</body>
</html>