<?php
				
		ob_start(); // Output Buffering on

		$cookie_name = 'productcode';
		$productcode = $_GET['productcode'];
		$cookie_value = $productcode;
		setcookie($cookie_name, $productcode, time() + (86400 * 30), "/");
		
		header("Refresh: 1; URL=$url");
		
		if(!isset($_COOKIE[$cookie_name])) {
		 error_reporting(E_ALL ^ E_WARNING);
		 
		 echo "Cookie named '" . $cookie_name . "' is not set!"."</br>";
		 echo "Please Press Submit button after, selecting Product Code ... ";
		 $url=$_SERVER['REQUEST_URI'];
		 header("Refresh: 10; URL=$url");
		 
		} else {
		 
		 error_reporting(E_ALL ^ E_WARNING);
						 
		 echo "Cookie '" . $cookie_name . "' is set!<br>";
		 echo "Value is: " . $_COOKIE[$cookie_name];
						 
		 exit;
		}
				
?>