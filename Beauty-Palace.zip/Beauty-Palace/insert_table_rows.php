<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Beauty Palace</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<center><img src="img/New_logof.jpg"></Center>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		
		<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
		
		<script type="text/javascript">
			function billPrint()
			{
				window.open("billing.php").print();
			}
			function newRow()
			{
				var table = document.getElementById("tbl");
				var row = table.insertRow(4);
				var cell1 = row.insertCell(0);
				var cell2 = row.insertCell(1);
				var cell3 = row.insertCell(2);
				var cell4 = row.insertCell(3);
				var cell5 = row.insertCell(4);
				var cell6 = row.insertCell(5);
				var cell7 = row.insertCell(6);
				cell1.innerHTML = "<select name='productname' value='Bags' width='170px'><option value=''>Bags</option><option value=''>Jewellery</option><option value=''>Cosmetics</option><option value=''>Perfume</option></select>";
				cell2.innerHTML = "<input type='text' size='20' name='itemname'/>";
				cell3.innerHTML = "<input type='text' size='20' name='productcode'/>";
				cell4.innerHTML = "<input type='text' size='20' name='itemprice'/>";
				cell5.innerHTML = "<input type='text' size='20' name='itemquantity'/>";	
				cell6.innerHTML = "<input type='text' size='20' name='gstpercentage'/>";	
				cell7.innerHTML = "<input type='button' onclick='newRow()' value='Add'/>";
				
			}
		</script>
  </head>
  <body>

  
	
	<form name="salesbill" enctype="multipart/form-data" action="insert_table_rows.php" method="post" id="form">
	
		<table  class="table"  align="LEFT"  name ="tbl"  border="0" cellspacing="1" cellpadding="0"> 
		
				<tr>
					<td align="left">New Bill Number :</td>
					 <td>
		<?php
					
					include_once("classes/DbFunction.php");
		
					$DbFunction = new DbFunction();
		
					$conn = $DbFunction->myconnect(); 
						
					$tbl_name="sales1"; // Table name 

					$sql="SELECT * FROM $tbl_name";

					$result = $DbFunction->getData($sql);

					$count = $DbFunction->getNorows($sql);
						
						
					$query = "SELECT DISTINCT salesid FROM $tbl_name ORDER BY salesid DESC Limit 1";
						
					$result1 = $DbFunction->getData($query);
						
						foreach ($result1 as $res) {
						
							 $salesid = $res['salesid'];
				  
						}
						
						//echo $salesid = ($salesid + 1);
				
						
			/*	$query = "Select * from $tbl_name ORDER BY salesid Asc";
				
				$rows = $DbFunction->getNorows($query); 
								
				$resultdays = $DbFunction->getData("SELECT * FROM $tbl_name  ORDER BY salesid Asc");
						
				$start = $start + 1;
			 
				for( $i = $start; $i < $calc; $i++) {
						
				foreach ($resultdays as $res) {
				 
				$days = $res['days']; */
		?>	
		
		 </td>
                </tr>
				<tr>
					<td align="left">Bill Number :</td>
					 <td>
						<label><input type="hidden" name="days[]"  value="<?php echo $days; ?>" id="name-data" class='form-control detail'></lable>
						<label><input type="text" hidden size="20" autofocus name="salesid" id="name-data" class='form-control detail' align="left"/></label>
						<label><input type="text" size="20" autofocus name="salesbillno" id="name-data" class='form-control detail' ></label>
					 </td>
                </tr>
				
				
				<tr>
					<td align="left">Customer Name</td>
                    <td><label><input type="text" size="20" autofocus name="customername" id="name-data" value="<?php echo $rows['customername']; ?>" class='form-control detail' /></label></td>
				</tr>

				
				<tr>
					<td align="left">Product Category </td>
					<td align="left">Item Name </td>
					<td align="left">Product Code </td>
					
					<td align="left">Price </td>
					<td align="left">Quantity </td>
					<td align="left">Discount </td>
                </tr> 
				
				<td><label>
				
					<select name="productname[]" id="name-data"  class='form-control detail' >
						
						<option value="Bags">Bags</option>
						<option value="Jewellery">Jewellery</option>
						<option value="Perfume">Perfume</option>
						<option value="Cosmetics">Cosmetics</option>
						
					</select>						
						
					</label></td>
						
                    <td><input type="text" id="name-data" name="itemname[]" class='form-control detail'/></td>
					<td><input id="name-data" type="text" name="productcode[]" class='form-control detail' /></td>
					<td><input id="name-data" type="text" name="itemprice[]" class='form-control detail' /></td>
					
					<td><input id="name-data" type="text" name="itemquantity[]" class='form-control detail' /></td>
					<td><input id="name-data" type="text" name="gstpercentage[]" class='form-control detail' /></td>
					
					
				
					<td><input type="button" id="" onclick="newRow()" value="Add"/></td>
                </tr>
				
				
				<tr><td></td>
					<td>
					
					<?php
	
				/*	//	$i = $i + 1;	
									
					//	}
						
						if ( $i > $rows ) {
						break;	
						
						} 
				*/		
					?>	
					
					</td>
					<td><input id="submit" type="submit" value="Submit Order" class="btn btn-primary"  name="SubmitSave"/>	</td>
					<td><input type="submit" name="Print" value="Print" class="btn btn-primary" onclick="billPrint()"></td>
                </tr>
                <tr>
					<td>&nbsp;</td>
                </tr>
				
				<?php
			
					}				
				
				?>
				</table> 
	
	</form>
	
	</body> 
</html>

<?php

if (isset($_POST['SubmitSave'])){
//error_reporting("0");
$con = mysqli_connect('localhost','root', '','beautypalace');
//$con = mysqli_connect('localhost','root', '','test' );
    
$row_data = array();
	
	foreach($_POST['days'] as $row=>$days) { 
		
		$days=mysqli_real_escape_string($con,$days); 

	 

	 $productname=mysqli_real_escape_string($con,($_POST['productname'][$row]));
	 $itemname=mysqli_real_escape_string($con,($_POST['itemname'][$row]));
	 $productcode=mysqli_real_escape_string($con,($_POST['productcode'][$row]));
	 $itemprice=mysqli_real_escape_string($con,($_POST['itemprice'][$row]));
	 $itemquantity=mysqli_real_escape_string($con,($_POST['itemquantity'][$row]));
	 $gstpercentage=mysqli_real_escape_string($con,($_POST['gstpercentage'][$row]));
 
	$row_data[] = "('$salesid','$salesbillno', '$customername', '$productname','$itemname', '$productcode', '$itemprice', '$itemquantity', '$gstpercentage')";
	//	print_r($row_data[]);

	//echo implode(',', $row_data);
	//exit('test');
}

if (!empty($row_data)) {
$sql = 'INSERT INTO  sales1(salesid, salesbillno,customername, productname, itemname, productcode,itemprice,itemquantity, gstpercentage) VALUES '.implode

(',', $row_data);


//$result2 = mysqli_query($con, $sql );

if ($result2)
echo 'Successful inserts: ' . mysqli_affected_rows($con);
else
echo 'query failed' ;
} 
}

?>