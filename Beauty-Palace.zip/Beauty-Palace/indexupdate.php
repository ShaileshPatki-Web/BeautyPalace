<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Beauty Palace</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<center><img src="img/New_logof.jpg"></Center>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	
		<script type="text/javascript">
		
			function billPrint()
			{
				window.open("billing.php").print();
			}
			function newRow()
			{
				
				var table = document.getElementById("tbl");
				var row = table.insertRow(6);
				var cell1 = row.insertCell(0);
				var cell2 = row.insertCell(1);
				var cell3 = row.insertCell(2);
				var cell4 = row.insertCell(3);
				var cell5 = row.insertCell(4);
				var cell6 = row.insertCell(5);
				var cell7 = row.insertCell(6);				
				
				cell1.innerHTML = "<input type='text' size='20' name='producthidden[]' id='textFieldTextJS'/>";
				cell2.innerHTML = "<input type='text' size='20' name='itemname[]'/>";
				cell3.innerHTML = "<input type='text' size='20' name='productcode[]'/>";
				cell4.innerHTML = "<input type='text' size='20' name='itemprice[]'/>";
				cell5.innerHTML = "<input type='text' size='20' name='itemquantity[]'/>";	
				cell6.innerHTML = "<input type='text' size='20' name='gstpercentage[]'/>";	
				cell7.innerHTML = "<input type='button' onclick='newRow()' value='Add'/>";
				
				
			}
			
			function singleSelectChangeText() {

			document.cookie = "username1=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
			
			var selObj = document.getElementById("new_select3");
			var selValue = selObj.options[selObj.selectedIndex].text;
			
			document.getElementById("textFieldTextJS1").value = selValue;			
			
			}
			
			function singleInputChangeText() {
			
			document.cookie = "username1=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
			var selObj = document.getElementById("new_select3");
			var selValue = selObj.options[selObj.selectedIndex].text;
			
			document.getElementById("textFieldTextJS1").value = selValue;			
			
			document.cookie = 'username1=textFieldTextJS1';
			
			}
			
			function fetch_select1(val)
			{
			 $.ajax({		 
			 type: 'post',
			 url: 'fetch_data_name.php',	 
			 data: {		 
			  get_option:val
			 },
			 success: function (response) {		  
			 document.getElementById("new_select1").innerHTML=response;
			 
			 }
			 });
			}
			
			function fetch_select2(val1)
				{		
				
				 $.ajax({
				 type: 'post',
				 url: 'fetch_data_itemname.php',
				 data: {
				  get_option1:val1
				 },
				  success: function (response) {		
				  document.getElementById("new_select2").innerHTML=response;
				   
				  var x = document.getElementsByClassName("exampleitemname");
				  x[0].innerHTML = response; 
					
				 }
				 });
				}
			

			function fetch_select3(val3)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_productcode.php',
			 data: {
			  get_option3:val3
			  
			 },
			 success: function (response) {		
			 
			 document.getElementById("new_select3").innerHTML=response;
			  
			 var x = document.getElementsByClassName("exampleproductcode");
			 x[0].innerHTML = response;	
			 
				
			 }
			 });
			}
						
			function fetch_select5(val5)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_sellingprice.php',
			 data: {
			  get_option5:val5
			 },
			 success: function (response) {		
			  
			  document.getElementById("new_select5").innerHTML=response;
				
			  var x = document.getElementsByClassName("examplesellingprice");
			  x[0].innerHTML = response;	
			  
			 }
			 });
			}
			
			var	sellingprice = document.getElementByClass("sellingprice");

			document.write(sellingprice);
				
		</script>
		
		<style type="text/css">
			.box{
				color: #000;
				 margin-top: 40px;
			}
			.red{ background: #ECF0F5; }		 
			
		</style>
  </head>
  <body>
  
  <div class="main-menu>
  
  <div class="area"></div><nav class="main-menu">  
		<ul>
            <li><a href="index.php">
			<i class="fa fa-home fa-2x"></i>
            <span class="nav-text">Billing</center></span>
            </a>
            </li>
			<li class="has-subnav">
                <a href="dashboardpurchase.php">
                <i class="fa fa-laptop fa-2x"></i>
                <span class="nav-text">Purchase</span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardsales.php">
                <i class="fa fa-list fa-2x"></i>
                <span class="nav-text">Sales</span>
                </a>
            </li>
			<li>
                    <a href="dashboardproduct.php">
                        <i class="fa fa-bar-chart-o fa-2x"></i>
                        <span class="nav-text">
                           Add Product 
                        </span>
                    </a>
                </li>
            <li class="has-subnav">
                <a href="dashboardstock.php">
                 <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Stock Report</span>
                </a>
            </li>
          <li>
                <a href="salesReport.php">
                 <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Sales Report</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Tables</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-map-marker fa-2x"></i>
                <span class="nav-text">Maps</span>
                </a>
            </li>
            <li>
				<a href="documentation.php">
                <i class="fa fa-info fa-2x"></i>
                <span class="nav-text">Documentation</span>
                </a>
            </li>
        </ul>
        <ul class="logout">
			<li>
			<a href="#">
            <i class="fa fa-power-off fa-2x"></i>
            <span class="nav-text">Logout</span>
            </a>
			</li>  
        </ul>
    </nav>
	
 <div class="container">
 <article>
 <p><br/><p>
 
	<h3 align="center">Billing</h3>
		 
	 <div class="col-sm-12">
	
	 
	<?php
			
		include_once("classes/DbFunction.php");

		$DbFunction = new DbFunction();

		$conn = $DbFunction->myconnect(); 
			
		$tbl_name = "sales"; // Table name 


		$sql="SELECT * FROM $tbl_name";

		$result = $DbFunction->getData($sql);

		$count = $DbFunction->getNorows($sql);						
		
		$query = "SELECT DISTINCT salesid FROM $tbl_name ORDER BY salesid DESC Limit 1";
		
		$result1 = $DbFunction->getData($query);
		
		foreach ($result1 as $res) {
		
			 $salesid = $res['salesid'];
  
		}
		
		$salesid = ($salesid + 1);
						
	?>
		
		<form action="index1.php" method="POST"  width="100%">
		
		
		<?php
					include_once("classes/DbFunction.php");
		
					$DbFunction = new DbFunction();
		
					$conn = $DbFunction->myconnect(); 
						
					$tbl_name = "tempsales"; // Table name 

					$sql = "SELECT * FROM $tbl_name";

					$result = $DbFunction->getData($sql);

					$count = $DbFunction->getNorows($sql);
						
					$salsidtemp = $_GET['id'];	
					
					$query = "SELECT * FROM $tbl_name WHERE salesid = '$salsidtemp'";
						
					$result1 = $DbFunction->getData($query);
						
					foreach ($result1 as $res) {
						
								$salesidtemp = $res['salesid'];
								$salesbillnotemp = $res['salesbillnotemp'];
								$salesDatetemp= $res['salesDate'];
								$customernametemp = $res['customername'];
								$venderinovicenotemp=$res['venderinoviceno'];
								$productnametemp=$res['productname'];
								$itemnametemp=$res['itemname']; 
								$productcodetemp=$res['productcode'];
								$itempricetemp=$res['itemprice'];
								$itemquantitytemp=$res['itemquantity'];
								$totaltemp=$res['total']; 
								$discpercentagetemp=$res['discpercentage'];
								$discontotaltemp=$res['discontotal'];
								$grandtotaltemp=$res['grandtotal'];
				  
						}
						
						$salesid = ($salesid + 1);
						
						
						
			?>
		
			<table name="tbl" id="tbl"> 
				
                <tr>
				<td align="left"><label>Bill Date   :  &nbsp;&nbsp;&nbsp; </label></td>
				 <td>
				
					<label><input type="date" value="<?php echo $salesDatetemp; ?>"  autofocus name="salesDate" /></label>
					
				 </td>
			</tr>
               
                <tr>
					<td align="left">Customer Name:</td>
					
                    <td><label><input type="text" size="20" autofocus name="customername" id="customername" value="<?php echo $customernametemp; ?>" class='form-control detail' />
					
					
					
					</label></td>
					
				</tr>                  				 
                
				<tr><td><p></br></p></td></tr>
                <tr>
					<td align="left" width="170">Product Category </td>
					<td align="center">Item Name </td>
				<!--	<td align="center">Product Code </td> -->
					
					<td align="center">Price </td>
					<td align="center">Quantity </td>
					<td align="center">Discount </td>
                </tr>               
				    
                <tr>
				
					<td>
					<input type="hidden" size="20" autofocus name="salsidtemp" id="salsidtemp" value="<?php echo $salsidtemp; ?>" class='form-control detail' />
					<?php 
						
							
						$result = $DbFunction->getData("SELECT DISTINCT productname FROM mpurchase GROUP BY productname,itemname ORDER BY productname,itemname");
						
						echo "<select name='productname[]' onChange='fetch_select1(this.value);fetch_select2(this.value);fetch_select3(this.value);fetch_select4(this.value);' class='form-control detail'>";

							echo "<option value='$productnametemp'>$productnametemp</option>";	

							foreach ($result as $res) {
						
							$productname=$res['productname'];
							
							echo "<option value='$productname'>$productname</option>";
						}
						
					echo "</select>";	
					
					?>
					
					</td>
					
					<td>

						<?php 
						
						$result = $DbFunction->getData("SELECT DISTINCT itemname FROM mpurchase ORDER BY itemname");
						
						echo "<select  name='itemname[]' id='new_select2' class='exampleitemname form-control detail' >";
						
						echo "<option value='$itemnametemp'>$itemnametemp</option>";	
						
						foreach ($result as $res) {
						
							$itemname=$res['itemname'];
							
							echo "<option value='$itemname'>$itemname</option>";
							
						}
						
						echo "</select>";	
					
						?>	
                   
				   </td>
					
					<td>
					
					<input type="text" size="20" name="itempricetemp[]" id="itempricetemp" required class="examplesellingprice form-control detail" value="<?php echo $itempricetemp; ?>" placeholder="Selling Price" />
					
					
					</td>
					
					<td><input type="text" size="20" name="itemquantity[]" id="itemquantity" value="<?php echo $itemquantitytemp; ?>"  class='form-control detail' /></td>
					<td><input type="text" size="20" name="gstpercentage[]" id="gstpercentage" value="<?php echo $discpercentagetemp; ?>"  class='form-control detail' /></td>
					<td><input type='submit' name='SubmitSaveTemp' value='Add'/></td>				
				
					<td>
					
					<p><br/><p>
					<p><br/><p>
					<p><br/><p>
					
					</td>
					
					</tr>
					
					<p><br/><p>

					
					</tr><br/>
				
				</form>
			
	</div>
		
		<div class="col-12 col-md-8">
		
		
		<?php  
       
        include_once("classes/DbFunction.php");
		
		$DbFunction = new DbFunction();
		
		$conn = $DbFunction->myconnect();
		
		$query = "SELECT * FROM tempsales WHERE salesid='$salsidtemp' ORDER BY salesid Desc";
		
		$total_results = $DbFunction->getNorows($query);		
		
		$per_page = 10;
	
		$total_pages = ceil($total_results / $per_page);	
		
		
		
		$result = $DbFunction->getData("SELECT * FROM tempsales WHERE salesid='$salsidtemp' ORDER BY salesid Desc");
		
		if($result > 0 ) {
		
		echo "<div><table class='table' cellpadding='0.15' border-spacing: 1px; style='border-collapse: collapse;border-style:solid;border-width: 1px;'>";
		echo '<tr> <th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF; text-align: center; ">Sr. No.</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product<br>Category</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item<br>Name</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Qty</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discount</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discounted<br>Amount</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Grand<br>Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; "><img src="update.png"></th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; "><img src="del.png"></th>
		</tr>';
		
		$start =  1;
		$total_results;
		
		for ($i = $start; $i <= $total_results; $i++)
        {
          		
			foreach ($result as $res) {
				
				$salesid = $res['salesid'];
				$salesbillno = $res['salesbillno'];
				$salesDate= $res['salesDate'];
				$customername = $res['customername'];
				$venderinoviceno=$res['venderinoviceno'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$itemprice=$res['itemprice'];
				$itemquantity=$res['itemquantity'];
				$total=$res['total']; 
				$discpercentage=$res['discpercentage'];
				$discontotal=$res['discontotal'];
				$grandtotal=$res['grandtotal']; 	
				
				echo '<tr> </tr>';
				echo '<tr> </tr>';
				
				echo "<tr style='text-align: center;'>";
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $total . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discpercentage . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discontotal . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $grandtotal . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="indexupdate.php?id=' . $salesid . '"><img src="update.png"></a></td>'; 
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="deletesalesbill.php?id=' . $salesid . '" onclick="return confirmDelete()"><img src="del.png"></a></td>';	
			    echo "</tr>"; 
				
				$i = $i + 1;	
				
				}
				
			}

			echo "</table></div>";	
			
			}
			
		?>
		
		
	 		
	 </div>
	 
  </article> 

 </div>
 
 </div>
 
 
 </body>
 </html>
 
 