<?php 
	
		
	/*
	$_POST['Submit'] = $_POST['productcode'];
	
	if(isset($_POST['get_option5'])){
	
	if ( $DbFunction->ifsessionExists() === FALSE ) {@session_start();}
	
	include_once("classes/DbFunction.php");
	
	$DbFunction = new DbFunction();	
	
	$productcode = $_POST['get_option5'];
	
	$result = $DbFunction->getData("SELECT  sellingprice FROM mpurchase WHERE productcode = '$productcode' ORDER BY productname");
	
	foreach ($result as $res) {
			
		echo "<option>".$res['sellingprice']."</option>";
			 
	}			
	
	exit;  
	*/

	
	
				
	error_reporting("0");
	
								
	
	
				include_once("classes/DbFunction.php");	
		
				$DbFunction = new DbFunction();	
	
				$productcode = $_POST['productcode'];
				
				$sql = "SELECT *  FROM mpurchase WHERE productcode = '$productcode'";
					
				$result = $DbFunction->getData($sql);
				
				foreach ($result as $res) {
							
						$ssalesid = $res['ssalesid'];
						$itemname = $res['itemname'];
						$productcode = $res['productcode'];
				echo	$sellingprice = $res['sellingprice'];
					
						}
				
				
				
				//header("Location: index.php");	
					
					
?>	