<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>

		<meta charset="UTF-8">       
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	-->	
         <title>Beauty Palace - Sales</title>
        
        <style>
            
            /* Style the element with the id "myHeader" */
            
             
                #Headertext {
                  top: 0;
              
                  font-size: 18px;
                  color: black;
                  background-color: lightskyblue;
                  text-align: center;                  
                  width: 100%;
                  height: 100%;
                }

                /* Style all elements with the class name "city" */
                
                .date1 {
                    
                  position: static;  
                  background-color: lightskyblue;
                  color: green;
                  font-size: 18px;
                  text-align: center;
                  padding: 250px;
                }
                
                #borderimg { 
                    border: 8px solid transparent;
                    border-radius: 25px;                    
                    
                    border-image: url(nbproject/border.png) 30 round;
                    width: 485px;
                    height: 345px;
                  }

                 #Footertext {
                  
                    position: fixed;
                    left: 0;
                    bottom: 0;
                    width: 100%;
                    background-color: crimson;
                    color: white;                  
                    font-size: 24px;    
                    text-align: center;
            }
     
              .topleft {
              position: absolute;  
              top: 28px;
              left: 28px;
              font-size: 18px;
            }

            .topright {
              position: absolute;
              top: 28px;
              right: 28px;
              font-size: 18px;
            }

            .center {
              position: absolute;
              left: 0;
              top: 3%;
              width: 100%;
              text-align: center;
              font-size: 18px;
            }


            .form-submit-button {

                background: #016ABC;
                color: #fff;
                border: 1px solid #eee;
                border-radius: 20px;
                text-shadow:none;

                }

                .form-submit-button:hover {

                background: #33ccff;
                color: #fff;
                border: 1px solid #eee;
                border-radius: 20px;
                text-shadow:none;

            }
			
			 select {
				width: 178px;
				margin: 10px;
			}
			select:focus {
				min-width: 178px;
				width: auto;
			}    	
       
        </style>
        
        
    </head>
    <body>
        
        <div id='Headertext'>
            
            <div class="date1">
            
           <div class="topleft">

	   <?php
        
            echo $date = date("d-M-Y");           
        
        ?>  
         
         </div>      
            
        <div class="center">
            <h1>
            <img src="nbproject/gifdesign.gif" height='40' width='40' style="align-items: center;" >
            
            </img>      Beauty Palace <img src="nbproject/gifdesign.gif" height="40" width="40">  </img>        </h1> 
        </div>
            
          <div class="topright">
          
                <form name="Tick">
                    
                    <div id="demo"> </div>
                    
                </form>
            
        </div>
					
                <table  height="50" width="498" align="center" > 
                    
                 <form name="salesbill" align="Center" action="salesbill.php"  method="post">
                    
                   <td width="298">
                       
                    <tr>
                      <td>&nbsp;</td>
                      <td width="278">&nbsp;</td>
                    <tr>
                      <td align="left">Sales Bill Number </td>
                      <td><label>
                        <input type="text" autofocus name="salesbillno" />
                      </label></td>
                    </tr>
                       
                    <tr>
                      <td>&nbsp;</td>
                      <td width="278">&nbsp;</td>
                    <tr>
                      <td align="left">Vendor Name </td>
                      <td><label>
					  
						<input type="text" autofocus name="vendorname" />					
					
                      </label></td>
					  
                    </tr>   
                       
                      <tr>
                      <td>&nbsp;</td>
                      <td width="278">&nbsp;</td>
                    <tr>
                      <td align="left">Invoice Number </td>
                      <td><label>
                        <input type="text" autofocus name="venderinoviceno" />
                      </label></td>
                    </tr>     
                       
                    <tr>
                      <td>&nbsp;</td>
                      <td width="278">&nbsp;</td>
                    <tr>
                      <td align="left">Product Category </td>
                      <td><label>
					  
					  <select name="productname" value="$mproduct" width="170px">
					  
                        <?php
		
						include ("connect_db.php");
						
						$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
						
						if(!$con)
						{
						  die ("Can't Connect");
						} 
						
						$query = "SELECT DISTINCT productname FROM mproduct";
						
						$result = mysqli_query($con, $query);				
						
						while($row = mysqli_fetch_array($result))
							{
							  $mproduct=$row['productname'];
							  echo "<option>$mproduct</option>";
							} 
						
						echo "</select>";
				
					?>
                      </label></td>
                    </tr>
                    <tr>

                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>

                      <td align="left">Product Name </td>
                      <td><input type="text" name="itemname" /></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td align="left">Product Price </td>
                      <td><input type="text" name="itemprice" /></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
					
                    <tr>
                      <td align="left">Product Quantity </td>
                      <td><input type="text" name="itemquantity" /></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>             
                 
						
					<tr>
                      <td align="left">Enter GST Percentage  </td>
                      <td><input type="text" name="gstontotal" /></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>                 	
				
                    <tr>
                      <td>&nbsp;</td>
                      <td> 

                         <input type="submit" name="AddSubmit" value="Submit" class="form-submit-button"  /> </td>
                    </tr>
                    <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                     </table>
                  </form>
        <?php          
	
		include_once("classes/Crud.php");
		
		$perpage = 10;
		
		if(isset($_GET["page"])){
		$page = intval($_GET["page"]);
		}
		else {
		$page = 1;
		}
		
		$calc = $perpage * $page;
		$start = $calc - $perpage;
		
		$crud = new Crud();
		
		$conn = $crud->myconnect();
						
		$query = "SELECT * FROM sales ORDER BY salesid Desc";
		
		$rows = $crud->getNorows($query); 
		
		$result = $crud->getData("SELECT * FROM sales ORDER BY salesid Desc Limit $start, $perpage");
		
		echo "<table align='center' class='table' cellpadding='1' border-spacing: 0px;'>";

		echo '<tr> <th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF; text-align: center; ">Serial</th> 
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">sales Bill No</th> 
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Vendor Name</th> 
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Inovice No</th> 
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Product Name</th> 
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Item Name</th>
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Item Price</th>
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Item Quantity</th>
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Price Total</th>
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">GST %</th>
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">GST Total</th>
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Grand Total</th>
		
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Update</th>
		<th style="border: 1px solid #FFFFFF;background: #3c8dbc;color: #FFFFFF;text-align: center; ">Delete</th>
		
</tr>';
				
			$start = $start + 1;
			 
			for( $i = $start; $i < $calc; $i++) {		
			
			foreach ($result as $res) {
				  $salesid = $res['salesid'];
				  $salesbillno = $res['salesbillno'];
				  $vendorname = $res['vendorname'];
				  $venderinoviceno=$res['venderinoviceno'];
				  $productname=$res['productname'];
				  $itemname=$res['itemname']; 
				  
				  $itemprice=$res['itemprice'];
				  $itemquantity=$res['itemquantity'];
				  $total=$res['total']; 
				  
				  $gstpercentage=$res['gstpercentage'];
				  $gstontotal=$res['gstontotal'];
				  $grandtotal=$res['grandtotal']; 			  
				  
			 	echo '<tr> </tr>';
				echo '<tr> </tr>';
			
				echo "<tr>";
            
                echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
                echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $salesbillno . '</td>';
                echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $vendorname . '</td>';
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $venderinoviceno . '</td>';
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $productname . '</td>';
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $itemname . '</td>';
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $itemprice . '</td>';
				
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $itemquantity . '</td>';
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $total . '</td>';
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $gstpercentage . '</td>';
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $gstontotal . '</td>';
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99 ;">' . $grandtotal . '</td>';
				
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99; text-align:center;"><a align href="updatesalesbill.php?id=' . $salesid . '">Update</a></td>'; 
				
				echo '<td style="padding: 1px;border: 1PX solid #FFFFFF;background: #99FF99; text-align:center;"><a align href="crud/deleteholidays.php?id=' . $id . '" onclick="return confirmDelete()">Delete</a></td>';	
                echo "</tr>"; 
				
				$i = $i + 1;	
							
				}
				
				if ( $i > $rows ) {
				break;	
				
				} 
			}
					
		echo "</table>";
 
 ?>
        </div>
          
        </div>    
               
        <div>   
       
        <div id="Footertext">Copyright 2019</div>
        
        </div>  
   </body> 
   
<script>
var myTimer = setInterval(myClock, 1000);
function myClock() {
    document.getElementById("demo").innerHTML =
    new Date().toLocaleTimeString();
}
</script>
        
</html>
