<?php
	
	 $purchaseid = $_POST['purchaseid'];	
	 $purchasebillno = $_POST['purchasebillno']; 
	 $purchaseDate=$_POST['purchaseDate'];
	 $vendorname = $_POST['vendorname'];
	 $venderinoviceno = $_POST['venderinoviceno'];
	 $itemname = $_POST['itemname'];
	 $insert_itemname = implode(",", $itemname); 
	 $str_arr_itemname = explode (",", $insert_itemname);  
	 $itemname = $insert_itemname;
	 
	 
	 $productname = $_POST['productname'];
	 $productname1 = substr($productname, 0, 1);
	 $itemname1 = substr($itemname, 0, 1);
		 
	 $productcode = ($productname1 . $itemname1 . $purchaseid);
	
	 
	
	 $itemprice = $_POST['productprice'];
	 $sellingprice = $_POST['sellingprice']; 
	 $actualitemqty = $_POST['itemquantity'];
	 $itemquantity = $_POST['itemquantity'];
	 $gstpercentage = $_POST['gstpercentage'];
	 
 
	 if(isset($_POST['AddSubmit']) == 'AddSubmit') {

			include_once("classes/DbFunction1.php");

			$DbFunction = new DbFunction();

			$conn = $DbFunction->myconnect(); 
			
			$itemname = $_POST['itemname'];
			$insert_itemname= implode(",", $itemname); // echo

			$str_arr1_itemname = explode (",", $insert_itemname);
			
			$itemprice = $_POST['productprice'];
			$sellingprice = $_POST['sellingprice']; 
			$actualitemqty = $_POST['itemquantity'];
			$itemquantity = $_POST['itemquantity'];
			$gstpercentage = $_POST['gstpercentage'];
			
			$total = ($itemprice * $itemquantity);
			
			$gstontotal = (($total * $gstpercentage) / 100);
			
			$grandtotal = ($total + $gstontotal);
			$grandtotal = number_format($grandtotal,2);
			
			$data = array
				(array(					
			
			'productname' => $insert_productname,
			'itemname' => $insert_itemname,
			'sellingprice' => $insert_sellingprice,
			'itemquantity' => $insert_itemquantity,
			'gstpercentage' => $insert_gstpercentage,
			
			));					
		
		foreach($data as $x => $val) {
				 "$x = $val<br>";
		}
		
		function Counting($data){ 
				
		$count = 0;
		
		foreach( $data as $datacount){
			$count += count( $datacount);
			
		}
		
		return ($count);
		} 
						
		$countarray = Counting($str_arr1_itemname);
		
		for($i=0; $i < $countarray; $i++) {		
		
			$itemname = $str_arr1_itemname[$i];
			
			if(!empty($itemname)) {
				
				 $sql="SELECT * FROM mpurchase WHERE itemname = '$itemname'";

				$result = $DbFunction->getData($sql);
				
				foreach ($result as $res) {
			
					$productcode = $res['productcode'];
				
				}
			}	
			
			$intinsert = "INSERT INTO purchase (purchasebillno,purchaseDate,vendorname,venderinoviceno,productname,productcode,itemname,itemprice,sellingprice,actualitemqty,itemquantity,total,gstpercentage,gstontotal,grandtotal) VALUES ('$purchasebillno','$purchaseDate','$vendorname','$venderinoviceno','$productname','$productcode','$itemname','$itemprice','$sellingprice','$actualitemqty','$itemquantity','$total','$gstpercentage','$gstontotal','$grandtotal')";
		
			$result = $DbFunction->getData($intinsert);
						
		   }				
						
						//check if product exist in mpurchase
						$chklist="SELECT * FROM mpurchase";
						$chkresult = $DbFunction->getData($chklist);
						if($chkresult)
						{
							foreach ($chkresult as $res) 
							{
								$productname1 = $_POST['productname'];
								$itmname=$res['itemname'];
								$productcode1 = $_POST['productcode'];
								
								if($itemname1!=$itmname)
								{
									$got=1;
									if($got==1){break;}
																		
								}
								else
								{
									$got=0;
								}
								
							}
							
						}
						if($got==1)
						{
							//$intinsert = "INSERT INTO mpurchase (productname,itemname,productcode,productprice,sellingprice) VALUES ($productname','$itemname','$productcode','$itemprice,'$sellingprice')";
								
							//$result = $DbFunction->execute($intinsert);
						}
						
						
							
						
						
						
						//check if product already exist in stock
						$checkselect = "SELECT * FROM stock";
						$checkresult=$DbFunction->getData($checkselect);
						if($checkresult)
						{
							foreach ($checkresult as $res) 
							{
								$itemname1=$res['itemname'];
								$itemquantity1 = $res['itemquantity'];
								$itemquantity2=$itemquantity1+$itemquantity;
								if($itemname==$itemname1)
								{
									
									 $val=1;
									if($val==1)
									{break;}
								}
								else
								{
									//echo "in else";
									$val=0;
								}
								
							}
						}
						if($val==1)
						{	
							$update = "UPDATE stock SET itemquantity='$itemquantity2' WHERE itemname='$itemname'";
							$checkresult=$DbFunction->execute($update);
						}
						else if ($val==0)
						{
							$intinsert = "INSERT INTO stock (productname,itemname,productcode,itemquantity,itemprice,sellingprice) VALUES ('$productname','$itemname','$productcode','$itemquantity','$itemprice','$sellingprice')";
							$result = $DbFunction->execute($intinsert);
						}	
						
						
						header("Location: dashboardpurchase.php"); 
												
	}
	
?>