<!DOCTYPE html>
<html>
  <head>
	<title>BEAUTY PALACE - Purchase Bill</title>
	
    <link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script type="text/javascript" src="bootstrap/js/jquery-1.11.3.min.js"></script>
	
	<style type="text/css">
    .box{
        color: #000;
         margin-top: 40px;
    }
    .red{ background: #ECF0F5; }
 
    
	</style>
	
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	
	<script type="text/javascript">
	$(document).ready(function(){
		$('input[type="checkbox"]').click(function(){
			var inputValue = $(this).attr("value");
			$("." + inputValue).toggle();
		});
	});
	
	function singleSelectChangeText() {
			//Getting Value
			
			var selObj = document.getElementById("singleSelectTextDDJS");
			var selValue = selObj.options[selObj.selectedIndex].text;
			
			//Setting Value
			document.getElementById("textFieldTextJS").value = selValue;

			}
			
			function fetch_select1(val)
			{
			 $.ajax({		 
			 type: 'post',
			 url: 'fetch_data_name.php',	 
			 data: {		 
			  get_option:val
			 },
			 success: function (response) {		  
			 document.getElementById("new_select1").innerHTML=response;
			 
			 }
			 });
			}
			
			function fetch_select2(val1)
				{		
				
				 $.ajax({
				 type: 'post',
				 url: 'fetch_data_itemname.php',
				 data: {
				  get_option1:val1
				 },
				  success: function (response) {		
				  document.getElementById("new_select2").innerHTML=response;
				   
				  var x = document.getElementsByClassName("exampleitemname");
				  x[0].innerHTML = response; 
				   
				 }
				 });
				}
			

			function fetch_select3(val3)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_productcode.php',
			 data: {
			  get_option3:val3
			 },
			 success: function (response) {		
			  
			  document.getElementById("new_select3").innerHTML=response;
				
			  var x = document.getElementsByClassName("exampleproductcode");
			  x[0].innerHTML = response;	
			  
			 }
			 });
			}
			
			function fetch_select4(val4)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_productprice.php',
			 data: {
			  get_option4:val4
			 },
			 success: function (response) {		
			  
			  document.getElementById("new_select4").innerHTML=response;
				
			  var x = document.getElementsByClassName("exampleproductprice");
			  x[0].innerHTML = response;	
			  
			 }
			 });
			}
			
			function fetch_select5(val5)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_sellingprice.php',
			 data: {
			  get_option5:val5
			 },
			 success: function (response) {		
			  
			  document.getElementById("new_select5").innerHTML=response;
				
			  var x = document.getElementsByClassName("examplesellingprice");
			  x[0].innerHTML = response;	
			  
			 }
			 });
			}
			
	</script>

  </head>
  <body>
  <div class="main-menu>

  
  <div class="area"></div><nav class="main-menu">
  
  
            <ul>
                <li>
                    <a href="index.php"> 
						<i class="fa fa-home fa-2x"></i>
                        <span class="nav-text">
                            Billing
                        </span>
                    </a>
                  
                </li>
                <li class="has-subnav">
                    <a href="dashboardpurchase.php">
                        <i class="fa fa-laptop fa-2x"></i>
                        <span class="nav-text">
                            Purchase
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="dashboardsales.php">
                       <i class="fa fa-list fa-2x"></i>
                        <span class="nav-text">
                           Sales
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-folder-open fa-2x"></i>
                        <span class="nav-text">
                            Pages
                        </span>
                    </a>
                   
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-bar-chart-o fa-2x"></i>
                        <span class="nav-text">
                            Graphs and Statistics
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-font fa-2x"></i>
                        <span class="nav-text">
                           Quotes
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                       <i class="fa fa-table fa-2x"></i>
                        <span class="nav-text">
                            Tables
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                        <i class="fa fa-map-marker fa-2x"></i>
                        <span class="nav-text">
                            Maps
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa fa-info fa-2x"></i>
                        <span class="nav-text">
                            Documentation
                        </span>
                    </a>
                </li>
            </ul>

            <ul class="logout">
                <li>
                   <a href="#">
                         <i class="fa fa-power-off fa-2x"></i>
                        <span class="nav-text">
                            Logout
                        </span>
                    </a>
                </li>  
            </ul>
        </nav>
 <div class="container">
 <article>
	<h3 align="left">PURCHASE</h3>
		
	 <div class="row">
	 <div class="col-sm-3">
	 
	 <?php
		

		include_once("classes/DbFunction.php");
		
		$DbFunction = new DbFunction();
		
		$conn = $DbFunction->myconnect();					
				
		$purchaseid = $_GET['id'];
		
		$result = $DbFunction->getData("SELECT * FROM purchase WHERE purchaseid = '$purchaseid' ORDER BY purchaseid");
					
		foreach ($result as $row) {
			 
			  $purchaseid = $purchaseid;
			  
			  $purchasebillno = $row['purchasebillno'];
			  $vendorname = $row['vendorname'];
			  $venderinoviceno=$row['venderinoviceno'];
			  
			  $productname=$row['productname'];
			  $itemname=$row['itemname']; 
			  $productcode=$row['productcode'];
			  $itemprice=$row['itemprice'];
			  $sellingprice=$row['sellingprice'];
			  $itemquantity=$row['itemquantity'];
			  $total=$row['total']; 
			  
			  $gstpercentage=$row['gstpercentage'];
			  $gstontotal=$row['gstontotal'];
			  $grandtotal=$row['grandtotal'];				  
			  
		}
		
	?>
	 
	 
	 
	<table> 
    
	<form name="updatedashboardpurchase" align="LEFT" action="updatepurchasebillquery.php"  method="post">
            <tr>
                
					<td align="left">Next Bill No. </td> 
					<td><label value="">
					
		<?php
		
		include_once("classes/DbFunction.php");
		
		$DbFunction = new DbFunction();
		
		$conn = $DbFunction->myconnect(); 
		
		$purchaseid = $_GET['id'];
		
		$query = "SELECT DISTINCT purchaseid FROM purchase WHERE purchaseid = '$purchaseid' ORDER BY purchaseid DESC Limit 1";
		
		$result = $DbFunction->getData($query);
		
		foreach ($result as $res) 
		{
			$purchaseid = $res['purchaseid'];
		}
		
		 $npurchaseid = $purchaseid;
	

 		
		?>
		
	
	
		
<?php
	if(isset($npurchaseid)) {
		
	?>	
		<input disabled type = "text" value="<?php echo $npurchaseid; ?>" autofocus name="npurchaseid"  class='form-control detail'/> 
		<input hidden type="text" value="<?php echo $npurchaseid; ?>" autofocus name="getid" class='form-control detail' />			
	<?php
	
	} 	

	?>	
				
					</label></td>
                </tr>
                <label value="">
					<td align="left">Vendor Name </td>
                    <td><label>
						<input type="text" autofocus name="vendorname" value="<?php echo $vendorname; ?>" class='form-control detail' />										
					    </label></td>
				</tr>  
				 
				<tr>
                      <td align="left">Invoice Number </td>
                      <td><label>
                        <input type="text" autofocus name="venderinoviceno" value="<?php echo $venderinoviceno; ?>" class='form-control detail' />
                      </label></td>
                    </tr>     
               
                <tr>
                    <td align="left">Product Category </td>
                    <td><label>
					
					<?php 
						
						$productvalue = "---Select---";	
						$result = $DbFunction->getData("SELECT productname FROM mpurchase GROUP BY productname");
						
						echo "<select name='productname'  id='productname' onChange='fetch_select1(this.value);fetch_select2(this.value);fetch_select3(this.value);fetch_select4(this.value);fetch_select5(this.value);' class='form-control detail' style='width:170px;select:focus width:auto;'>";
						echo "<option value='$productname'>";
						if (!empty($productname))
							 echo $productname;
						else { 
							echo $productvalue;
						}
						echo "</option>";
						
						foreach ($result as $res) {
						
							$productname=$res['productname'];
							
							echo "<option value='$productname'>$productname</option>";
						}
						
					echo "</select>";	
					
					?>
					
				</label></td>
                </tr>
				
                <tr>
					<td align="left">Product Name </td>
                    <td> 
					
					<?php 
						
						$result = $DbFunction->getData("SELECT  itemname FROM mpurchase WHERE itemname = '$itemname' ORDER BY itemname");
						$itemvalue = "---Select---";
						echo "<select  name='itemname[]' id='new_select2' class='exampleitemname form-control detail' style='width:170px;' >";
						
						echo "<option value='$itemname'>";
						if (!empty($itemname))
							 echo $itemname;
						else { 
							echo $productvalue;
						}
						echo "</option>";
						
						//echo "<option value='Select Item Name'>Select Item Name</option>";
						
						foreach ($result as $res) {
						
								  $itemname=$res['itemname'];
							echo "<option value='$itemname'>$itemname</option>";
						}
						
						echo "</select>";	
					
					?>
				
				</td>
                </tr>
                <tr>
                    <td align="left">Product Price </td>
                    <td><input type="text" autofocus name="itemprice" value="<?php echo $itemprice; ?>" class='form-control detail' /></td>
                </tr>
				
				<tr>
                    <td align="left">Selling Price </td>
                    <td><input type="text" autofocus name="sellingprice" value="<?php echo $sellingprice; ?>" class='form-control detail' /></td>
                </tr>
               
			   <tr>
					<td align="left">Product Quantity </td>
                    <td><input type="text" autofocus name="itemquantity" value="<?php echo $itemquantity; ?>" class='form-control detail' /></td>
                </tr>
                             
                <tr>
                    <td align="left">GST % </td>
                    <td><input type="text" autofocus name="gstpercentage" value="<?php echo $gstpercentage; ?>" class='form-control detail' /></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>                 	
				<tr>
                    <td>&nbsp;</td>
                    <td> 
						<input type="submit" name="AddSubmit" value="Submit" class="form-submit-button" class='form-control detail'  /> </td>
                </tr>
                <tr>
					<td>&nbsp;</td>
                </tr>
				</form>
            </table> 
			</div>
			
	<div class="col-sm-9">
		
			
	<?php          

		include_once("classes/DbFunction.php");
		
		$DbFunction = new DbFunction();
		
		$conn = $DbFunction->myconnect();
		
		$query = "SELECT * FROM purchase ORDER BY purchaseid Desc";
		
		$total_results = $DbFunction->getNorows($query);
		
		$per_page = 9;
		
		$total_pages = ceil($total_results / $per_page);

        if (isset($_GET['page']) && is_numeric($_GET['page']))
        {
                $show_page = $_GET['page'];
                
                // make sure the $show_page value is valid
                if ($show_page > 0 && $show_page <= $total_pages)
                {
                        $start = ($show_page -1) * $per_page;
                        $end = $start + $per_page; 
                }
                else
                {
                        // error - show first set of results
                  echo      $start = 0;
                  echo      $end = $per_page; 
                }               
        }
        else
        {
                // if page isn't set, show first set of results
                $start = 0;
                $end = $per_page; 
        }
		
		
		$result = $DbFunction->getData("SELECT * FROM purchase ORDER BY purchaseid Desc Limit $start, $per_page");
		
		echo "<div><table align='center'  class='table table-responsive'  cellpadding='0.5' border-spacing: 1px; style='border-collapse: collapse;padding-top:40px;'>";

		echo '<tr> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Edit</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Delete</th>
		
		
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center;">Sr No</th> 
		<!-- <th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Purchases Bill No</th>  -->
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Vendor Name</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Inovice No</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product Name</th>

		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item Name</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Selling Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item Quantity</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Price Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">GST%</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">GSTTotal</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Grand Total</th>
		
</tr>';
				
			$start = $start + 1;
			 
			// loop through results of database query, displaying them in the table 
        for ($i = $start; $i < $end; $i++)
        {
                // make sure that PHP doesn't try to show results that don't exist

                if ($i == $total_results) { break; }		
			
			foreach ($result as $res) {
				  $purchaseid = $res['purchaseid'];
				  $purchasebillno = $res['purchasebillno'];
				  $vendorname = $res['vendorname'];
				  $venderinoviceno=$res['venderinoviceno'];
				  $productname=$res['productname'];
				  $itemname=$res['itemname']; 
				  $productcode=$res['productcode'];
				  $itemprice=$res['itemprice'];
				  $sellingprice=$res['sellingprice'];
				  $itemquantity=$res['itemquantity'];
				  $total=$res['total'];				  
				  $gstpercentage=$res['gstpercentage'];
				  $gstontotal=$res['gstontotal'];
				  $grandtotal=$res['grandtotal']; 		  
				  			  
				echo '<tr> </tr>';
				echo '<tr> </tr>';
			
				echo "<tr>";
            
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="updatedashboardpurchase.php?id=' . $purchaseid . '"><img src="update.png"></a></td>'; 
				
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="deletepurchasebill.php?id=' . $purchaseid . '" onclick="return confirmDelete()"><img src="del.png"></a></td>';	
                
                echo '<td style="padding: 1PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
            
                echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $vendorname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $venderinoviceno . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $productname . '</td>';
			
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $sellingprice . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $total . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $gstpercentage . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $gstontotal . '</td>';
				echo '<td style="padding: 1PX;border: 0.5PX solid ;">' . $grandtotal . '</td>';
				
				echo "</tr>"; 
				
				$i = $i + 1;	
							
				}
				
				if ( $i > $rows ) {
				break;	
				
				} 
			}
					
		echo "</table></div>";
		
		
		echo "<div align='center'>";      
        echo "<p><b>View Page Wise:</b> ";
        for ($i = 1; $i <= $total_pages; $i++)
        {
                echo "<a id = 'anchortag' href='dashboardpurchase.php?page=$i'>$i</a> ";
        }
        echo "</p>";
		echo "</p>";
		echo "</p>";
		
		echo "</div>";
		
 ?>
 </div>
	
	</div>
	
	 </div>
	 
  </article>
 

 </div>

 </div>
 </body>
 </html>