<?php

if(isset($_POST['get_option4']))
{

	$state4 = $_POST['get_option4'];	
	
	include_once("classes/DbFunction.php");
	
	$DbFunction = new DbFunction();	
									
	$result = $DbFunction->getData("SELECT  productprice FROM mpurchase WHERE productname = '$state4'  ORDER BY productname");
	
		foreach ($result as $res) {
			
			 echo "<option>".$res['productprice']."</option>";
		
		}
		
		 exit; 
}	

?>