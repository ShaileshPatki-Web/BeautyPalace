<?php
$totalsale=0;
	include_once("classes/DbFunction.php");
	$DbFunction = new DbFunction();
	$conn = $DbFunction->myconnect();
	$x=$_POST['month'];
	if($x==1){$month="January";}
	elseif($x==2){$month="February";}
	elseif($x==3){$month="March";}
	elseif($x==4){$month="April";}
	elseif($x==5){$month="May";}
	elseif($x==6){$month="June";}
	elseif($x==7){$month="Jully";}
	elseif($x==8){$month="August";}
	elseif($x==9){$month="September";}
	elseif($x==10){$month="October";}
	elseif($x==11){$month="November";}
	elseif($x==12){$month="December";}
	$query ="SELECT * FROM sales WHERE MONTH(salesDate) = '$x'";
	$result = $DbFunction->getData($query);
	echo '<tr><td colspan="12" align="center">'.$month .' Month Report </td></tr><tr> <th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF; text-align: center; ">SrNo</th> ';
		echo '<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Bill No</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Sales Date</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Customer Name</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product<br>Name</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item<br>Name</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Qty</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discount %</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discount Amt</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Grand<br>Total</th>
		</tr>';
				
	foreach ($result as $row) 
	{
			$month=$row['MONTH(salesDate)'];
			$salesid = $row['salesid'];
			$salesbillno = $row['salesbillno'];
			$salesDate= $row['salesDate'];
			$customername = $row['customername'];
			$productname=$row['productname'];
			$itemname=$row['itemname']; 
			$itemprice=$row['itemprice'];
			$itemquantity=$row['itemquantity'];
			$total=$row['total']; 
			$discpercentage=$row['discpercentage'];
			$discontotal=$row['discontotal'];
			$grandtotal=$row['grandtotal']; 		  
			$totalsale =$totalsale+$grandtotal; 		
	
			echo '<tr><td style="padding: 0.5PX;border: 0.5PX solid ;">'  .$salesid.'<div align="center">'.($i).'</div>'. '</td>'; 
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $salesbillno . '</td>';
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;"><strong>' . $salesDate . '</strong></td>';
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $customername . '</td>';
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $productname . '</td>';
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemname . '</td>';
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
			if($itemquantity<=5)
			{
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;"><font color="red">' . $itemquantity . '</font></td>';
			}else
			{
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
			}
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $total . '</td>';
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discpercentage . '</td>';
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discontotal . '</td>';
			echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $grandtotal . '</td>';
			echo '</tr>';
			}
			echo "<tr><td colspan='12' align='right'>Total =".$totalsale. "</td></tr>";

?>
