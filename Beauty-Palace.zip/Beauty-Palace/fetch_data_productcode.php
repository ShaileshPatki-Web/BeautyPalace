<?php

if(isset($_POST['get_option3']))
{
	
	$state3 = $_POST['get_option3'];
	
	include_once("classes/DbFunction.php");
	
	$DbFunction = new DbFunction();
	
	
	$result = $DbFunction->getData("SELECT  productcode FROM mpurchase  WHERE productname = '$state3' ORDER BY productname");
	
		
		
		foreach ($result as $res) {
			 echo "<option>".$res['productcode']."</option>";
		
		}
		
		exit;
}	

?>