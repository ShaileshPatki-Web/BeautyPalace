<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Beauty Palace - Stock</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<center><img src="img/New_logof.jpg"></center>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/table.css"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
		<script src="table2excel.js" type="text/javascript"></script>
		<script type="text/javascript">
			function myFunction() 
			{
				var htmltable= document.getElementById('tblCustomers');
				var html = htmltable.outerHTML;
				window.open('data:application/vnd.ms-excel,' + encodeURIComponent(html));
			} 
			function stockPrint()
			{
				var table=document.getElementById("tblCustomers");
				 newWin=window.open("");
				 newWin.document.write("<html><head><link rel='stylesheet' type='text/css' href='bootstrap/css/table.css'/></head> <body>");
				// newWin.document.write($('#tblCustomers').html());
				 newWin.document.write(table.outerHTML);
				 newWin.document.write("</body></html>");
				 newWin.print();
				 newWin.close();
				 //window.print();
				
			}
</script>

  </head>
  <body>
  <div class="main-menu>
  <div class="area"></div><nav class="main-menu">
		<ul>
            <li><a href="index.php">
			<i class="fa fa-home fa-2x"></i>
            <span class="nav-text">Billing</span>
            </a>
            </li>
			<li class="has-subnav">
                <a href="dashboardpurchase.php">
                <i class="fa fa-laptop fa-2x"></i>
                <span class="nav-text">Purchase</span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="dashboardsales.php">
                <i class="fa fa-list fa-2x"></i>
                <span class="nav-text">Sales</span>
                </a>
            </li>
			<li>
                <a href="dashboardproduct.php">
                <i class="fa fa-bar-chart-o fa-2x"></i>
                <span class="nav-text">
                    Add Product 
                </span>
                </a>
            </li>
            <li class="has-subnav">
                <a href="stock.php">
               <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Stock Report</span>
                </a>
            </li>
           
           <li>
                <a href="salesReport.php">
                 <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Sales Report</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-table fa-2x"></i>
                <span class="nav-text">Tables</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="fa fa-map-marker fa-2x"></i>
                <span class="nav-text">Maps</span>
                </a>
            </li>
            <li>
				<a href="#">
                <i class="fa fa-info fa-2x"></i>
                <span class="nav-text">Documentation</span>
                </a>
            </li>
        </ul>
        <ul class="logout">
			<li>
			<a href="#">
            <i class="fa fa-power-off fa-2x"></i>
            <span class="nav-text">Logout</span>
            </a>
			</li>  
        </ul>
    </nav>
	
 <div class="container">
 <article>
	<h3>STOCKS</h3>
	<div class="row">&nbsp;</div>
	 <div class="row" >
	 <div class="col-md-12">
	 <div class="search-container" >
	 <p></p>
	 
	 <form action="" method="post">
		<input type='text' align='right' id="search" name="search" placeholder='Search..' name='search' >
		<button type='submit' align='right' formaction="stock.php"><i class='fa fa-search'></i></button>
		<!-- -->
		</form>
		
		<p></p>
		
	</div>
	</div>
	</div>
	<div class="row">
	<div class="col-md-12">
	
	<?php          
		
		include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect();
		$query = "SELECT * FROM stock ORDER BY productid Desc";
		$total_results = $DbFunction->getNorows($query);
		$per_page = 15;
		$total_pages = ceil($total_results / $per_page);
		if (isset($_GET['page']) && is_numeric($_GET['page']))
        {
                $show_page = $_GET['page'];
                // make sure the $show_page value is valid
                if ($show_page > 0 && $show_page <= $total_pages)
                {
                        $start = ($show_page -1) * $per_page;
                        $end = $start + $per_page; 
                }
                else
                {
                // error - show first set of results
                  echo      $start = 0;
                  echo      $end = $per_page; 
                }               
        }
        else
        {
                // if page isn't set, show first set of results
                $start = 0;
                $end = $per_page; 
        }
		if (isset($_POST['search']))
		{
			//echo "searching";
			$search=$_POST['search'];
			$result=$DbFunction->getData("SELECT * FROM stock WHERE productname LIKE '$search%' OR productcode LIKE '$search%' OR itemname LIKE '$search%' OR itemprice LIKE '$search%' OR sellingprice LIKE '$search%' OR itemquantity LIKE '$search%'  ");
		} else {
			//$result = $DbFunction->getData("SELECT SUM( itemquantity ) AS itemquantity , productname, itemname, itemprice, sellingprice FROM purchase GROUP BY itemname ORDER BY SUM( itemquantity ) ASC Limit $start, $per_page " );
			$result=$DbFunction->getData("SELECT * FROM stock");
		}
		echo "<div id='divToPrint'> <table id='tblCustomers' align='center'  class='table table-responsive' height='300px' cellpadding='0.5' border-spacing: 1px; style='border-collapse: collapse;'>";
		echo '<tr> <th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center;">Sr. No.</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product Category</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product name</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Purchase Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Selling Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Quantity</th>
		</tr>';
		$start = $start + 1;
		// loop through results of database query, displaying them in the table 
        for ($i = $start; $i < $end; $i++)
        {
        // make sure that PHP doesn't try to show results that don't exist
            if ($i == $total_results) { break; }		
			foreach ($result as $res) 
			{
				$purchaseid = $res['purchaseid'];
				$purchasebillno = $res['purchasebillno'];
				$vendorname = $res['vendorname'];
				$venderinoviceno=$res['venderinoviceno'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$productcode=$res['productcode'];
				$itemprice=$res['itemprice'];
				$sellingprice=$res['sellingprice'];
				$itemquantity=$res['itemquantity'];
				$total=$res['total'];				  
				$gstpercentage=$res['gstpercentage'];
				$gstontotal=$res['gstontotal'];
				$grandtotal=$res['grandtotal']; 		  
				  			  
				echo "<tr>";
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
               	echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $sellingprice . '</td>';
				if($itemquantity<=5)
				{			
					echo '<td style="padding: 0.5PX;border: 0.5PX solid ;"><font color="red">' . $itemquantity . '</font></td>';
				}else
				{
					echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
				}
				
				echo "</tr>"; 
				
				$i = $i + 1;	
			}
			if ( $i > $rows ) 
			{
				break;	
			} 
		}
		echo "</table></div>";
?>
		</div>
		</div>
	 </div>
	 <?php 
		echo "<div align='center'>";      
        echo "<p><b>View Page Wise:</b> ";
        for ($i = 1; $i <= $total_pages; $i++)
        {
                echo "<a id = 'anchortag' href='dashboardstock.php?page=$i'>$i</a> ";
        }
	?>	
		<button name="Excel" onclick="myFunction()">Excel</button>
		<button name="Print" onclick="stockPrint()">Print</button>
		
  </article>
 </div>
 </div>
 </body>
</html>