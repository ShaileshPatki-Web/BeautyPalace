<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>

		<meta charset="UTF-8">       
		
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	-->	
         <title>Beauty Palace</title>
        
        <style>
            
            /* Style the element with the id "myHeader" */
            
             
                #Headertext {
                  top: 0;
              
                  font-size: 18px;
                  color: black;
                  background-color: lightskyblue;
                  text-align: center;                  
                  width: 100%;
                  height: 100%;
                }

                /* Style all elements with the class name "city" */
                
                .date1 {
                    
                  position: static;  
                  background-color: lightskyblue;
                  color: green;
                  font-size: 18px;
                  text-align: center;
                  padding: 250px;
                }
                
                #borderimg { 
                    border: 8px solid transparent;
                    border-radius: 25px;                    
                    
                    border-image: url(nbproject/border.png) 30 round;
                    width: 485px;
                    height: 345px;
                  }

                 #Footertext {
                  
                    position: fixed;
                    left: 0;
                    bottom: 0;
                    width: 100%;
                    background-color: crimson;
                    color: white;                  
                    font-size: 24px;    
                    text-align: center;
            }
     
              .topleft {
              position: absolute;  
              top: 28px;
              left: 28px;
              font-size: 18px;
            }

            .topright {
              position: absolute;
              top: 28px;
              right: 28px;
              font-size: 18px;
            }

            .center {
              position: absolute;
              left: 0;
              top: 3%;
              width: 100%;
              text-align: center;
              font-size: 18px;
            }


            .form-submit-button {

                background: #016ABC;
                color: #fff;
                border: 1px solid #eee;
                border-radius: 20px;
                text-shadow:none;

                }

                .form-submit-button:hover {

                background: #33ccff;
                color: #fff;
                border: 1px solid #eee;
                border-radius: 20px;
                text-shadow:none;

            }
			
			 select {
				width: 178px;
				margin: 10px;
			}
			select:focus {
				min-width: 178px;
				width: auto;
			}    	
       
        </style>
        
        
    </head>
    <body>
        
        <div id='Headertext'>

		<div class="date1">
            
        <div class="topleft">

        <?php
        
            echo $date = date("d-M-Y");           
        
        ?>  
         
         </div>      
            
        <div class="center">
            <h1>
            <img src="nbproject/gifdesign.gif" height='40' width='40' style="align-items: center;" >
            
            </img>      Beauty Palace <img src="nbproject/gifdesign.gif" height="40" width="40">  </img>        </h1> 
        </div>
            
          <div class="topright">
          
                <form name="Tick">
                    
                    <div id="demo"> </div>
                    
                </form>
            
        </div>
		
					
                
        <?php          
           
		
		$purchasebillno = $_GET['id'];
		
		include('connect_db.php');
		
        // get results from database
		$objEmp=new dbConnect1("localhost","root","","beautypalace");
		
		$query ="SELECT * FROM purchase  WHERE purchaseid = '$purchasebillno'";			

		$result=$objEmp->connect($query);
		
		while($row = mysql_fetch_array( $result )) 
  			{			
			  	  $id = $row['purchaseid'];
				  $purchasebillno = $row['purchasebillno'];
				  $vendorname = $row['vendorname'];
				  $venderinoviceno=$row['venderinoviceno'];
				  $productname=$row['productname'];
				  $itemname=$row['itemname']; 
				  
				  $itemprice=$row['itemprice'];
				  $itemquantity=$row['itemquantity'];
				  $total=$row['total']; 
				  
				  $gstpercentage=$row['gstpercentage'];
				  $gstontotal=$row['gstontotal'];
				  $grandtotal=$row['grandtotal'];	
			}
		
 ?>
                
        </div>
          
        </div>    

               
        <div>   
       
        <div id="Footertext">Copyright 2019</div>
        
        </div>  
   </body> 
   
<script>
var myTimer = setInterval(myClock, 1000);
function myClock() {
    document.getElementById("demo").innerHTML =
    new Date().toLocaleTimeString();
}
</script>

        
</html>