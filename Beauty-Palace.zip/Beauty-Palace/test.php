<!--
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Demo GetSelectOptionData</title>
	
	 <script>
    function showData() {
        var theSelect = demoForm.demoSelect;
        var firstP = document.getElementById('firstP');
        var secondP = document.getElementById('secondP');
        var thirdP = document.getElementById('thirdP');
		
        firstP.innerHTML = ('This option\'s index number is: ' + theSelect.selectedIndex );
        secondP.innerHTML = ('Its value is: ' + theSelect[theSelect.selectedIndex].value);
        thirdP.innerHTML = ('Its text is: ' + theSelect[theSelect.selectedIndex].text);
		
    }
	
	
     </script>
</head>
<body>
    <form name="demoForm">
        <select name="demoSelect" onchange="showData()">
            <option value="zilch">Select:</option>
            <option value="A">Option 1</option>
            <option value="B">Option 2</option>
            <option value="C">Option 3</option>
        </select>
    </form>

    
	<input type="text" readonly name="test" id="secondP" /> 
    <p id="secondP">&nbsp;</p>
    <p id="thirdP">&nbsp;</p>

	function singleSelectChangeText() {
			//Getting Value
				
			var itemnameindex=indexForm.itemname.value;
				
			document.getElementById("txtHint2").innerHTML=itemnameindex;
			myForm.itemname.value=itemnameindex;
			
			
			var selObj = document.getElementById("singleSelectTextDDJS");
			var selValue = selObj.options[selObj.selectedIndex].value;
			alert(selValue);
			//Setting Value
			document.getElementById("textFieldTextJS").value = selValue;

			}
   
</body>
</html>
-->

<!DOCTYPE html>
<html>
	<head>
		<title>JavaScript - Get selected value from dropdown list</title>
	<script>
	
		function singleSelectChangeText() {
        //Getting Value
        
 
        var selObj = document.getElementById("singleSelectTextDDJS");
        var selValue = selObj.options[selObj.selectedIndex].text;
        
        //Setting Value
        document.getElementById("textFieldTextJS").value = selValue;
		}
 
	</script>
	</head>

	<body>

		<h1>JavaScript - Get selected value from dropdown list</h1>

	<select id="singleSelectTextDDJS" class="form-control"
        onchange="singleSelectChangeText()">
        <option value="0">Select Value 0</option>
        <option value="8">Option value 8</option>
        <option value="5">Option value 5</option>
        <option value="4">Option value 4</option>
    </select>
	
	<?php

	if (!isset($_POST['voteid'])) {
     $x = $_POST['voteid'];
     echo $x;
   echo "ok";
   }else{
   echo 'no variable received';
   }
 
 ?>
 
    <input type="text"  id="textFieldTextJS" class="form-control" placeholder="get value on option select">
	</body>

</html>