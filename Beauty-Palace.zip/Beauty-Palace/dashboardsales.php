<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>BEAUTY PALACE - Sales Bill</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
   <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
	<head>
  <center><img src="img/New_logof.jpg"></center>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/sidebar2.css"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script type="text/javascript" src="bootstrap/js/jquery-1.11.3.min.js"></script>
	
	<style type="text/css">
    .box{
        color: #000;
         margin-top: 40px;
    }
    .red{ background: #ECF0F5; }
 
	</style>
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){
		$('input[type="checkbox"]').click(function(){
			var inputValue = $(this).attr("value");
			$("." + inputValue).toggle();
		});
	});
	
	function singleSelectChangeText() {
			//Getting Value
			
			var selObj = document.getElementById("singleSelectTextDDJS");
			var selValue = selObj.options[selObj.selectedIndex].text;
			
			//Setting Value
			document.getElementById("textFieldTextJS").value = selValue;

			}
			
			function fetch_select1(val)
			{
			 $.ajax({		 
			 type: 'post',
			 url: 'fetch_data_name.php',	 
			 data: {		 
			  get_option:val
			 },
			 success: function (response) {		  
			 document.getElementById("new_select1").innerHTML=response;
			 
			 }
			 });
			}
			
			function fetch_select2(val1)
				{		
				
				 $.ajax({
				 type: 'post',
				 url: 'fetch_data_itemname.php',
				 data: {
				  get_option1:val1
				 },
				  success: function (response) {		
				  document.getElementById("new_select2").innerHTML=response;
				   
				  var x = document.getElementsByClassName("exampleitemname");
				  x[0].innerHTML = response; 
				   
				 }
				 });
				}
			

			function fetch_select3(val3)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_productcode.php',
			 data: {
			  get_option3:val3
			 },
			 success: function (response) {		
			  
			  document.getElementById("new_select3").innerHTML=response;
				
			  var x = document.getElementsByClassName("exampleproductcode");
			  x[0].innerHTML = response;	
			  
			 }
			 });
			}
			
			function fetch_select5(val5)
			{	 
			 
			 $.ajax({
			 type: 'post',
			 url: 'fetch_data_sellingprice.php',
			 data: {
			  get_option5:val5
			 },
			 success: function (response) {		
			  
			  document.getElementById("new_select5").innerHTML=response;
				
			  var x = document.getElementsByClassName("examplesellingprice");
			  x[0].innerHTML = response;	
			  
			 }
			 });
			}
			
	</script>

</head>
 <body>
  <div class="main-menu>
  <div class="area"></div><nav class="main-menu">  
            <ul>
                <li>
                    <a href="index.php"> 
						<i class="fa fa-home fa-2x"></i>
                        <span class="nav-text">
                            Billing
                        </span>
                    </a>
                </li>
                <li class="has-subnav">
                    <a href="dashboardpurchase.php">
                        <i class="fa fa-laptop fa-2x"></i>
                        <span class="nav-text">
                            Purchase
                        </span>
                    </a>
				</li>
                <li class="has-subnav">
                    <a href="dashboardsales.php">
                       <i class="fa fa-list fa-2x"></i>
                        <span class="nav-text">
                           Sales
                        </span>
                    </a>
                </li>
                <li>
                    <a href="dashboardproduct.php">
                        <i class="fa fa-bar-chart-o fa-2x"></i>
                        <span class="nav-text">
                           Add Product 
                        </span>
                    </a>
                </li>
				<li class="has-subnav">
                    <a href="stock.php">
                        <i class="fa fa-table fa-2x"></i>
                        <span class="nav-text">
                            Stock Report
                        </span>
                    </a>
                </li>
                <li>
					<a href="salesReport.php">
						 <i class="fa fa-table fa-2x"></i>
						<span class="nav-text">Sales Report</span>
					</a>
				</li>
                <li>
                   <a href="#">
                       <i class="fa fa-table fa-2x"></i>
                        <span class="nav-text">
                            Tables
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                        <i class="fa fa-map-marker fa-2x"></i>
                        <span class="nav-text">
                            Maps
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa fa-info fa-2x"></i>
                        <span class="nav-text">
                            Documentation
                        </span>
                    </a>
                </li>
            </ul>
            <ul class="logout">
                <li>
                   <a href="#">
                         <i class="fa fa-power-off fa-2x"></i>
                        <span class="nav-text">
                            Logout
                        </span>
                    </a>
                </li>  
            </ul>
        </nav>
 <div class="container">
 <article>
 <div class="row" style="margin-top:70px;" >
 
 <div class="col-4 col-md-4">
	<h3 align="left">SALES BILL</h3>
	 
	<table >
	<?php	
		include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect();		
		$salesbillno=$_GET['id'];
		$result = $DbFunction->getData("SELECT * FROM sales WHERE salesid='$salesbillno'");
		foreach ($result as $res)
		{
			$salesid = $res['salesid'];
			$salesbillno = $res['salesbillno'];
			$salesDate = $res['salesDate'];
			$customername = $res['customername'];
			$productname=$res['productname'];
			$itemname=$res['itemname']; 
			$productcode=$res['productcode'];
			$itemprice=$res['itemprice'];
			$itemquantity=$res['itemquantity'];
			$total=$res['total'];				  
			$discpercentage=$res['discpercentage'];
			$discontotal=$res['discontotal'];
			$grandtotal=$res['grandtotal']; 
		}
		if(isset($_POST['Edit'])== 'Edit')
		{	
			include_once("classes/DbFunction.php");
			$DbFunction = new DbFunction();
			$conn = $DbFunction->myconnect();		
			$salesid = $_GET['id'];
			$result = $DbFunction->getData("SELECT * FROM sales WHERE 	salesid='$salesid'");
			foreach ($result as $res)
			{
				$salesid = $res['salesid'];
				$salesbillno = $res['salesbillno'];
				$salesDate = $res['salesDate'];
				$customername = $res['customername'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$productcode=$res['productcode'];
				$itemprice=$res['itemprice'];
				$itemquantity=$res['itemquantity'];
				$total=$res['total'];				  
				$discpercentage=$res['discpercentage'];
				$discontotal=$res['discontotal'];
				$grandtotal=$res['grandtotal']; 
			}	  
		}
	?>
	
	<form name="salesbill" align="LEFT" action="salesbill.php"  method="post"  autocomplete="on">
        <td>
			<!-- <td align="left">New Bill No</td> -->
			<td><label>
			<?php
				include_once("classes/DbFunction.php");
				$DbFunction = new DbFunction();
				$conn = $DbFunction->myconnect(); 
				$query = "SELECT DISTINCT salesid FROM sales ORDER BY salesid DESC Limit 1";
				$result = $DbFunction->getData($query);
				foreach ($result as $res)
				{
					$salesid = $res['salesid'];
				}
				$salesid = ($salesid + 1);			
								
			?>
				<!-- <input disabled type="text" value="<?php echo $salesid; ?>" autofocus name="salesid1" class='form-control detail'/> -->
				<input hidden type="text" value="<?php echo $salesid; ?>"  name="salesid" class='form-control detail' />
				</label></td>
                </tr>	
				<tr>
					<td align="left">Sales Bill No </td>
                    <td><label>
						<input type="text" value="<?php echo $salesbillno; ?>" autofocus name="salesbillno" class='form-control detail' />					
					    </label></td>
				</tr>  
				

				<tr>
					<td align="left">Sales Date  </td>
                    <td><label>
						<input type="date" value="<?php echo date('Y-m-d'); ?>" autofocus name="salesDate" class='form-control detail' />					
					    </label></td>
				</tr>  
				
				
				
                <tr>
					<td align="left">Customer Name</td>
					<td><label>
					<input type="text"  value="<?php echo $customername; ?>" autofocus name="customername" class='form-control detail' />					
					</label></td>
				</tr>   
                
				<tr>
                <td align="left">Product Category &nbsp;&nbsp</td>
                <td><label>
					<?php 
						
						$productvalue = "---Select---";	
						
						$result = $DbFunction->getData("SELECT DISTINCT productname FROM mpurchase GROUP BY productname,itemname ORDER BY productname,itemname");
						
						echo "<select name='productname'  onChange='fetch_select1(this.value);fetch_select2(this.value);fetch_select3(this.value);fetch_select5(this.value);' style='width:190px'; class='form-control detail'>";
						
						echo "<option value='$productname'>";
						if (!empty($productname))
							 echo $productname;
						else { 
							echo $productvalue;
						}
						echo "</option>";
						
						foreach ($result as $res) {
						
							$productname=$res['productname'];
							
							echo "<option value='$productname'>$productname</option>";
						}
						
					echo "</select>";	
					
					?>	
					
					
				</label></td>
                </tr>
				
				
				
		        <tr>
					<td align="left"><label for="ItemName">Item Name</label></td>
					<td><label>					
					 <?php 
						
						$itemvalue = "---Select---";
						
						$result = $DbFunction->getData("SELECT  itemname FROM mpurchase WHERE itemname = '$itemname' AND productname = '$productname' ORDER BY itemname");
						
						echo "<select  name='itemname' id='new_select2' style='width:190px'; class='exampleitemname form-control detail' >";
						
						echo "<option value='$itemname'>";
						if (!empty($itemname))
							 echo $itemname;
						else { 
							echo $itemvalue;
						}
						echo "</option>";
						
						//echo "<option value='Select Item Name'>Select Item Name</option>";
						foreach ($result as $res) {
						
								  $itemname=$res['itemname'];
							echo "<option value='$itemname'>$itemname</option>";
						}
						
						echo "</select>";	
					
						?>	
					</label></td>
                </tr>
        		<td></td>
				<tr>
				</tr>
				
				<td></td>
				
				<tr>
                
                </tr>
				
				<td></td>
				
		        <tr>
                    <td align="left">Item Price </td>
                    <td><label>
					
					<input type="text" value="<?php echo $itemprice; ?>" name="itemprice"  class='form-control detail'/>
					</label>
					</td>
                </tr>
        		<td></td>
				<tr>
					<td align="left">Quantity </td>
                    <td><label>					
					<input type="text" value="<?php echo $itemquantity; ?>" name="itemquantity" class='form-control detail' />
					</label>
					</td>
                </tr>
        		<td></td>
		        <tr>
                    <td align="left">Discount % </td>
                    <td>
					<label><input type="text" value="<?php echo $discpercentage; ?>" name="discpercentage" class='form-control detail' /></label>
					</td>
                </tr>
        		<td>&nbsp;</td>
				<tr>
                    <td>&nbsp;</td>
                    <td> 
					<input type="submit" name="AddSubmit"  value="Submit" formaction="salesbill.php" class="form-submit-button" title="Submit Sales Bill" />
					<!-- <input type="submit" name="Edit" value="Edit" formaction="dashboardsales.php" class="form-submit-button"/> -->
					<input type="submit" name="Select" value="Update" formaction="selectedsalesbill.php" class="form-submit-button" title="Update Sales Bill after Edit Selection"/>
					
					 </td>
                </tr>
                <tr>
					<td>&nbsp;</td>
                </tr>
				</form>
            </table>
			</div>
		<div class="col-12 col-md-8">
		<?php         
        include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect();
		$query = "SELECT * FROM sales ORDER BY salesid Desc";
		$total_results = $DbFunction->getNorows($query);
		$per_page = 9;
		$total_pages = ceil($total_results / $per_page);
		if (isset($_GET['page']) && is_numeric($_GET['page']))
        {
            $show_page = $_GET['page'];
            if ($show_page > 0 && $show_page <= $total_pages)
                {
                        $start = ($show_page -1) * $per_page;
                        $end = $start + $per_page; 
                }
                else
                {
                    echo      $start = 0;
					echo      $end = $per_page; 
                }               
        }
        else
        {
            $start = 0;
            $end = $per_page; 
        } 
		$result = $DbFunction->getData("SELECT * FROM sales ORDER BY salesid Desc Limit $start, $per_page");
		
		echo "<div><table align='center'  class='table table-responsive' cellpadding='3.5' border-spacing: 1px; style='border-collapse: collapse;'>";
		//echo "<div><table align='center'  class='table table-responsive'  cellpadding='0.5' border-spacing: 1px; style='border-collapse: collapse;'>";
		
		echo '<tr> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; "><a href=""><img src="update.png"></a></th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; "><a href=""><img src="del.png"></a></th>
		
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF; text-align: center; ">SrNo</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Bill No</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Sales Date</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Customer Name</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Product<br>Name</th> 
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Item<br>Name</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Price</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Qty</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Total</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discount%</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Discount<br>Amt</th>
		<th style="border: 0.5PX solid #FFFFFF;background: linear-gradient(to bottom, #000000 40%, #808080 107%);color: #FFFFFF;text-align: center; ">Grand<br>Total</th>
		</tr>';
		$start = $start + 1;
		for ($i = $start; $i < $end; $i++)
        {
            if ($i == $total_results) { break; }		
			foreach ($result as $res) {
				$salesid = $res['salesid'];
				$salesbillno = $res['salesbillno'];
				$salesDate= $res['salesDate'];
				$customername = $res['customername'];
				$venderinoviceno=$res['venderinoviceno'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$itemprice=$res['itemprice'];
				$itemquantity=$res['itemquantity'];
				$total=$res['total']; 
				$discpercentage=$res['discpercentage'];
				$discontotal=$res['discontotal'];
				$grandtotal=$res['grandtotal']; 		  				  			  
				echo '<tr> </tr>';
				echo '<tr> </tr>';
				echo "<tr>";
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="dashboardsales.php?id=' . $salesid . '"><img src="update.png"></a></td>'; 
				echo '<td style="padding: 1PX;border: 0.5PX solid ;"><a align href="deletesalesbill.php?id=' . $salesid . '" onclick="return confirmDelete()"><img src="del.png"></a></td>';	
			    
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">'  .'<div align="center">'.($i).'</div>'. '</td>'; 
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $salesbillno . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $salesDate . '</td>';
                echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $customername . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $productname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemname . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemprice . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $itemquantity . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $total . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discpercentage . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $discontotal . '</td>';
				echo '<td style="padding: 0.5PX;border: 0.5PX solid ;">' . $grandtotal . '</td>';
				echo "</tr>"; 
				$i = $i + 1;	
				}
				if ( $i > $rows ) {
				break;	
				}
			}
			echo "</table></div>";		
			echo "<div align='center'>";      
			echo "<p><b>View Page Wise:</b> ";
			for ($i = 1; $i <= $total_pages; $i++)
			{
					echo "<a id = 'anchortag' href='dashboardsales.php?page=$i'>$i</a> ";
			}
			echo "</p>";
			echo "</p>";
			echo "</p>";
			echo "</div>";
		?>
</div>
</div>
</article>
</div>
</div>

<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 It is disabling Slider Menus -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/app.min.js"></script>
<!-- Sparkline -->
<script src="../plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="../plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="../plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS 1.0.1 -->
<script src="../plugins/chartjs/Chart.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<!-- Previous -->

<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="../plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="../plugins/input-mask/jquery.inputmask.js"></script>
<script src="../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="../plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="../plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="../plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="../plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="../plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="../plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<!-- Page script -->

<script>
  $(function () {
    //Initialize Select2 Elements
    $(".select2").select2();

    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    //Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
    //Money Euro
    $("[data-mask]").inputmask();

    //Date range picker
    $('#reservation').daterangepicker();
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
    //Date range as a button
    $('#daterange-btn').daterangepicker(
        {
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function (start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
    );

    //Date picker
    $('#datepicker').datepicker({
	  format: 'dd/mm/yyyy',	  
      autoclose: true
    });

	 $('#birthdate').datepicker({
		format: 'dd/mm/yyyy',
      autoclose: true
    });
	
    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    });
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass: 'iradio_minimal-red'
    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

    //Colorpicker
    $(".my-colorpicker1").colorpicker();
    //color picker with addon
    $(".my-colorpicker2").colorpicker();

    //Timepicker
    $(".timepicker").timepicker({
      showInputs: false
    });
  });
</script>

</body>
</html>