<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Sales Bill</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<style type="text/css">
	input,td,table
	{
		font-size:12px;
	}
	</style>
<body>

	<?php 	
		include_once("classes/DbFunction.php");
		include_once("classes/Crud.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect(); 
		$perpage = 10;
		if(isset($_GET["page"]))
		{
			$page = intval($_GET["page"]);
		}
		else
		{
			$page = 1;
		}
		$calc = $perpage * $page;
		$start = $calc - $perpage;
		$crud = new Crud();
		$conn = $crud->myconnect();
		$query = "SELECT * FROM sales ORDER BY salesidid DESC limit 1 ";
		$rows = $crud->getNorows($query); 
		$result = $crud->getData("SELECT * FROM sales ORDER BY salesid DESC limit 1 ");
		//$result = $DbFunction->getData($query);
		$start = $start + 1;
		for( $i = $start; $i < $calc; $i++) 
		{		
			foreach ($result as $res) 
			{
				$salesid = $res['salesid'];
				$salesbillno = $res['salesbillno'];
				$customername = $res['customername'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$itemprice=$res['itemprice'];
				$itemquantity=$res['itemquantity'];
				$total=$res['total']; 
				$discpercentage=$res['discpercentage'];
				$discontotal=$res['discontotal'];
				$grandtotal=$res['grandtotal']; 
				
				$i = $i + 1;	
			}
			if ( $i > $rows ) 
			{
				break;	
			} 
		}
		
		$disc=($itemprice*$itemquantity*$discpercentage)/100;
		
	?>
	
	<table align='right' width='258' style='border-collapse: collapse;'>
		<tr>
            <td>&nbsp;</td>
		</tr>
		<tr><th align="center" colspan="4"><center><img src="img/Newproject.jpg" height="60" width="220"></center></tr>
		
		<tr>
			<td colspan="4" align="center">&nbsp;18 Mhada Complex, Bansilal Nagar,<br/> Railway Station Road, Aurangabad.</td>
		<tr>	
		<td colspan="4" align="center">Tel:</td></tr>
		</tr>
		<tr>
            <td width="278" colspan="4">-------------------------------------------------------------------</td>
		</tr>
		<tr>
		<th align="center" colspan="4">CASH BILL</th></tr>
		<tr>
            <td width="278" colspan="4">-------------------------------------------------------------------</td>
		</tr>
		<tr>
			<td align="left">Bill no:<?php echo $salesid ;?></td>
			<td  align="right" colspan="3">Date:<input type="text" style="border-style:none" size="9" value="<?php echo date("d-M-Y");?>"> </td>
		<tr><td align="right" colspan="4">Time:<input type="text" style="border-style:none" size="8" value="<?php echo date("h:i:sa");?>"></td>
		</tr>
		</tr>
		<tr>        
                      <td width="278" colspan="4">-------------------------------------------------------------------</td>
		</tr>
		<tr>			
			<td>Perticulars</td>
			<td align="center">Qty</td>
			<td align="center">Rate</td>
			<td>Tot Amt</td>
		</tr>
		<tr>
                     
                      <td width="278" colspan="4">-------------------------------------------------------------------</td>
		</tr>
		
		<?php 
		$netqty=0;
		$query="SELECT * FROM sales WHERE salesbillno='$salesbillno'";
		$rows = $crud->getNorows($query); 
		$result = $crud->getData($query);
		$result = $DbFunction->getData($query);
		foreach ($result as $res) 
			{
				$salesid = $res['salesid'] ."<br>";
				$salesbillno = $res['salesbillno'];
				$customername = $res['customername'];
				$productname=$res['productname'];
				$itemname=$res['itemname']; 
				$itemprice=$res['itemprice'];
				$itemquantity=$res['itemquantity'];
				$total=$res['total']; 
				$discpercentage=$res['discpercentage'];
				$discontotal=$res['discontotal'];
				$grandtotal=$res['grandtotal']; 
				$netqty=$netqty+$itemquantity;
				$totaldiscount=$discpercentage+$discpercentage;
				$finaldisc=$discontotal+$discontotal;
			
			echo '<tr><td><input type="text" size="15" style="border-style:none; width:10em;text-wrap:normal;" value="'. $itemname  . '"></td>';
			echo '<td align="center"><input type="text" style="border-style:none;text-align:center;" size="1" value="'. $itemquantity.'"></td>';
			echo '<td><input type="text" size="3" style="border-style:none;text-align:center;" value="'. $itemprice .'"></td>';
			echo '<td><input type="text" size="3" style="border-style:none;text-align:center;" size="1" value="'.  ($itemprice*$itemquantity-$disc ) . '"><img src="img/rupee.png"></td>
			</tr>';
		}
		$query="SELECT SUM(grandtotal) as grandtotal FROM sales WHERE salesbillno='$salesbillno'";
		$rows = $crud->getNorows($query); 
		$result = $crud->getData($query);
		foreach ($result as $res) 
			{ 
				 $grandtotal=$res['grandtotal']; 
			}
		
		
		?> 
			<tr>
                     
                      <td width="278" colspan="4">-------------------------------------------------------------------</td>
		</tr>
		<tr>
			
			<th align="left">Net Qty : </th>
			<th><input type="text" style="border-style:none; text-align:center;" size="4" value="<?php echo $netqty ?>"></th>
			<th align="center">Total : </th>
			<th><input type="text" style="border-style:none; text-align:center;" size="4" value="<?php echo  $grandtotal ?>"><img src='img/rupee.png'></th>
		</tr>
		<tr>
                     
                      <td width="278" colspan="4">-------------------------------------------------------------------</td>
		</tr>
		
		<?php if ($discpercentage > 0)
		{
			echo "<tr><td></td>
			<!--<td align='left' id='labeldsk'  style='display:block'>Discount: </td>
			<td align='left'>  $totaldiscount % </td> -->
			</tr><tr><td colspan='4' align='center'><strong>You Have Saved : ". $finaldisc ."<img src='img/rupee.png'></strong></td>
			</tr>
			<tr>
            <td>&nbsp;</td>
			</tr>";
		}?>
		
		<tr>
		<td colspan="4"><center>Thanks for shopping</center></td>
		</tr>
		<tr>
		<td colspan="4"><center>Visit Again</center></td>
		</tr>	
	</table>
</body>
</html>