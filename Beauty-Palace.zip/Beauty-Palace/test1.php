<?php 

				$cookie_name = 'productcode';
				$productcode = $_GET['productcode'];
				$cookie_value = $productcode;
				setcookie($cookie_name, $productcode, time() + (86400 * 30), "/");
				
				if(!isset($_COOKIE[$cookie_name])) {
				 echo "Cookie named '" . $cookie_name . "' is not set!";
				} else {
				 echo "Cookie '" . $cookie_name . "' is set!<br>";
				 echo "Value is: " . $_COOKIE[$cookie_name];
				}
				
?>