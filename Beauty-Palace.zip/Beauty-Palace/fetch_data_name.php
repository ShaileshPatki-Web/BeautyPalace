<?php

if(isset($_POST['get_option']))
{

	$state = $_POST['get_option'];

	include_once("classes/DbFunction.php");
	
	$DbFunction = new DbFunction();

	$query = "SELECT  productname FROM mpurchase  WHERE productname='$state' ORDER BY productname";
	
	$result = $DbFunction->getData($query);
	
		foreach ($result as $res) {
			 echo "<option>".$res['productname']."</option>";
		
		}
		
		 exit; 
}	

?>