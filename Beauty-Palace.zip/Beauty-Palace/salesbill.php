<?php

 $salesid = $_POST['salesid'];
 
 $salesbillno = $_POST['salesbillno'];
 
 $salesDate = $_POST['salesDate'];
 
 $customername = $_POST['customername'];
 
 $productname = $_POST['productname'];
 
 $itemname = $_POST['itemname']; 
 $insert_itemname= implode(",", $itemname); // echo
	
 $str_arr1_itemname = explode (",", $insert_itemname);
 
 $productcode = $_POST['productcode']; 
 
 $itemprice = $_POST['itemprice'];  
 
 $itemquantity = $_POST['itemquantity'];
 
 $discpercentage = $_POST['discpercentage']; 
 
 $discontotal = $_POST['discontotal']; 
 
 if(isset($_POST['AddSubmit'])) 
 {

				include_once("classes/DbFunction.php");
		
				$DbFunction = new DbFunction();
		
				$conn = $DbFunction->myconnect();
				
				$salesDate	= $_POST['salesDate'];	 
				
				$total = ($itemprice * $itemquantity);
				
				$discontotal = (($total * $discpercentage) / 100);
				
				$discontotal = number_format($discontotal,2);
				
				$grandtotal = (($total) - ($discontotal));
				
				$grandtotal = number_format($grandtotal,2);
				
				$data = array
					(array(					
				
				'productname' => $insert_productname,
				'itemname' => $insert_itemname,

				'sellingprice' => $insert_sellingprice,
				'itemquantity' => $insert_itemquantity,
				'gstpercentage' => $insert_gstpercentage,
				
				));					
		
				foreach($data as $x => $val) {
						 "$x = $val<br>";
				}
				
				function Counting($data){ 
						
				$count = 0;
				
				foreach( $data as $datacount){
					$count += count( $datacount);
					
				}
				
				return ($count);
				} 
						
				$countarray = Counting($str_arr1_itemname);
				
				for($i=0; $i < $countarray; $i++) {		
		
				$itemname = $str_arr1_itemname[$i];
			
				if(!empty($itemname)) {
					
					 $sql="SELECT * FROM mpurchase WHERE itemname = '$itemname'";

					$result = $DbFunction->getData($sql);
					
					foreach ($result as $res) {
				
						$productcode = $res['productcode'];
					
					}
				}
				
				$resultexe = "INSERT into sales (salesid,salesbillno,salesDate, customername,productname,itemname,productcode,itemprice,itemquantity,total,discpercentage,discontotal,grandtotal) VALUES ('null','$salesbillno','$salesDate','$customername','$productname','$itemname','$productcode','$itemprice','$itemquantity','$total','$discpercentage','$discontotal','$grandtotal')";
				
				$result=$DbFunction->execute($resultexe);
														
			//	$billnoupdate = "UPDATE `sales` SET `salesbillno`= '$salesid'";
				
			//	$result=$DbFunction->execute($billnoupdate);
																
				$deduct= "SELECT productname,itemquantity,productcode FROM stock WHERE itemname = '$itemname'";
				
				$resultdeduct = $DbFunction->getData($deduct);						
				
				$q = $resultdeduct[0]['itemquantity'];						
								
				$quantity=($q - $itemquantity);
								
				$update = "UPDATE stock SET itemquantity='$quantity' WHERE itemname='$itemname'";
				
				
				
				if ($DbFunction->execute($update) === TRUE)
				
				{
					//echo "Record updated successfully";
					
					} else {
						
					//	echo "Error updating record: " . $conn->error;
				}						
						
	header("Location: dashboardsales.php");  
 
 }
 
?>