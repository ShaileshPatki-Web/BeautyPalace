<?php
	 
		$purchaseid = $_POST['purchaseid'];
		$productname = $_POST['productname'];	  
		$itemname = $_POST['itemname'];

		$productname1 = substr($productname, 0, 1);
		$itemname1 = substr($itemname, 0, 1);
		 
		$productcode = ($productname1 . $itemname1 . $purchaseid);
		 
		$productprice = $_POST['productprice'];
		$sellingprice = $_POST['sellingprice'];
	 
	 if(isset($_POST['AddSubmit'])) {
	 
		include_once("classes/DbFunction.php");

		$DbFunction = new DbFunction();

		$conn = $DbFunction->myconnect(); 
											
		$intinsert = "INSERT INTO mpurchase (productname,itemname,productcode,productprice,sellingprice) VALUES ('$productname','$itemname','$productcode','$productprice','$sellingprice')";
								
		$result = $DbFunction->execute($intinsert);
		
		header("Location: dashboardproduct.php");
												
	}	

	if(isset($_POST['Select'])) {	
	
		$purchaseid1 = $_POST['purchaseid1'];
		$productname = $_POST['productname'];

		$itemname = $_POST['itemname'];

		$productcode = $_POST['productcode'];
		$productprice = $_POST['productprice'];
		$sellingprice = $_POST['sellingprice'];
		
		$productname1 = substr($productname, 0, 1);
		$itemname1 = substr($itemname, 0, 1);
 
		$productcode = ($productname1 . $itemname1 . $purchaseid1);
		
		include_once("classes/DbFunction.php");
		
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect(); 
		
		$intinsert = "UPDATE  mpurchase SET productname='$productname',itemname='$itemname',productcode='$productcode',productprice='$productprice',sellingprice='$sellingprice' WHERE 	purchaseid='$purchaseid1'";
		
		$result = $DbFunction->execute($intinsert);
		
		header("Location: dashboardproduct.php");	
	}
	
?>