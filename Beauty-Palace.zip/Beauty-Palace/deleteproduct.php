<?php
		session_start();
		$purchaseid =  $_GET['id'];		
		include_once("classes/DbFunction.php");
		$DbFunction = new DbFunction();
		$conn = $DbFunction->myconnect();	
		$intinsert = "DELETE  From mpurchase WHERE purchaseid='$purchaseid'";
		$result = $DbFunction->execute($intinsert);					
		header("Location: dashboardproduct.php");
?>